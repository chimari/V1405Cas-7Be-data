"""Show Ca and Na doublet EWs using the adopted empirical CoG diagnostics."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

here = Path(__file__).resolve().parent
source = pd.read_csv(here / "diagnostic_CoG_points.csv").set_index("ID")
rows = source.loc[["D03","D04","D05","D06"]].copy()
rows["observed_mA"] = rows.EW_rest_mA
rows["model_mA"] = 1000*rows.rest_air_A*10**rows.model_log_Wrest_over_lambda
rows["difference_mA"] = rows.observed_mA - rows.model_mA
np.testing.assert_allclose(np.log10(rows.observed_mA/rows.model_mA), rows.residual_dex, atol=1e-12)
assert rows.CoG_fit_weight.eq(0).all()
rows[["label","observed_mA","model_mA","difference_mA","sigma_correlated_mA"]].to_csv(
    here / "doublet_ew_comparison.csv")

plt.rcParams.update({"font.size":8,"pdf.fonttype":42})
fig, ax = plt.subplots(figsize=(3.55,2.10))
fig.subplots_adjust(left=.18,right=.66,top=.76,bottom=.23)
y = np.arange(4)[::-1]
for yy in (3,2):
    ax.axhspan(yy-.5,yy+.5,color="#f3f6f8",zorder=0)
ax.axvline(0,color=".48",lw=.7)
for data,color in [(rows.iloc[:2],"#21568a"),(rows.iloc[2:],"#ad4d24")]:
    yy = y[:2] if data.iloc[0].label.startswith("Ca") else y[2:]
    ax.errorbar(data.difference_mA,yy,xerr=data.sigma_correlated_mA,
                fmt="o",ms=3,capsize=2,color=color,zorder=3)
ax.set(yticks=y,yticklabels=rows.label,xlim=(-13,9),ylim=(-.5,3.5),
       xticks=[-10,-5,0,5],xlabel="Observed − model (mÅ)")
ax.tick_params(axis="y",length=0,pad=4)
ax.tick_params(axis="x",length=3,pad=2)
ax.grid(axis="x",alpha=.24)
ax.spines[["top","right","left"]].set_visible(False)
for xpos, field, label in [(1.19,"observed_mA","Obs."),(1.55,"model_mA","Model")]:
    ax.text(xpos,1.06,label,transform=ax.transAxes,ha="center",va="bottom",weight="bold")
    for yy,val in zip(y,rows[field]):
        ax.text(xpos,yy,f"{val:.1f}",transform=ax.get_yaxis_transform(),
                ha="center",va="center")
ax.text(1.37,1.22,"Rest EW (mÅ)",transform=ax.transAxes,ha="center",va="bottom",fontsize=7.5)
fig.savefig(here / "empirical_doublet_ew_comparison.pdf")
