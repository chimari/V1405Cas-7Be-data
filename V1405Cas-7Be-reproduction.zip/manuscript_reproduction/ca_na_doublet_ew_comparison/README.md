# Ca II and Na I doublet equivalent-width comparison

V1405 Cas manuscript figure with LaTeX label `doublet-ew`. The inputs are the four saved empirical CoG diagnostics at covering fraction 0.8 and excitation temperature 12146 K. The model EWs use the Ca II H/K joint normalization and the Na I D1/D2 joint check. The manuscript's displayed Na I ionic ratio uses D1, while the Cloudy reference uses the joint ground-level target.

```sh
python -m pip install -r requirements.txt
python render_doublet_ew_comparison.py
```

The script converts the saved model reduced EWs to mÅ, checks the residual sign and zero weight in the primary CoG, then writes the comparison CSV and PDF. Error bars use the saved conditional measurement noise. `reference_plot.pdf` is the manuscript graphic, and `reference_comparison.csv` is the archived numerical output. The workflow starts from the saved CoG diagnostic points.
