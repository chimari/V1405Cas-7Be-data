"""Integrate the archived isolated Be II profiles before and after doubling opacity."""
from pathlib import Path
import csv

import numpy as np

ROOT = Path(__file__).resolve().parent
C_KMS = 299792.458
EW_VMIN, EW_VMAX = -1010., -940.
REFERENCE_VELOCITY = (EW_VMIN + EW_VMAX)/2


def main():
    data = np.genfromtxt(ROOT/'data/blend_profiles.csv',delimiter=',',names=True,
                         encoding='utf8',dtype=None)
    floor = data['floor']
    assert np.allclose(floor,floor[0])
    covering = 1-floor[0]
    w = data['air_A']
    doppler = np.sqrt((1+REFERENCE_VELOCITY/C_KMS)/(1-REFERENCE_VELOCITY/C_KMS))
    trapezoid = getattr(np,'trapezoid',None)
    if trapezoid is None:
        trapezoid = np.trapz
    rows = []
    for key, rest in (('be3130',3130.583557665),('be3131',3131.228107417)):
        ratio = w/rest
        v = C_KMS*(ratio**2-1)/(ratio**2+1)
        mask = (v>=EW_VMIN)&(v<=EW_VMAX)
        # Isolated flux = 1 - C_f + C_f exp(-tau).
        transmission = np.clip((data[key][mask]-floor[0])/covering,0.,1.)
        ews = [trapezoid(covering*(1-transmission**scale),w[mask])*1000/doppler
               for scale in (1.,2.)]
        rows.append(dict(line=key,Cf=covering,EW_mA=ews[0],EW_tau_doubled_mA=ews[1],
                         change_percent=100*(ews[1]/ews[0]-1)))
    with (ROOT/'opacity_sensitivity.csv').open('w',newline='') as output:
        writer=csv.DictWriter(output,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    for row in rows:
        print(row['line'],f"{row['change_percent']:.2f}%")


if __name__=='__main__':
    main()
