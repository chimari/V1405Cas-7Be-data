# Figure 19 — V339 Del at +38 d

Source files for the V339 Del +38 d appendix figure. From this directory
run python render_figure.py with NumPy, pandas and Matplotlib. Copy the
generated PDF to fig/V339Del_38d_profiles_Be_CoG.pdf in the manuscript.

The 2013 September 23 UT Subaru/HDS exposure uses the −1010 to −940 km/s
heliocentric EW interval. The −1043 km/s feature is modeled in the
near-UV blend and lies outside the EW interval. The input line list and
processed arrays retain the masks and the reviewed local backgrounds.
The blend uses a common covering fraction and the 3121.5 Å plateau.
The Be marker positions are illustrative because the doublet is saturated.
