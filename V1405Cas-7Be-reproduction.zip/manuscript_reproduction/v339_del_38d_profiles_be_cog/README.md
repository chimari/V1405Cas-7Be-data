# V339 Del at +38 d (Figure 20)

LaTeX label `fig:v339del-38d-integrated-cog`. Install the dependencies in
`requirements.txt` and run `MPLBACKEND=Agg python render_figure.py` to
reproduce the [figure](reference_plot.pdf) from the processed CSVs in
`data/`. The script produces `V339Del_38d_profiles_Be_CoG.pdf`.

The 2013 September 23 Subaru/HDS exposure uses the heliocentric EW
window from −1010 to −940 km/s. The −1043 km/s component lies outside the
window and is modeled in the near-UV blend. The line list and processed
profiles retain the masks and reviewed local backgrounds.

Run `python opacity_sensitivity.py` to rebuild
[opacity_sensitivity.csv](opacity_sensitivity.csv). This test doubles the
optical depth of the isolated ⁷Be II profiles at fixed covering and
velocity shape and measures the response within the same EW window.
