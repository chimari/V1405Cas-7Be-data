"""Render the manuscript figure using its accompanying processed CSV inputs."""
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator, MultipleLocator, ScalarFormatter
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
K = 1.497e-15 * np.sqrt(np.pi)
C = 299792.458
VWIN = (-1010, -940)
SPECIES = ['Fe II','Ti II','Cr II','Mn II','Ni II','Fe II reference']
COLORS = {'Fe II':'#215d88','Ti II':'#07776a','Cr II':'#a64e31','Mn II':'#724888',
          'Ni II':'#526778','Fe II reference':'#215d88'}
BE_BLUE, BE_RED, CA = '#245d92', '#a54178', '#9b521e'


def style():
    plt.rcParams.update({
        'font.family':'DejaVu Sans', 'font.size':7.5, 'axes.labelsize':7.8,
        'axes.titlesize':7.7, 'xtick.labelsize':7, 'ytick.labelsize':7,
        'axes.spines.top':False, 'axes.spines.right':False, 'axes.linewidth':.65,
        'xtick.major.size':3, 'ytick.major.size':3,
        'xtick.major.width':.65, 'ytick.major.width':.65, 'pdf.fonttype':42,
        'savefig.facecolor':'white', 'legend.fontsize':6.6,
    })


def title(ax, text, lift=1.24):
    ax.text(0,lift,text,transform=ax.transAxes,ha='left',va='bottom',weight='bold',fontsize=9)


def iron(fig, grid):
    t=pd.read_csv(DATA/'iron_group_profiles.csv')
    axes=[]
    for i,ion in enumerate(SPECIES):
        ax=fig.add_subplot(grid[i//2,i%2],sharex=axes[0] if axes else None)
        axes.append(ax)
        lines=t[t.panel.eq(ion)]
        color=COLORS[ion]
        strong=ion=='Fe II reference'
        ax.axvspan(*VWIN,color='#eaf0f6',zorder=0)
        ax.axhline(1,color='#8d989e',ls='--',lw=.45)
        for v in [-1043,-996,-985,-968,-954]:
            ax.axvline(v,color='#a5afb7',ls=':',lw=.45,zorder=.8)
        for j,(_,g) in enumerate(lines.groupby('id',sort=False)):
            status=g.status.iloc[0]
            check=status in ('check','check_background_dependence')
            rest=g.wavelength_air_A.iloc[0]
            m=g.velocity_helio_kms.between(-1060,-924)
            label=f'{rest:.0f}' if strong else None
            col=('#246290','#a44e38','#178571')[j] if strong else color
            ax.plot(g.velocity_helio_kms[m],g.flux_normalized[m],
                    color=col,lw=.85 if strong else .8,ls='--' if check else '-',
                    alpha=.91 if strong else .65 if check else .82,label=label)
        label='Fe II multiplet 42' if strong else 'Ni II (tentative)' if ion=='Ni II' else ion
        ax.set_title(f'{label} ({lines.id.nunique()})',loc='left',pad=3)
        ax.set_xlim(-1060,-924)
        ax.set_ylim((.80,1.055) if strong else (.815,1.075))
        ax.set_yticks([.85,.90,.95,1.00,1.05])
        ax.xaxis.set_major_locator(MultipleLocator(40))
        ax.tick_params(labelbottom=i>=4,labelleft=i%2==0 or strong)
        if i==0:
            ax.text(-1043,1.058,'−1043',ha='center',va='bottom',
                    color='#53616b',fontsize=6.2)
        if strong:
            ax.legend(loc='lower left',ncol=3,frameon=False,handlelength=1.1,
                      handletextpad=.35,columnspacing=.7,borderaxespad=.2,fontsize=6.1)
        if i==2:
            ax.set_ylabel('Normalized flux',labelpad=3)
    title(axes[0],r'(a) Iron-group absorption profiles',lift=1.10)
    fig.text(.279,.074,'Heliocentric velocity (km s$^{-1}$)',ha='center',fontsize=7.7)


def blend(fig, grid):
    t=pd.read_csv(DATA/'blend_profiles.csv')
    a=fig.add_subplot(grid[0]); b=fig.add_subplot(grid[1],sharex=a); r=fig.add_subplot(grid[2],sharex=a)
    w=t.air_A
    a.plot(w,t.observed,color='#3a444b',lw=.67,label='HDS')
    a.plot(w,t.joint,color='#c24d39',lw=.95,label='Joint fit')
    a.axhline(t.floor.iloc[0],ls=':',lw=.57,color='#84949f')
    a.legend(loc='upper right',frameon=False,ncol=2,handlelength=1.45,
             columnspacing=.8,borderaxespad=.24)
    a.set(ylim=(.68,1.075),ylabel='Norm. flux')
    a.set_yticks([.7,.8,.9,1])
    for key,color,lab in [('be3130',BE_BLUE,r'$^7$Be II 3130'),
                          ('be3131',BE_RED,r'$^7$Be II 3131'),
                          ('cr3132','#177c67','Cr II 3132')]:
        b.plot(w,1-t[key],lw=.83,color=color,label=lab)
    b.legend(loc='upper right',frameon=False,ncol=3,handlelength=1.15,columnspacing=.65,
             borderaxespad=.2,handletextpad=.35,fontsize=6.1)
    b.set(ylim=(-.014,.355),ylabel='Depth')
    b.set_yticks([0,.15,.30])
    r.plot(w,t.observed-t.joint,color='#47525a',lw=.65)
    r.axhline(0,color='#95a0a7',lw=.5)
    r.set(xlabel=r'Heliocentric air wavelength (Å)',ylabel='Residual',
          ylim=(-.068,.068),xlim=(3119.46,3122.42))
    r.set_yticks([-.05,0,.05])
    r.xaxis.set_major_locator(MultipleLocator(.5))
    r.xaxis.set_major_formatter(ScalarFormatter(useOffset=False))
    for sub in (a,b,r):
        sub.axvline(3119.71091,ls=':',lw=.5,color='#8292a0',zorder=.7)
        sub.axvspan(3121.47,3121.53,color='#eddcb8',alpha=.55,zorder=0)
        sub.yaxis.set_label_coords(-.113,.5)
    for sub in (a,b):
        sub.tick_params(labelbottom=False)
    title(a,r'(b) $^7$Be II and Cr II decomposition',lift=1.12)


def curve(log_tau,profile,weight,covering):
    return covering*(-np.expm1(-10**log_tau[:,None]*profile))@weight


def cog(fig, grid):
    t=pd.read_csv(DATA/'cog_lines.csv')
    diag=pd.read_csv(DATA/'cog_diagnostics.csv')
    templates=pd.read_csv(DATA/'cog_templates.csv')
    fit=pd.read_csv(DATA/'cog_fit.csv').iloc[0]
    a=fig.add_subplot(grid[0]); r=fig.add_subplot(grid[1],sharex=a)
    lK=np.log10(K)
    z=np.linspace(-.29,3.5,333)
    v=templates.velocity_kms.to_numpy()/C
    doppler=np.sqrt((1+v)/(1-v))
    d=np.diff(doppler)
    weights=np.r_[d[0]/2,(d[:-1]+d[1:])/2,d[-1]/2]/np.sqrt((1+np.mean(v))/(1-np.mean(v)))
    for ion in ['Fe II','Ti II','Cr II','Mn II']:
        g=t[t.ion.eq(ion)]
        color=COLORS[ion]
        a.plot(z,np.log10(curve(z,templates[ion].to_numpy(),weights,fit.covering)),
               color=color,lw=.76,alpha=.8)
        x=g.log_strength+lK
        a.scatter(x,g.log_measured_W_over_lambda,s=12,edgecolors=color,facecolors='white',lw=.7,zorder=4)
        a.scatter(x,g.log_model_W_over_lambda,s=4.0,color=color,zorder=5)
        r.scatter(x,g.residual_obs_minus_model_dex,s=11,edgecolors=color,facecolors='white',lw=.7,zorder=4)
    for q in diag.itertuples():
        x,y=q.log_strength+lK,q.log_marker_W_over_lambda
        if q.label.startswith('Ca'):
            a.scatter(x,y,marker='s',s=22,edgecolors=CA,facecolors='white',lw=.9,zorder=6)
            a.scatter(x,q.log_model_W_over_lambda,marker='s',s=5.5,color=CA,zorder=7)
            if q.label=='Ca II H':
                a.vlines(x,y,q.log_model_W_over_lambda,linestyle=':',color=CA,lw=.8)
                r.scatter(x,y-q.log_model_W_over_lambda,marker='s',s=16,edgecolors=CA,
                          facecolors='white',lw=.8,zorder=5)
            a.annotate(q.label,(x,y),xytext=(4,-9),textcoords='offset points',color=CA,fontsize=6.8)
        else:
            blue=q.label.endswith('3130')
            color=BE_BLUE if blue else BE_RED
            a.scatter(x,y,marker='D',s=21,color=color,zorder=6)
            a.annotate('',xy=(x+.32,y),xytext=(x+.05,y),
                       arrowprops={'arrowstyle':'->','lw':.6,'ls':'--','color':color})
            a.annotate(r'$^7$Be II '+q.label[-4:],(x,y),xytext=(-4,-11) if blue else (-4,9),
                       textcoords='offset points',ha='right',color=color,fontsize=6.8)
    ions=['Fe II','Ti II','Cr II','Mn II']
    handles=[Line2D([],[],marker='o',markersize=3.1,markerfacecolor='white',
                    markeredgecolor=COLORS[i],lw=0,label=i) for i in ions]
    species_legend=a.legend(handles=handles,loc='lower right',ncol=4,frameon=False,
                            handletextpad=.15,handlelength=.63,columnspacing=.7,borderaxespad=.25)
    a.add_artist(species_legend)
    ew_key=[
        Line2D([],[],marker='o',markersize=4.1,markerfacecolor='white',
               markeredgecolor='#4a5056',lw=0,label='Measured EW'),
        Line2D([],[],marker='o',markersize=2.6,color='#4a5056',lw=0,label='Model EW'),
    ]
    a.legend(handles=ew_key,loc='upper left',frameon=False,handlelength=.8,
             handletextpad=.35,borderaxespad=.45,labelspacing=.28)
    a.text(.98,.19,rf'$C_f=0.275$;  $T_{{\rm ex}}={fit.Tex_K:,.0f}$ K',
           transform=a.transAxes,ha='right',va='bottom',fontsize=6.6)
    a.set(ylabel=r'$\log_{10}(W_\lambda/\lambda)$',ylim=(-6.08,-4.00),xlim=(z[0],z[-1]))
    a.tick_params(labelbottom=False)
    r.axhline(0,color='#8a979d',lw=.55)
    r.set(xlabel=r'$\log_{10}[\int\tau(v)\,dv\;/\;(\mathrm{km\,s^{-1}})]$',
          ylabel='EW residual\n(dex)',ylim=(-.34,.32))
    r.set_yticks([-.25,0,.25])
    r.xaxis.set_major_locator(MultipleLocator(.5))
    for sub in (a,r):
        sub.grid(axis='y',color='#e8ecf0',lw=.55)
        sub.yaxis.set_label_coords(-.113,.5)
    title(a,'(c) Empirical curve of growth',lift=1.12)


def main():
    style()
    fig=plt.figure(figsize=(180/25.4,165/25.4))
    outer=fig.add_gridspec(1,2,left=.072,right=.984,bottom=.125,top=.86,wspace=.32,
                           width_ratios=[1.,1.04])
    left=outer[0].subgridspec(3,2,wspace=.18,hspace=.30)
    right=outer[1].subgridspec(2,1,height_ratios=[1.02,1],hspace=.43)
    iron(fig,left)
    blend(fig,right[0].subgridspec(3,1,height_ratios=[2.,1.18,.77],hspace=.10))
    cog(fig,right[1].subgridspec(2,1,height_ratios=[2.8,1],hspace=.10))
    fig.text(.073,.973,'V339 Del, +38 d from optical maximum',
             ha='left',va='top',fontsize=12,weight='bold')
    for ext in ('pdf','png'):
        fig.savefig(ROOT/f'V339Del_38d_profiles_Be_CoG.{ext}',dpi=300)


if __name__=='__main__':
    main()
