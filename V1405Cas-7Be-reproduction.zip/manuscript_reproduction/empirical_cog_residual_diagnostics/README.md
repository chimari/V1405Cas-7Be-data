# Empirical curve-of-growth residual diagnostics

V1405 Cas manuscript figure with LaTeX label `cogres`. The input contains the fields used for plotting from the saved 118-primary-line empirical CoG at covering fraction 0.8 and excitation temperature 12146 K. The full sample is checked, while Fe II, Ti II and Cr II appear in the plot.

Run with Python 3.11 or later:

```sh
python -m pip install -r requirements.txt
python render_cog_residuals.py
```

The script checks the residual sign, line counts and full-sample rms (0.0853 dex). It writes a PDF and a CSV with within-ion Spearman coefficients and rms values. `reference_plot.pdf` is the manuscript graphic, and `reference_statistics.csv` contains the archived statistics. The calculations start from the saved measured and model reduced widths.
