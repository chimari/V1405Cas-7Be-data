"""Plot residuals from the saved 118-line empirical curve of growth."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

here = Path(__file__).resolve().parent
points = pd.read_csv(here / "primary_CoG_points.csv")
assert len(points) == 118 and points.ID.is_unique
np.testing.assert_allclose(points.residual_dex,
    points.observed_log_Wrest_over_lambda - points.model_log_Wrest_over_lambda, atol=1e-12)
assert np.isclose(np.sqrt(np.mean(points.residual_dex**2)), .08530213724303641)

plt.rcParams.update({"font.size": 10, "pdf.fonttype": 42})
fig, axes = plt.subplots(2, 3, figsize=(9.5, 5.4), sharey=True, layout="constrained")
ions = [("Fe II", "#276bad", 38), ("Ti II", "#ca7937", 35), ("Cr II", "#35946c", 36)]
fields = [("Elow_eV", "Lower-level energy (eV)"),
          ("model_log_Wrest_over_lambda", r"$\log_{10}(W_{\rm model}/\lambda)$")]
statistics = []
for col, (ion, color, count) in enumerate(ions):
    data = points.loc[points.ion.eq(ion)]
    assert len(data) == count
    y = data.residual_dex
    axes[0, col].set_title(f"{ion} ({count} lines)")
    for row, (field, label) in enumerate(fields):
        ax = axes[row, col]
        x = data[field]
        rho = spearmanr(x, y).statistic
        statistics.append({"ion": ion, "lines": count, "x": field, "spearman_rho": rho,
                           "rms_dex": np.sqrt(np.mean(y**2))})
        ax.axhline(0, color=".52", lw=.8)
        ax.scatter(x, y, color=color, s=20, edgecolors="white", linewidths=.3, alpha=.88, zorder=3)
        fit_x = np.array([x.min(), x.max()])
        ax.plot(fit_x, np.polyval(np.polyfit(x, y, 1), fit_x), color=color, ls="--", lw=1.1)
        ax.text(.04, .95, rf"$\rho_{{\rm S}} = {rho:+.2f}$", transform=ax.transAxes,
                va="top", bbox={"facecolor":"white","edgecolor":"none","pad":1.5}, zorder=5)
        ax.set(xlabel=label, ylim=(-.32, .32))
        ax.set_yticks([-.2, -.1, 0, .1, .2])
        ax.grid(axis="y", alpha=.18)
        ax.spines[["top","right"]].set_visible(False)
        if row == 1:
            ax.set_xlim(-5.9, -3.75)
        if col == 0:
            ax.set_ylabel(r"$\log_{10}(W_{\rm obs}/W_{\rm model})$")
assert points.residual_dex.abs().max() < .32
assert points.loc[points.ion.isin([row[0] for row in ions]),fields[1][0]].between(-5.9,-3.75).all()
pd.DataFrame(statistics).to_csv(here / "empirical_cog_residual_statistics.csv", index=False)
fig.savefig(here / "empirical_cog_residual_diagnostics.pdf")
