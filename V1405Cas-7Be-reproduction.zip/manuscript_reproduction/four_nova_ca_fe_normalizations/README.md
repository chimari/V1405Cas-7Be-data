# Calcium and iron normalizations (Table 13)

LaTeX label `tab:ca-fe-normalizations`. This
[CSV](ca_fe_normalizations.csv) follows the precision printed in
the manuscript. It tabulates the ionic-ratio change, the inverse
ionization correction, and the calcium mass-normalization factor
whose product gives the thin-EW to CoG plus Cloudy mass-fraction
ratio. Slab and effective [Ca/Fe] use the common solar scale.
Empty cells preserve the unresolved V2944 Oph elemental result.

The `sources/` files provide the model and ionic-ratio summaries.
The [observed ionic ratios](../four_nova_ion_ratios/ionic_ratios.csv)
and [mass fractions](../four_nova_mass_fractions/be_mass_fraction_comparison.csv)
are the companion tables.
