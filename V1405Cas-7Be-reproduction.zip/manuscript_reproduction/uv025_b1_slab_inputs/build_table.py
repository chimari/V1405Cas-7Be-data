import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
HEADER = '\\begin{table}[t]\n\\caption{Inputs to the UV025 B1 reference slab.}\n\\label{tab:cloudy-grid}\n\\centering\\small\n\\begin{tabular}{lr}\n\\hline\nQuantity & Adopted value\\\\\n\\hline\n'
FOOTER = '\\hline\n\\end{tabular}\n\\end{table}\n'
LABELS = ['$\\log_{10}(T_{\\rm src}/{\\rm K})$', '$\\log_{10}[\\Phi({\\rm H})/({\\rm cm^{-2}\\,s^{-1}})]$', '$\\log_{10}[n_{\\rm H}/({\\rm cm^{-3}})]$', '$\\log_{10}(r/{\\rm cm})$', '$\\log_{10}({\\rm Fe/H})$', 'Fe II stopping $\\log_{10}[N/({\\rm cm^{-2}})]$', 'Turbulence (km s$^{-1}$)', 'Cloudy iterations']

def main():
    model = (HERE / 'model.in').read_text()
    assert len(re.findall(r'^(?:interpolate|continue)\s', model, re.M)) == 2564

    def number(command):
        match, = re.findall('^' + re.escape(command) + r'\s+([-\d.]+)\b', model, re.M)
        return float(match)

    values = [
        '4.15',  # Parent blackbody of the tabulated UV025 spectrum.
        f"{number('phi(H)'):.6f}",
        f"{number('hden'):.2f}",
        f"{number('radius'):.8f}",
        f"${number('element abundance iron'):.2f}$",
        f"""{number('stop column density "Fe+"'):.4f}""",
        f"{number('turbulence'):.4f}",
        f"{number('iterate'):.0f}",
    ]
    print(HEADER, end='')
    for label, value in zip(LABELS, values, strict=True):
        print(f'{label} & {value}' + r'\\')
    print(FOOTER, end='')

if __name__ == '__main__':
    main()
