# UV025 B1 reference slab inputs

Reproduction of the manuscript table with LaTeX label `tab:cloudy-grid`. Run `python3 build_table.py > rebuilt.tex` and compare with `slab_inputs.tex`.

`model.in` is the exact Cloudy C25.00 input from the returned UV025 B1 recheck. Its incident spectrum is embedded as 2564 interpolation nodes. The parent blackbody temperature, log10(T/K) = 4.15, is documented in the manuscript's UV025 spectrum definition and supplied explicitly in the table builder. The other seven entries are read from the input commands. This package rebuilds the table from those inputs.
