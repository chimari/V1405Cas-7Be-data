# Cloudy data for the UV025 B1 input

The model uses [Cloudy C25.00](https://gitlab.nublado.org/cloudy/cloudy/-/tags/c25.00)
at source revision `fb07fa7142af77846af521753622453fb551bef7`.
`cloudy_data_sha256.json` records the checksums from the calculation.
The `cloudy_overlays/` hierarchy is relative to the Cloudy data root.
It contains the V1405 Cas Stout masterlist and the named Cr II radiative
data based on Lawler et al. (2017). For the named Cr II dataset, copy the
verified installed default `cr_2.nrg` and `cr_2.coll` under the
names `cr_2_v1405_lsne2017_20261021.nrg` and
`cr_2_v1405_lsne2017_20261021.coll` beside the custom transition file.
The checksum inventory gives both names for each identical file.
Verify against it after installing the additional data.
