# V1405 Cas Fe II covering-fraction diagnostic

Manuscript figure with LaTeX label `cover`. The reference PDF is byte-identical to the manuscript figure and to the PDF inside the verified reproduction archive. The caption is from the current manuscript.

Open [the existing support archive](../../Appendix_covering_uncertainties/appendix_cover_errors.zip) and extract its nested `V1405Cas_FeII_triplet_covering_package.zip`. In the extracted `FeII_triplet_covering_20261029` directory, run `python analyze.py` with NumPy, pandas, SciPy and Matplotlib. The package includes the normalized input profiles, analysis code and saved core-flux diagnostics for Fe II 4924, 5018 and 5169. The common-covering fit is descriptive and the core-based lower bound assumes a uniform background.

This entry verifies archive integrity and the identity of the reference PDF. The analysis was not rerun for this preservation check.
