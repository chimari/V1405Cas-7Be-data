"""Reproduce the UV025 B1 calcium rate budget from the Cloudy C25.00 return."""
import json
from io import TextIOWrapper
from pathlib import Path
import re
from zipfile import ZipFile

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
HEADER = re.compile(r" Ca ion_solver .*? nz(\d+)\.\d+ Te(\S+) ne(\S+) .* Search\? ([TF])")
ROW = re.compile(r" Ca (.*?)\s{2,}([-+\d].*)$")
IONIZATION = {
    "photoionization": ["Photoion snk"],
    "electron_impact": ["Coll ioniz"],
    "secondary_ionization": ["Secon ioniz"],
    "charge_transfer_ionization": ["ion xfr mol", "chr trn ion"],
    "other_ionization": ["UTA ioniz", "ion on grn"],
}
RECOMBINATION = {
    "radiative_recombination": ["radiati rec"],
    "three_body_recombination": ["CotaRate rec"],
    "badnell_dielectronic_recombination": ["drBadnel rec"],
    "charge_transfer_recombination": ["rec xfr mol", "chr trn rec"],
    "grain_recombination": ["rec on grn"],
}


def read_final_solver_blocks(stream):
    """Keep the last non-search block for each zone in the final iteration."""
    blocks = {}
    for line in stream:
        if line.startswith("   Calculation stopped because"):
            if "Iteration 8 of 8" in line and "Fe+ column dens reached" in line:
                return blocks
            blocks.clear()
        match = HEADER.match(line)
        if match is None:
            continue
        zone, te, ne, search = match.groups()
        if search == "T" or int(zone) == 0:
            continue
        values = {}
        for row in stream:
            label, numbers = ROW.match(row).groups()
            values[label] = np.array(numbers.split(), dtype=float)
            if label == "Abun [cm-3]":
                break
        blocks[int(zone)] = (float(te), float(ne), values)
    raise ValueError("Final Fe II stopping condition not found in solver trace")


def plot_budget(x, edges, limits, ca, be, structure, rates):
    fig, (top, middle, bottom) = plt.subplots(
        3, 1, figsize=(6.3, 5.8), sharex=True, layout="constrained"
    )
    for ax in (top, middle, bottom):
        ax.axvspan(*limits, color="#e9eef3", zorder=0)
        ax.set_xlim(0, edges[-1])
    top.set_yscale("log")
    top.plot(x, ca[:, 8], color="#943f24", label="Ca II total ionization")
    top.plot(x, ca[:, 9], color="#245884", label="Ca III total recombination")
    top.plot(x, be[:, 9], color="#416b47", linestyle="--", label="Be III total recombination")
    top.set_ylabel(r"Rate per ion (s$^{-1}$)")
    top.legend(loc="center right", frameon=False, fontsize=9)
    middle.plot(x, rates["radiative_recombination"] / ca[:, 9],
                color="#245884", label="Radiative")
    middle.plot(x, rates["three_body_recombination"] / ca[:, 9],
                color="#943f24", linestyle="--", label="Three-body")
    middle.set_ylim(0, 1)
    middle.set_ylabel("Ca III recombination\nfraction")
    middle.legend(loc="upper center", ncols=2, frameon=False, fontsize=9)
    bottom.set_yscale("log")
    bottom.plot(x, structure[:, 1] / structure[:, 2], color="#943f24",
                label=r"$n({\rm Ca\,II})/n({\rm Ca\,III})$")
    bottom.plot(x, ca[:, 9] / ca[:, 8], color="#20252a", linestyle="--",
                linewidth=1.2, label="Total recombination / ionization")
    bottom.set_xlabel(r"H column from illuminated face ($10^{22}\ {\rm cm}^{-2}$)")
    bottom.set_ylabel("Ratio")
    bottom.legend(loc="upper right", frameon=False, fontsize=9)
    fig.savefig(ROOT / "UV025_B1_Ca_rate_budget.pdf")


def main():
    with ZipFile(ROOT / "V1405Cas_Ca_rate_components_return.zip") as archive:
        status = json.loads(archive.read("status.json"))
        assert status["version_ok"] and status["feii_stop"] and status["normal_exit"]
        with TextIOWrapper(archive.open("Ca_rate_arrays.txt")) as stream:
            blocks = read_final_solver_blocks(stream)
        ca, be, structure, overview, columns, ca_levels = (
            np.loadtxt(archive.open(f"model.{suffix}"))
            for suffix in ("ca_rates", "be_rates", "ca_structure", "ovr", "ions", "ca2col")
        )
        density = 10**float(re.search(
            r"^hden\s+(\S+)", archive.read("model.in").decode(), re.M
        )[1])

    depth = overview[:, 0]
    for arr in (ca, be, structure):
        np.testing.assert_array_equal(depth, arr[:, 0])
    assert sorted(blocks) == list(range(1, len(depth) + 1))
    te, ne, data = zip(*(blocks[zone] for zone in sorted(blocks)))
    np.testing.assert_array_equal(te, overview[:, 1])
    np.testing.assert_array_equal(ne, overview[:, 4])
    for column, label, idx in ((structure[:, 1], "Abun [cm-3]", 1),
                               (structure[:, 2], "Abun [cm-3]", 2),
                               (ca[:, 8], "Ioniz total", 1), (ca[:, 9], "Recom total", 1)):
        np.testing.assert_allclose([row[label][idx] for row in data], column, rtol=.005)

    edges = np.r_[0., (depth[1:] + depth[:-1]) / 2, columns[:2].sum() / density]
    width = np.diff(edges)
    assert np.all(width > 0)
    cumulative = np.r_[0., np.cumsum(structure[:, 3] * width)]
    np.testing.assert_allclose(cumulative[-1], ca_levels[0], rtol=.002)
    limits = np.interp([.1, .9], cumulative / cumulative[-1], edges)
    middle_width = np.maximum(0., np.minimum(edges[1:], limits[1])
                              - np.maximum(edges[:-1], limits[0]))

    zone_table = {
        "zone": sorted(blocks), "depth_cm": depth, "H_column_cm-2": depth * density,
        "width_cm": width, "width_in_central_80pct_cm": middle_width,
        "Te_K": te, "ne_cm-3": ne, "CaII_cm-3": structure[:, 1],
        "CaIII_cm-3": structure[:, 2], "CaII_ground_cm-3": structure[:, 3],
        "CaII_total_ionization_s-1": ca[:, 8], "CaIII_total_recombination_s-1": ca[:, 9],
        "BeII_total_ionization_s-1": be[:, 8], "BeIII_total_recombination_s-1": be[:, 9],
    }
    rates = {}
    summaries = []
    for channels, total, parent in ((IONIZATION, ca[:, 8], structure[:, 1]),
                                     (RECOMBINATION, ca[:, 9], structure[:, 2])):
        components = {
            name: np.array([sum(row[key][1] for key in keys) for row in data])
            for name, keys in channels.items()
        }
        rates.update(components)
        residual = total - sum(components.values())
        np.testing.assert_allclose(residual / total, 0., atol=.004)
        for name, rate in {**components, "unaccounted_" + next(iter(channels)) + "_budget": residual}.items():
            zone_table[f"{name}_s-1"] = rate
            whole, central = (np.dot(parent * w, rate) / np.dot(parent * w, total)
                              for w in (width, middle_width))
            summaries.append((name, whole, central))
    pd.DataFrame(zone_table).to_csv(ROOT / "zone_components.csv", index=False)
    pd.DataFrame(summaries, columns=["process", "full_slab_fraction", "central_80pct_fraction"]).to_csv(
        ROOT / "integrated_components.csv", index=False
    )
    hydrogen_scale = density / 1e22
    plot_budget(depth * hydrogen_scale, edges * hydrogen_scale, limits * hydrogen_scale,
                ca, be, structure, rates)


if __name__ == "__main__":
    main()
