# UV025 B1 calcium rate budget (Figure 22)

LaTeX label `fig:total-rates`. Install the dependencies in
`requirements.txt` and run `python analyze_components.py` to reproduce
the [figure](reference_plot.pdf) and the two CSVs from the archived
Cloudy return. The script writes `UV025_B1_Ca_rate_budget.pdf`.
The returned Cloudy C25.00 run adds a trace of the Ca solver arrays to
the reference input. The script uses the last non-search solver array
for each zone in iteration 8 and checks it against the independently
saved final-zone rates, densities, and temperatures.

`zone_components.csv` gives rates per parent ion and the two sets of depth
weights. `integrated_components.csv` gives fractions of the corresponding
saved total, integrated over the full slab and over the interval between
the 10th and 90th percentiles of the Ca II ground-level column. Integration
uses the Ca II density for ionization and the Ca III density for recombination.
The signed residual retains the rounding mismatch with the saved totals.

For ionization the selected solver column refers to losses from Ca II.
For recombination it refers to transitions from the next higher charge
into Ca II. The `CotaRate rec` row is the three-body term, as documented in
Cloudy's [rate-array output](https://data.nublado.org/doxygen/c17.03/ion__solver_8cpp_source.html)
and [recombination routine](https://data.nublado.org/doxygen/c17.03/ion__recomb_8cpp_source.html).
The photoionization and Auger source rows are diagnostics of ion production,
so the script does not add them to the photoionization loss term.

The five coefficient trials in section 7.1 and appendix 8 are archived with their
[inputs, outputs and diagnostic summary](ca_iii_recombination_sensitivity/README.md).
