# UV025 B1 Ca III recombination sensitivity

The input and returned archives contain the five Cloudy C25.00 cases
underlying section 7.1 and appendix 8 of the 2026-11-26 manuscript.
The run instructions and source patch are in the input archive.
The public return preserves the model inputs, numerical outputs and provenance hashes.
`verified_summary.csv` records the Fe I, Fe II and Balmer diagnostics,
`K_g` and the abundance conversions recomputed from the saved outputs.

The calculation varies the radiative and three-body Ca III coefficients
separately by ±50 per cent with the other B1 settings fixed. All five
runs pass the diagnostics. The radiative trials shift `K_g` by −30.2 and
+32.6 per cent, and the three-body trials by −22.3 and +23.8 per cent.
Applying these corrections to the adopted ionic ratio gives
observing-epoch Be/Ca of (5.13–9.75) × 10⁻⁵.
