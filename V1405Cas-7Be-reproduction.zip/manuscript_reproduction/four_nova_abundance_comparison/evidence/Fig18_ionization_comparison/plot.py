"""Plot the Fe-normalized Be, decay-corrected daughter-Li, Ti and Cr comparisons."""
import csv
import re
import statistics
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import LogLocator, NullFormatter

from ti_cr_elements import derive

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
EVIDENCE = ROOT / "evidence"
LABELS = ["V1405 Cas", "V5668 Sgr", "V2944 Oph", "V339 Del"]
HALF_LIFE_D = 53.22


def read_csv(path):
    with path.open() as stream:
        return list(csv.DictReader(stream))


def reference(path, model):
    return next(row for row in read_csv(EVIDENCE / path) if row["model"] == model)


def make_points():
    slots = {
        "V5668 Sgr": reference("V5668Sgr_Vnorm_ionization/summary.csv", "vnorm_d1p54"),
        "V2944 Oph": reference("V2944Oph_ionization/density_scan.csv", "oph_V1405shape_n10p25"),
        "V339 Del": reference("V339Del_STIS_ionization/summary.csv", "hds47_STIS_shape"),
    }
    points = {}
    for row in read_csv(HERE / "observed_befe.csv"):
        nova = row["nova"]
        ion_ratio = 10**float(row["log_ionic_Be_over_Fe"])
        days = float(row["days_from_discovery"])
        if nova == "V1405 Cas":
            # Current manuscript, subsection Empirical-template Be/Ca and
            # daughter-lithium equivalent, at the UV025 B1 Fe/H.
            be_fe = 3.13e-10 / 10**(-4.54)
        else:
            model = slots[nova]
            be_fe = ion_ratio * float(model["FeII_frac"]) / float(model["BeII_ground_frac"])
        points[nova] = dict(nova=nova, days_from_discovery=days,
                            CoG_BeII_ground_over_FeII=ion_ratio,
                            observing_epoch_Be_over_Fe=be_fe,
                            daughter_Li_over_Fe_equivalent=be_fe * 2**(days / HALF_LIFE_D))
    with (HERE / "be_li_fe_comparison.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(points[LABELS[0]]))
        writer.writeheader()
        writer.writerows(points[nova] for nova in LABELS)
    return points


def uncertainty_intervals(points, elements):
    intervals = {}

    def add(nova, quantity, lo, hi, kind):
        intervals[nova, quantity] = (lo, hi, kind)

    cas = "V1405 Cas"
    archived = {row["element"]: row for row in
                read_csv(HERE / "verified_abundance_pattern_points.csv")}
    obs = archived["Be"]
    add(cas, "ionic Be/Fe", 10**float(obs["obs_lo"]), 10**float(obs["obs_hi"]), "conditional")

    li = points[cas]["daughter_Li_over_Fe_equivalent"]
    model_factor = [10**(float(obs[f"cloudy_discovery_{edge}"]) -
                         float(obs["cloudy_discovery"])) for edge in ("lo", "hi")]
    add(cas, "Li/Fe equivalent", *(li*factor for factor in model_factor), "conditional")
    for row in elements:
        if row["nova"] != cas:
            continue
        element = row["element"]
        for field, key in (("ionic_dex", "lte"), ("elemental_dex", "cloudy")):
            center = float(row[field])
            lo, hi = (center + float(archived[element][f"{key}_{edge}"]) -
                      float(archived[element][key] if key == "lte" else
                            archived[element]["cloudy_1040"]) for edge in ("lo", "hi"))
            add(cas, f"{element} {field}", lo, hi, "conditional")

    k_line = next(row for row in read_csv(ROOT / "tables/diagnostic_lines.csv")
                  if row["ID"] == "D03")
    # EW measurement windows are disjoint. Use the archived sideband noise
    # for Ca K and the refitted Be blend realizations.
    ca = float(k_line["EW_rest_mA"])
    fractional_ca_noise = float(k_line["sigma_correlated_mA"]) / ca
    ew_draws = [float(row["EW_3131_mA"]) for row in read_csv(HERE / "paired_be_draws.csv")]
    ew_quantiles = statistics.quantiles(ew_draws, n=100, method="inclusive")
    ew_factors = (1 - ((1 - ew_quantiles[15]/45.69)**2 + fractional_ca_noise**2)**.5,
                  1 + ((ew_quantiles[83]/45.69 - 1)**2 + fractional_ca_noise**2)**.5)

    sgr = "V5668 Sgr"
    controls = read_csv(HERE / "sgr_systematic_controls.csv")
    reference_row = next(row for row in controls if row["case"] == "Cf_0.6")
    be_fixed_fe_controls = [
        row for row in controls
        if row["T_exc_K"] == reference_row["T_exc_K"]
        and row["log_FeII_over_U"] == reference_row["log_FeII_over_U"]
        and row["Be_success"] == "True" and row["Be_shift_bound_hit"] == "False"
    ]
    be_factors = [10**(float(row["log_N_BeII_ground"]) -
                       float(reference_row["log_N_BeII_ground"])) for row in be_fixed_fe_controls]
    ew_trial_factors = [float(row["EW_Be_red_model_mA"]) /
                        float(reference_row["EW_Be_red_model_mA"]) for row in be_fixed_fe_controls]
    for quantity, key in (("ionic Be/Fe", "CoG_BeII_ground_over_FeII"),
                          ("Li/Fe equivalent", "daughter_Li_over_Fe_equivalent")):
        center = points[sgr][key]
        add(sgr, quantity, center*min(be_factors), center*max(be_factors), "profile trial")
    mass_factors = {(cas, "Current EWs, thin limit"): (*ew_factors, "conditional"),
                    (cas, "CoG + Cloudy"): (*model_factor, "conditional"),
                    (sgr, "Current EWs, thin limit"): (
                        min(ew_trial_factors), max(ew_trial_factors), "profile trial"),
                    (sgr, "CoG + Cloudy"): (min(be_factors), max(be_factors), "profile trial")}
    return intervals, mass_factors


def interval_bar(ax, y, interval, color):
    if interval is None:
        return
    lo, hi, kind = interval
    if kind == "profile trial":
        ax.hlines(y, lo, hi, color=color, lw=1.25, linestyle=(0, (2, 2)), zorder=4)
        ax.plot([lo, hi], [y, y], "|", color=color, ms=8, mew=1.1, zorder=4)
    else:
        ax.hlines(y, lo, hi, color=color, lw=1.0, zorder=4)
        ax.plot([lo, hi], [y, y], "|", color=color, ms=8, mew=.85, zorder=4)


def row_labels(ax, separators=False):
    ax.set_ylim(-.56, 3.56)
    ax.set_yticks([3, 2, 1, 0], LABELS)
    ax.spines[["top", "right", "left"]].set_visible(False)
    ax.spines["bottom"].set_color("#63738a")
    ax.tick_params(axis="y", length=0, pad=8)
    ax.tick_params(axis="x", color="#63738a", pad=4)
    ax.grid(axis="x", color="#dde4eb", linewidth=.65)
    ax.set_axisbelow(True)
    if separators:
        for y in (.5, 1.5, 2.5):
            ax.axhline(y, color="#99a9bb", linewidth=.7, linestyle=(0, (2, 3)), zorder=0)


def mass_fraction(cell):
    if cell.strip() == r"\ldots":
        return None, None
    match = re.fullmatch(
        r"\$\(?([\d.]+)(?:\\pm([\d.]+))?\)?\\times10\^\{(-?\d+)\}\$",
        cell.strip(),
    )
    if match is None:
        raise ValueError(f"Unexpected mass-fraction cell: {cell}")
    mantissa, error, exponent = match.groups()
    scale = 10**int(exponent)
    return float(mantissa)*scale, float(error)*scale if error else None


def plot_method_comparison(ax, intervals, mass_factors):
    methods = (
        ("Published EW ratios", "D", "#596271", "white", .22),
        ("Current EWs, thin limit", "^", "#a66016", "white", 0.),
        ("CoG + Cloudy", "s", "#11685e", "#11685e", -.22),
    )
    table = (ROOT / "tables/be_mass_fraction_comparison.tex").read_text()
    rows = {line.split("&", 1)[0].strip(): line.split("&")
            for line in table.splitlines() if "&" in line}
    with (HERE / "method_mass_fractions.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["nova", "method", "discovery_epoch_Be7_mass_fraction", "reported_error"])
        for column, (label, marker, color, fill, offset) in enumerate(methods, start=3):
            for y, nova in zip([3, 2, 1, 0], LABELS):
                value, error = mass_fraction(rows[nova][column])
                writer.writerow([nova, label, value, error])
                if error is not None:
                    intervals[nova, label] = value-error, value+error, "published"
                if (nova, label) in mass_factors:
                    lo, hi, kind = mass_factors[nova, label]
                    intervals[nova, label] = value*lo, value*hi, kind
                if value is not None:
                    interval_bar(ax, y+offset, intervals.get((nova, label)), color)
                    ax.plot(value, y+offset, marker, ms=5.2, mfc=fill,
                            mec=color, color=color, mew=1.15, zorder=5)
            ax.plot([], [], marker, color=color, mfc=fill, mew=1.15,
                    ms=5.5, label={"Published EW ratios": "Published EWs", "Current EWs, thin limit": "Thin EWs"}.get(label, label))

    ax.set_xscale("log")
    ax.set_xlim(3.3e-9, 5.3e-4)
    ax.set_xticks([10.**exponent for exponent in range(-8, -3)])
    ax.xaxis.set_minor_locator(LogLocator(base=10, subs=(2, 5)))
    ax.xaxis.set_minor_formatter(NullFormatter())
    ax.set_xlabel(r"Discovery-epoch $^{7}$Be mass fraction")
    row_labels(ax, separators=True)
    ax.legend(loc="upper center", bbox_to_anchor=(.49, -.45), ncol=2,
              handletextpad=.35, columnspacing=.85, frameon=False, fontsize=7.6)


def plot():
    points = make_points()
    elements = derive()
    intervals, mass_factors = uncertainty_intervals(points, elements)
    plt.rcParams.update({"font.size": 8, "font.family": "DejaVu Sans",
                         "mathtext.fontset": "dejavusans", "pdf.fonttype": 42})
    fig, (be, comparison, metals) = plt.subplots(3, 1, figsize=(3.35, 5.85))
    fig.subplots_adjust(left=.255, right=.975, top=.955, bottom=.139, hspace=1.25)
    ink, observed_color, corrected_color = "#243246", "#315f9b", "#ad4b23"

    be.set_title("(a) Beryllium and lithium", loc="left",
                 fontweight="semibold", fontsize=9, color=ink, pad=5)
    be.set_xscale("log")
    be.set_xlim(6.5e-6, 6.7e-3)
    be.set_xticks([1e-5, 1e-4, 1e-3], [r"$10^{-5}$", r"$10^{-4}$", r"$10^{-3}$"])
    be.xaxis.set_minor_locator(LogLocator(base=10, subs=(2,5)))
    be.xaxis.set_minor_formatter(NullFormatter())
    be.set_xlabel("Number ratio relative to iron")
    row_labels(be)
    for y, nova in zip([3, 2, 1, 0], LABELS):
        row = points[nova]
        ion = row["CoG_BeII_ground_over_FeII"]
        equiv = row["daughter_Li_over_Fe_equivalent"]
        conditional = nova == "V2944 Oph"
        be.plot([ion, equiv], [y, y], color="#acb7c4", lw=1.0,
                ls=(0, (2, 2)) if conditional else "-", zorder=2)
        interval_bar(be, y, intervals.get((nova, "ionic Be/Fe")), observed_color)
        interval_bar(be, y, intervals.get((nova, "Li/Fe equivalent")), corrected_color)
        be.plot(ion, y, "o", color=observed_color, mfc="white", mew=1.4, ms=5.2, zorder=5)
        be.plot(equiv, y, "s", color=corrected_color, mfc="white" if conditional
                else corrected_color, mew=1.4, ms=5, zorder=5)
    be.plot([], [], "o", color=observed_color, mfc="white", mew=1.4,
            label=r"Observed $^{7}$Be II / Fe II")
    be.plot([], [], "s", color=corrected_color, label=r"Daughter $^{7}$Li / Fe")
    be.plot([], [], "s", color=corrected_color, mfc="white", mew=1.4, label="Oph trial")
    be.legend(loc="upper center", bbox_to_anchor=(.49, -.45), ncol=2,
              handletextpad=.35, columnspacing=.85, frameon=False, fontsize=7.6)

    comparison.set_title("(b) Beryllium mass fraction", loc="left",
                         fontweight="semibold", fontsize=9, color=ink, pad=5)
    plot_method_comparison(comparison, intervals, mass_factors)

    metals.set_title("(c) Titanium and chromium", loc="left",
                     fontweight="semibold", fontsize=9, color=ink, pad=5)
    metals.set(xlim=(-1., .4), xticks=[-1., -.75, -.5, -.25, 0, .25],
               xlabel="Solar-normalized number ratio (dex)")
    row_labels(metals, separators=True)
    metals.axvline(0, color="#8a96a7", lw=1.0)
    for element, offset, color, marker in (("Ti", .24, "#1c6378", "o"),
                                          ("Cr", -.24, "#7d508c", "s")):
        rows = {row["nova"]: row for row in elements if row["element"] == element}
        ys = [3-i+offset for i in range(len(LABELS))]
        for field, shift, fill in (("ionic_dex", .092, "white"),
                                   ("elemental_dex", -.092, color)):
            values = [float(rows[nova][field]) for nova in LABELS]
            label = f"{element} II/Fe II" if field == "ionic_dex" else f"{element}/Fe"
            for nova, y in zip(LABELS, ys):
                interval_bar(metals, y+shift, intervals.get((nova, f"{element} {field}")), color)
            metals.plot(values, [y+shift for y in ys], marker=marker, mfc=fill,
                        mec=color, mew=1.2, ls="none", color=color, ms=4.8, label=label, zorder=5)
    metals.legend(loc="upper center", bbox_to_anchor=(.49, -.45), ncol=2,
                  handletextpad=.35, columnspacing=1.2, frameon=False, fontsize=7.6)
    with (HERE / "uncertainty_intervals.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["nova", "quantity", "lower", "upper", "interval_kind"])
        writer.writerows([nova, quantity, *bounds] for (nova, quantity), bounds in intervals.items())
    fig.savefig(ROOT / "fig/comparison_novae_abundance_patterns.pdf")
    fig.savefig(HERE / "preview.png", dpi=150)
    plt.close(fig)


if __name__ == "__main__":
    plot()
