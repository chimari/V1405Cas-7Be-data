"""Build the Ti and Cr comparison from CoG ratios and Cloudy columns."""
import csv
from math import log10
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
MODELS = {
    "V5668 Sgr": ("V5668Sgr_vnorm_d1p54_5iter.out", "16.305879922", "1.54 kpc"),
    "V2944 Oph": ("V2944Oph_n10p25_5iter.out", "13.885540089", "baseline at log nH = 10.25"),
    "V339 Del": ("V339Del_hds47_STIS_shape_5iter.out", "16.240336141", "+47 d STIS shape"),
}


def load_csv(name):
    with (HERE / name).open() as stream:
        return list(csv.DictReader(stream))


def ion_fractions(name, phi):
    text = (HERE / "ionic_columns" / name).read_text()
    assert f"phi(H) {phi}" in text, name
    assert "Iteration 5 of 5" in text and "Cloudy exited OK" in text, name
    section = text[text.rindex("Log10 Column density (cm^-2)"):]
    section = section.split("Log10 Mean Ionisation (over radius)")[0]
    fractions = {}
    for element, word in [("Fe", "Iron"), ("Ti", "Titanium"), ("Cr", "Chromium")]:
        fields = re.search(rf"^ +{word} +([^\n]+)", section, re.M)[1]
        cols = [10**float(x) for x in re.findall(r"[-+]?\d+\.\d+", fields)]
        fractions[element] = cols[1] / sum(cols)
    return fractions


def derive():
    rows = [
        dict(nova="V1405 Cas", element=r["element"], ionic_dex=float(r["ionic_dex"]),
             elemental_dex=float(r["elemental_dex"]), model="UV025 B1",
             log10_fraction_correction="", fraction_X_II="", fraction_Fe_II="")
        for r in load_csv("v1405_ti_cr.csv")
    ]
    fractions = {nova: ion_fractions(name, phi) for nova, (name, phi, _) in MODELS.items()}
    for r in load_csv("ti_cr_ionic_ratios.csv"):
        nova, element = r["nova"], r["element"]
        f = fractions[nova]
        ionic = float(r["solar_normalized_ionic_ratio_dex"])
        corr = log10(f["Fe"] / f[element])
        rows.append(dict(nova=nova, element=element, ionic_dex=ionic, elemental_dex=ionic+corr,
                         model=MODELS[nova][2], log10_fraction_correction=corr,
                         fraction_X_II=f[element], fraction_Fe_II=f["Fe"]))
    with (HERE / "ti_cr_comparison.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return rows


if __name__ == "__main__":
    derive()
