> Earlier reproduction snapshot. The current manuscript Figure 18 and its inputs are in [comparison_novae_abundance_patterns](../comparison_novae_abundance_patterns/README.md).

# Figure 17 (formerly Figure 18)

With Matplotlib installed, run `python evidence/Fig18_ionization_comparison/plot.py` to regenerate
`fig/comparison_novae_abundance_patterns.pdf` and the plotted CSVs.
The observing-epoch points in panel (a) use the CoG Be II ground-level
column divided by the CoG total Fe II column. The V1405 Cas row of `observed_befe.csv` uses the empirical-template
B1 ratio in `verified_abundance_pattern_points.csv` (log Be II ground
column 12.6312 and log CoG total Fe II column approximately 17.1395).
The separate Cloudy Fe II stopping column has log N = 17.5942.
The other rows use the Be entries of `composition_points.csv` in the
comparison-nova abundance data archive.

For the elemental Be/Fe ratio, the V1405 Cas row uses the manuscript
UV025 B1 Be/H divided by the Fe/H adopted in that slab. The other rows
multiply the ionic column ratio by the integrated Fe II fraction divided
by the Be II ground-level fraction in the archived model summaries.
The elapsed times measured from discovery follow the manuscript. The
daughter-Li equivalent is the total Li-7 produced after the inferred
Be-7 inventory at discovery has fully decayed. To infer that inventory,
multiply observing-epoch elemental Be/Fe by 2^(elapsed time / 53.22 d). These are ratios in
the selected absorbers. The V2944 Oph point uses the log nH = 10.25
baseline trial and is marked as conditional.

Panel (b) plots the three estimates of the discovery-epoch Be-7 mass
fraction from `tables/be_mass_fraction_comparison.tex`. The plotting
script exports the values and available published errors to
`method_mass_fractions.csv`. Empty entries mark the unavailable published
V1405 Cas estimate and the unadopted V2944 Oph model-based estimate.

Panel (c) uses the Ti and Cr rows in `ti_cr_ionic_ratios.csv` and
`v1405_ti_cr.csv`. The elemental conversion in `ti_cr_elements.py` uses the
integrated ion columns archived in `ionic_columns/`. The plotted solar
ratios match the manuscript convention.

`uncertainty_intervals.csv` gives every plotted interval, with endpoints
in the units of the corresponding panel. V1405 Cas ratios use the
archived empirical-template B1 16th--84th percentiles. For its thin-EW
mass fraction the Be 3131 EW quantiles from `paired_be_draws.csv` and the
Ca II K sideband noise from `tables/diagnostic_lines.csv` are propagated
in quadrature to first order, treating the two windows as independent.
For its CoG plus Cloudy mass fraction the fractional interval in Be/H
is applied at fixed reference composition and decay factor.

The V5668 Sgr sensitivity intervals come from the archived
`systematic_controls.csv` in `V5668Sgr_CoG_CaK_NaD_reproducibility.zip`,
copied here with the `sgr_` prefix. They use the successful, unbounded
fits at the reference Fe II CoG normalization and excitation. The
ranges cover Be-profile changes at fixed Fe column, Ca II K EW and
ionization correction, including a control with independent Be covering.
They are not confidence intervals or the range of a joint covering-
fraction scan. No uncertainties are extrapolated to the other points.
