# V1405 Cas spectrum overview

Manuscript figure with LaTeX label `overview`. The reference PDF is byte-identical to the current manuscript figure. The reproduction archive is the previously verified package with code and inputs for the 118 primary transitions. Unzip it and follow the included plotting instructions. The separate caption is taken from the current manuscript. This archive preserves the existing reproduction files and records their correspondence to the current figure.

The current reference includes rotated H16 and H15 labels at the −793 km/s LVC positions. Run `python annotate_balmer.py` (PyMuPDF) to apply the labels to `reference_before_balmer_labels.pdf`. The manuscript places the 4-panel figure across the full text area.

