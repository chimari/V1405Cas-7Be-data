"""Add the Balmer LVC markers to the archived vector overview."""
from pathlib import Path
from math import sqrt
import fitz

root = Path(__file__).resolve().parent
with fitz.open(root / "reference_before_balmer_labels.pdf") as doc:
    page = doc[0]
    ticks = {w[4]: (w[0]+w[2])/2 for w in page.get_text("words") if w[4] in ("3700","3800")}
    beta = -793 / 299792.458
    doppler = sqrt((1+beta)/(1-beta))
    color = (.28,.17,.39)
    for label, wavelength in (("H16",3703.82),("H15",3711.94)):
        x = ticks["3700"] + (wavelength*doppler-3700)*(ticks["3800"]-ticks["3700"])/100
        page.draw_line((x,88),(x,108),color=color,width=.8)
        page.insert_text((x+2.4,84),label,fontsize=8.3,fontname="helv",rotate=90,color=color)
    doc.save(root / "overview_rebuilt.pdf", garbage=4, deflate=True)
