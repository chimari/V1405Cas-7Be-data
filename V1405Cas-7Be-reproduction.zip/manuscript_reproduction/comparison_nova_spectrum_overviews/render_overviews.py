from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.ticker import MultipleLocator, MaxNLocator

root=Path(__file__).resolve().parent
out=root/'rendered'
out.mkdir(exist_ok=True)
with (root/'inputs/Three_nova_EW_measurements.csv').open() as f:
    ledger=list(csv.DictReader(f))
objects=[
    (name,key,velocity,[root/'inputs'/f'{key}_{arm}.fits' for arm in ('Ub','Yb')])
    for name,key,velocity in [('V5668 Sgr','V5668Sgr',-786.2),
                              ('V2944 Oph','V2944Oph',-878.),
                              ('V339 Del','V339Del',-1103.)]
]
c=299792.458
colors={'primary':'#2460a0','diagnostic':'#a02d39','context':'#48524a','blue':'#357965'}
balmer=[('Hα',6562.80),('Hβ',4861.33),('Hγ',4340.47),('Hδ',4101.74),
        ('Hε',3970.07),('H8',3889.05),('H9',3835.39),('H10',3797.90)]
helium=[('He I',4471.48),('He I',5875.62),('He I',6678.15)]

def fits_spectrum(p):
    raw=p.read_bytes()
    h={}
    for i in range(0,len(raw),80):
        card=raw[i:i+80].decode('ascii','replace')
        if card[:8].strip()=='END':
            break
        if card[8:10]=='= ':
            h[card[:8].strip()]=card[10:].split('/')[0].strip().strip("'").strip()
    assert int(h['NAXIS'])==1 and int(h['BITPIX'])==-32 and int(h['DC-FLAG'])==0
    n=int(h['NAXIS1'])
    wave=float(h['CRVAL1'])+(np.arange(n)+1-float(h['CRPIX1']))*float(h['CDELT1'])
    flux=np.frombuffer(raw,dtype='>f4',count=n,offset=(i+80+2879)//2880*2880).astype(float)
    good=np.isfinite(flux)&(flux>0)
    scale=np.median(flux[good])
    flux[(flux==0)|~np.isfinite(flux)]=np.nan
    return wave,flux/scale,h['DATE-OBS']

def centers(w,v,key):
    x=v/c
    return w*(1+x) if key=='V5668Sgr' else w*np.sqrt((1+x)/(1-x))

def draw(name,key,vc,paths):
    spectra=dict(zip(('Ub','Yb'),map(fits_spectrum,paths)))
    rows=[r for r in ledger if r['nova']==name]
    expected={r['use'] for r in rows}
    assert 'primary CoG' in expected and len(rows)=={'V5668Sgr':43,'V2944Oph':26,'V339Del':34}[key]
    fig,axs=plt.subplots(4,1,figsize=(8.7,7.3))
    fig.subplots_adjust(left=.105,right=.975,bottom=.096,top=.81,hspace=.63)
    date=spectra['Ub'][2]
    day={'V5668Sgr':69,'V2944Oph':80,'V339Del':47}[key]
    epoch=f' (+{day} d)'
    if key=='V339Del': epoch=' (+47 d from maximum; +48.7 d from discovery)'
    paper='Tajitsu et al. (2015)' if key=='V339Del' else 'Tajitsu et al. (2016)'
    fig.text(.105,.965,f'{name}{epoch}  |  {date} UT',fontsize=12 if key=='V339Del' else 15,weight='bold')
    fig.text(.105,.928,f'Subaru/HDS · {paper} · Days from optical maximum · Reference absorber: {vc:g} km s⁻¹',fontsize=9)
    handles=[Line2D([],[],color=colors['primary'],label='Primary CoG'),
             Line2D([],[],color=colors['diagnostic'],label='Diagnostic'),
             Line2D([],[],color=colors['context'],linestyle=':',label='Balmer / He I rest wavelength')]
    if key=='V339Del':
        handles.append(Line2D([],[],color=colors['blue'],ls='--',label='Blue blend component'))
    fig.legend(handles=handles,ncol=len(handles),loc='upper left',bbox_to_anchor=(.099,.914),
               fontsize=8,frameon=False,handlelength=1.7,columnspacing=1.4)
    seen=set()
    for i,(ax,arm,lo,hi) in enumerate(zip(axs,['Ub','Ub','Yb','Yb'],[3000,3800,4050,5450],[3800,4660,5450,6900])):
        w,f,_=spectra[arm]
        keep=(w>=lo)&(w<hi)
        ax.plot(w[keep],f[keep],color='#182a35',lw=.43,zorder=2,rasterized=True)
        visible=f[keep & np.isfinite(f)]
        upper=max(1.4,1.16*np.quantile(visible,.95))
        lower=min(0.,np.quantile(visible,.005))
        ax.set(xlim=(lo,hi),ylim=(lower,upper),ylabel='Relative flux')
        ax.xaxis.set_major_locator(MultipleLocator(100 if arm=='Ub' else 200))
        ax.yaxis.set_major_locator(MaxNLocator(4))
        ax.grid(axis='y',lw=.4,color='.9')
        ax.tick_params(labelsize=8)
        ax.text(.013,.93,f'({chr(97+i)}) {arm}',transform=ax.transAxes,ha='left',va='top',
                fontsize=8,bbox=dict(facecolor='white',edgecolor='none',pad=1.5),zorder=7)
        entries=[]
        for r in rows:
            if arm not in r['arm']:
                continue
            wl=float(r['rest_air_A'])
            pos=centers(wl,vc,key)
            if not (lo<=pos<hi and w[0]<=pos<=w[-1]):
                continue
            seen.add((r['rest_air_A'],r['ion']))
            role='primary' if r['use']=='primary CoG' else 'diagnostic'
            name=r['transition'] or r['ion']
            if name.startswith('⁷Be'):
                name='⁷Be '+name.split()[-1]
            elif name.startswith(('Ni II','Mn II')):
                name=name.replace(' 3374','').replace(' 3442','')
            entries.append((pos,name,role))
        cr=3132.05663
        if arm=='Ub' and lo<=centers(cr,vc,key)<hi:
            entries.append((centers(cr,vc,key),'Cr II blend','diagnostic'))
            if key=='V339Del':
                for wl in [3130.583557665,3131.228107417,cr]:
                    x=centers(wl,-1268,key)
                    ax.axvline(x,color=colors['blue'],ls='--',lw=.75,zorder=4)
        for label,wl in balmer+helium:
            if lo<=wl<hi and w[0]<=wl<=w[-1]:
                entries.append((wl,label,'context'))
        # Close lines share a label lane only when their projected x coordinates separate.
        # Rotate dense labels and separate their anchors with short leader lines.
        entries.sort()
        spans=hi-lo
        spacing=spans*.012
        coords=np.array([x for x,_,_ in entries])
        display=coords.copy()
        for k in range(1,len(display)):
            display[k]=max(display[k],display[k-1]+spacing)
        if len(display) and display[-1]>hi-spacing:
            display[-1]=hi-spacing
            for k in range(len(display)-2,-1,-1):
                display[k]=min(display[k],display[k+1]-spacing)
        for x,(pos,label,role) in zip(display,entries):
            color=colors[role]
            style=':' if role=='context' else '-'
            ax.axvline(pos,color=color,ls=style,lw=.63 if role=='primary' else .8,
                       alpha=.64 if role=='primary' else .85,zorder=3 if role=='primary' else 4)
            trans=ax.get_xaxis_transform()
            ax.plot([pos,x],[1.,1.068],transform=trans,color=color,lw=.46,clip_on=False)
            ax.text(x,1.077,label,transform=trans,rotation=90,fontsize=6.1,ha='center',
                    va='bottom',color=color,clip_on=False)
    axs[-1].set_xlabel('Observed air wavelength (Å)',fontsize=9)
    fig.text(.105,.025,'Flux scaled by the median positive flux in each setting. Strong emission peaks may extend above the panels.',fontsize=7.5,color='.28')
    missing={(r['rest_air_A'],r['ion']) for r in rows}-seen
    print(key,'ledger',len(rows),'plotted',len(seen),'missing',missing,
          'coverage',[(a,round(x[0]),round(x[-1])) for a,(x,*_) in spectra.items()])
    assert not missing
    fig.savefig(out/f'{key}_spectrum_overview.pdf',dpi=250)
    return fig

with PdfPages(out/'Three_nova_spectrum_overviews.pdf') as pages:
    for obj in objects:
        fig=draw(*obj)
        pages.savefig(fig,dpi=250)
        plt.close(fig)
