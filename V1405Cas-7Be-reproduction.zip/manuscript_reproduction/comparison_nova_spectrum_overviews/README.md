# Full Subaru/HDS spectra of the three comparison novae

Supplementary spectrum overviews for V5668 Sgr, V2944 Oph, and V339 Del. The individual PDFs and combined PDF are included. To reproduce the figures, extract the three spectra ZIPs here and run `python render_overviews.py` with NumPy and Matplotlib. The input FITS spectra and line-marker catalog reproduce the adopted overview plots.

The first two spectra are those used by Tajitsu et al. (2016), at +69 and +80 days from optical maximum. The V339 Del spectrum is the observation used by Tajitsu et al. (2015) at +47 days from maximum (+48.7 days from discovery).
