from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

here = Path(__file__).resolve().parent
scan = pd.read_csv(here / 'covering_scan.csv')
cloudy = pd.read_csv(here / 'summary.csv')
fig, (cols, ratios) = plt.subplots(2, 1, sharex=True, figsize=(3.45, 3.55),
                                   constrained_layout=True)
for background, color in [('B1', '#245c91'), ('B0', '#ad5429')]:
    trials = scan[scan.background == background]
    models = cloudy[cloudy.background == background]
    below = trials.Be_flux_samples_below_covering_floor > 0
    for ax, field in [(cols, 'logN_BeII'), (ratios, 'ionic_ratio')]:
        ax.plot(trials.Cf, trials[field], color=color, label=f'Be, {background}'
                if ax is cols else background)
        ax.scatter(trials.Cf[below], trials[field][below], s=12, facecolors='white',
                   edgecolors=color, linewidths=0.7, zorder=3)
        ax.scatter(models.Cf, models[field], s=22, marker='D',
                   color=color, edgecolors='white', linewidths=0.5, zorder=4)
ca = scan[scan.background == 'B1']
cols.plot(ca.Cf, ca.logN_CaII, '--', color='0.25', label='Ca H/K')
cols.scatter(cloudy.Cf, cloudy.logN_CaII, s=20, marker='D', color='0.25',
             edgecolors='white', linewidths=0.5, zorder=4)
cols.set_ylabel(r'$\log_{10}(N_g/{\rm cm}^{-2})$', fontsize=8.5)
ratios.set_ylabel(r'$N_g(^{7}{\rm Be\,II})/N_g({\rm Ca\,II})$', fontsize=8.5)
ratios.set_xlabel(r'Common covering fraction $C_f$', fontsize=8.5)
cols.legend(loc='upper right', fontsize=6.5, frameon=False)
ratios.legend(loc='lower right', fontsize=6.5, frameon=False)
for ax, tag in [(cols, '(a)'), (ratios, '(b)')]:
    ax.text(0.025, 0.93, tag, transform=ax.transAxes, va='top', fontsize=7)
    ax.axvline(0.8, color='0.65', lw=0.7, ls=':')
    ax.tick_params(labelsize=7, direction='in')
fig.savefig(here / 'covering_sensitivity.pdf')
