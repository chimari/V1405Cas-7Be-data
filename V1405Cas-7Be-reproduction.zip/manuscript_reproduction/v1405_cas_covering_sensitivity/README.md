# V1405 Cas covering-fraction sensitivity (Figure 15)

LaTeX label `fig:covering-sensitivity`. The [figure](reference_plot.pdf)
shows the fixed-template B0 and B1 profile trials in
[covering_scan.csv](covering_scan.csv) and the Cloudy trials listed in
[summary.csv](summary.csv) and in manuscript table `tab:covering-cloudy`.
The open circles flag flux samples below the adopted covering floor.

Install the dependencies in `requirements.txt`, then run the renderer.

    MPLBACKEND=Agg python plot_covering.py

The script writes `covering_sensitivity.pdf` beside the two CSVs.
