# V1405 Cas ThAr wavelength calibration and resolving power

Manuscript table with LaTeX label `tab:thar`. Run `python3 build_table.py > rebuilt.tex` and compare with `calibration.tex`.

The CSV transcribes the detector-level statistics from the current manuscript. It records the internal wavelength-fit rms, number of selected lamp lines, and the 16th, 50th and 84th percentiles of resolving power. The original lamp profiles and per-line width measurements were not located in the materials checked. This package reproduces the table from the reported statistics.
