import csv
from pathlib import Path

HERE = Path(__file__).resolve().parent
HEADER = '\\begin{table}[t]\n\\caption{Internal wavelength calibration and ThAr resolving power.}\n\\label{tab:thar}\n\\centering\\small\n\\begin{tabular}{lrrr}\n\\hline\nDetector & $\\sigma_\\lambda$ (\\AA) & $n$ & $R_{50}$ [$R_{16}$--$R_{84}$]\\\\\n\\hline\n'
FOOTER = '\\hline\n\\end{tabular}\n\\begin{tabnote}\n$\\sigma_\\lambda$ is the rms residual of the wavelength identifications; it does not measure the absolute wavelength accuracy. $n$ counts the selected isolated lamp lines used for the width measurement. $R_{50}$ is their median resolving power and $R_{16}$--$R_{84}$ is their percentile range, describing line-to-line variation rather than an error on the median. The widths characterize the slit-illuminated lamp profile.\n\\end{tabnote}\n\\end{table}\n'

with (HERE / 'detector_summary.csv').open(newline='') as stream:
    rows = list(csv.DictReader(stream))
assert [r['detector'] for r in rows] == ['Ub-blue', 'Ub-red', 'Yb-blue', 'Yb-red']
print(HEADER, end='')
for row in rows:
    assert int(row['R16']) <= int(row['R50']) <= int(row['R84'])
    print(f"{row['detector']:7} & {row['rms_wavelength_A']} & {row['selected_lines']} & "
          f"{row['R50']} [{row['R16']}--{row['R84']}]" + r'\\')
print(FOOTER, end='')
