import csv
from pathlib import Path

HERE = Path(__file__).resolve().parent
HEADER = r'''\begingroup
\small\setlength{\tabcolsep}{4pt}
\begin{longtable}{lrrrrrll}
\caption{Diagnostic transitions and adopted or alternative LVC equivalent widths.}\label{tab:diagnostics}\\
\hline
Ion & $\lambda_{\rm air}$ (\AA) & $\chi$ (eV) & $\log gf$ & $W_\lambda$ (m\AA) & $s_{\rm c}$ (m\AA) & Note & $gf$ source\\
\hline
\endhead
\hline
\multicolumn{8}{p{.84\textwidth}}{\footnotesize The machine-readable table is \texttt{diagnostic\_lines.csv}. $s_{\rm c}$ is conditional measurement noise. The tied B1 fit supplies the two Be EWs and their shared amplitude (figure~\ref{be}); the text gives their percentile intervals. Ca, Na, Mg and V 3093/3102 use fixed-normalization sideband noise where continuum-anchor covariance is unavailable, with the Cr correction fixed at V 3093. Fe I and V 3517 include their local background fits. Notes: (a) B1 empirical Be fit; (b) Ca including background emission; (c) Na on He I emission; (d) Fe I; (e) auxiliary Mg multiplet; (f) Mg 5184 target; (g) V blend-corrected/revised background; (h) V 3517 A background. FW10: \citet{fw10}, with \citet{yan98}; Be wavelengths: \citet{noer15,edlen66}. M20/H15: \citet{meir20,het15}; NIST10: \citet{nist10}; FMW88: \citet{fmw88}; OB91: \citet{ob91}; PR17: \citet{pr17}. W14*: \citet{wood14}; retained +0.572/+0.452 round to +0.57/+0.45, without validation of the third decimal. W14v is the VALD attribution for 3517.}\\
\endlastfoot
'''
FOOTER = r'''\end{longtable}
\endgroup
'''

def main():
    with (HERE / 'diagnostic_lines.csv').open(newline='', encoding='utf-8') as stream:
        rows = list(csv.DictReader(stream))
    assert [r['ID'] for r in rows] == [f'D{i:02d}' for i in range(1, 17)]
    print(HEADER, end='')
    for row in rows:
        ion = row['ion'].replace('7Be', r'$^{7}$Be')
        noise = row['sigma_correlated_mA']
        fields = [
            ion, f"{float(row['rest_air_A']):.3f}",
            f"{float(row['Elow_eV']):.3f}", f"${float(row['loggf']):+.3f}$",
            row['publication_EW_rest_mA'], f"{float(noise):.2f}" if noise else '--',
            row['table_note'], row['gf_source_code'],
        ]
        print(' & '.join(fields) + r'\\' + f" % internal ID: {row['ID']}")
    print(FOOTER, end='')


if __name__ == '__main__':
    main()
