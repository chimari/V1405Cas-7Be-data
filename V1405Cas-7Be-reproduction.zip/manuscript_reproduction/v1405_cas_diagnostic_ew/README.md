# V1405 Cas diagnostic equivalent widths

Source for the manuscript table with LaTeX label `tab:diagnostics`. Run `python3 build_table.py > rebuilt.tex` and compare with `diagnostic_lines.tex`.

The CSV records the adopted values and provenance for 16 diagnostic features, including the tied B1 Be II doublet. The renderer uses the publication EW column and the available conditional noise estimates. Historical registry and alternative measurement fields in the CSV document provenance.
