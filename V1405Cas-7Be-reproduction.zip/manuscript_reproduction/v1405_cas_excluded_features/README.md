# V1405 Cas excluded absorption features

Source for the manuscript table with LaTeX label `tab:excluded`. Run `python3 build_table.py > rebuilt.tex` and compare with `excluded_lines.tex`.

The electronic table contains 63 transition entries across 60 feature groups, including the individual transitions of three unresolved pairs. It records the exclusion reasons, published comments and identification status. Tentative assignments and blank equivalent widths retain the meaning documented in the manuscript table note. The generator formats the archived catalog for LaTeX.

The reference LaTeX uses the current manuscript layout. The table builder reproduces the numeric rows; its generated formatting can differ.
