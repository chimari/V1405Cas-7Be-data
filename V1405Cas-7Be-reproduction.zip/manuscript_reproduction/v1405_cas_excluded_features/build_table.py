import csv
from pathlib import Path

HERE = Path(__file__).resolve().parent
HEADER = '\\begingroup\n\\small\\setlength{\\tabcolsep}{4pt}\n\\begin{longtable}{lllp{9.1cm}}\n\\caption{Absorption features not used in the quantitative line analysis.}\\label{tab:excluded}\\\\\n\\hline\nIon & $\\lambda_{\\rm air}$ (\\AA) & Reason & Comment\\\\\n\\hline\n\\endhead\n\\hline\n\n\\endlastfoot\n'
FOOTER = '\\end{longtable}\n\\par\\smallskip\n\\footnotesize This table contains documented absorption features or blend regions omitted from quantitative analysis, including tentative transition assignments. It does not assert that every listed transition is independently detected. Non-detections and low-S/N records without a documented positive detection are retained only in the internal ledger. No blank EW is interpreted as zero or as an upper limit. B: absorption blend; b?: possible blend; C: uncertain background; CW: contaminated background window; UP: unresolved pair; S: inadequate measurement precision; M: profile/background mismatch; E?: possible emission contribution; R?: unexplained red extension; I? or V?: uncertain assignment or velocity. Candidate contaminants are not confirmed detections or measured contributions. The three unresolved pairs appear as their constituent transitions. No line is rejected merely because it lies off the fitted CoG.\n\n\\endgroup\n'

def main():
    with (HERE / 'excluded_lines.csv').open(newline='', encoding='utf-8') as stream:
        rows = list(csv.DictReader(stream))
    assert len(rows) == len({row['ID'] for row in rows}) == 63
    assert len({row['feature_group_ID'] for row in rows}) == 60
    print(HEADER, end='')
    for row in sorted(rows, key=lambda row: float(row['rest_air_A'])):
        fields = [
            row['ion'], f"{float(row['rest_air_A']):.3f}",
            row['publication_reason_code'], row['publication_note_en'],
        ]
        print(' & '.join(fields) + r'\\' + f" % internal ID: {row['ID']}")
    print(FOOTER, end='')

if __name__ == '__main__':
    main()
