import csv
from pathlib import Path

HERE = Path(__file__).resolve().parent
HEADER = r'''\begingroup
\footnotesize\setlength{\tabcolsep}{4pt}
\renewcommand{\arraystretch}{0.88}
\begin{longtable}[!h]{lllp{9.1cm}}
\caption{Absorption features not used in the quantitative line analysis.}\label{tab:excluded}\\
\hline
Ion & $\lambda_{\rm air}$ (\AA) & Reason & Comment\\
\hline
\endhead
\hline

\endlastfoot
'''
FOOTER = r'''\end{longtable}
\par\smallskip
\footnotesize This table contains documented absorption features or blend regions omitted from quantitative analysis, including tentative transition assignments. It does not assert that every listed transition is independently detected. Non-detections and low-S/N records without a documented positive detection are retained only in the internal ledger. No blank EW is interpreted as zero or as an upper limit. B: absorption blend; b?: possible blend; C: uncertain background; CW: contaminated background window; UP: unresolved pair; S: inadequate measurement precision; M: profile/background mismatch; E?: possible emission contribution; R?: unexplained red extension; I? or V?: uncertain assignment or velocity. Candidate contaminants are not confirmed detections or measured contributions. The three unresolved pairs appear as their constituent transitions. No line is rejected merely because it lies off the fitted CoG.

\endgroup
'''

def main():
    with (HERE / 'excluded_lines.csv').open(newline='', encoding='utf-8') as stream:
        rows = list(csv.DictReader(stream))
    assert len(rows) == len({row['ID'] for row in rows}) == 63
    assert len({row['feature_group_ID'] for row in rows}) == 60
    print(HEADER, end='')
    for index, row in enumerate(sorted(rows, key=lambda row: float(row['rest_air_A']))):
        fields = [
            row['ion'], f"{float(row['rest_air_A']):.3f}",
            row['publication_reason_code'], row['publication_note_en'],
        ]
        if index == 0:
            fields[0] = r'\rule{0pt}{8pt}' + fields[0]
        print(' & '.join(fields) + r'\\' + f" % internal ID: {row['ID']}")
    print(FOOTER, end='')

if __name__ == '__main__':
    main()
