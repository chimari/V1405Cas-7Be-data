# V1405 Cas covering and background trials (Table 7)

LaTeX label `tab:covering-cloudy`. The
[Cloudy summary](covering_cloudy.csv) gives the four runs behind the
table and the diamonds plotted in [Figure 14](../v1405_cas_covering_sensitivity/README.md).
The Fe II stopping column and slab prescription are fixed. Be/Ca and
Be/H refer to the observing epoch. The last row in the TeX table gives
the extrema across the four trials.
