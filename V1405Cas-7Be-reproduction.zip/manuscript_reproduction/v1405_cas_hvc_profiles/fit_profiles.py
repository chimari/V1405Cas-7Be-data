from pathlib import Path
from itertools import product

import numpy as np
import pandas as pd
from scipy.ndimage import gaussian_filter1d
from scipy.optimize import least_squares

ROOT = Path(__file__).resolve().parent
INPUTS = ROOT / "inputs"

C = 299792.458
LAM = np.array([3130.583557665, 3131.228107417, 3132.056630])
V_LVC = -793.0
gf_ratio = 10**(-.479+.178) * LAM[1] / LAM[0]
PROFILE_V = np.arange(-1750.0, -590.0, 2.0)
REFERENCE_TEMPLATE = "Fe II 5018"
MASKS = ((3116.30, 3117.00), (3120.27, 3120.66))

BE_BACKGROUNDS = {
    "near": ((3114.55, 3114.82), (3121.54, 3121.82)),
    "wide": ((3113.60, 3114.10), (3121.46, 3121.74)),
    "redshifted": ((3114.53, 3114.78), (3121.69, 3121.98)),
}
FE = ("Fe II 4924", "Fe II 5018", "Fe II 5169")
obs = pd.read_csv(INPUTS / "observed_major_profiles.csv.gz", float_precision="round_trip")
lv = pd.read_csv(INPUTS / "opacity_templates.csv").query("Cf == 0.8")
lvc_amp = pd.read_csv(INPUTS / "fit_summary_reference.csv").query("background == 'B1'").iloc[0].main_blue_strength_kms

def interval(x, lo, hi):
    return (x >= lo) & (x <= hi)

def vel(wave, central_wave):
    r = wave / central_wave
    return C*(r*r-1)/(r*r+1)

def sampled_profile(label):
    sub = obs[obs.line_label.eq(label)].sort_values("heliocentric_velocity_kms")
    return sub.heliocentric_velocity_kms.to_numpy(), sub.display_flux.to_numpy()

def robust_linear(x, y):
    middle = np.mean(x)
    slope, intercept = np.polyfit(x-middle, y, 1)
    fit = least_squares(lambda a: a[0] + a[1]*(x-middle)-y, [intercept,slope],
                        loss="soft_l1", f_scale=0.014)
    return lambda wave: fit.x[0] + fit.x[1]*(wave-middle)

def fe_template(label):
    v, f = sampled_profile(label)
    flank = interval(v,-1710,-1560) | interval(v,-968,-892)
    background = robust_linear(v[flank], f[flank])
    transmission = np.interp(PROFILE_V, v, f / background(v))
    tau = gaussian_filter1d(-np.log(np.clip(transmission, .08, 1.)), sigma=5)
    taper = np.minimum(np.clip((PROFILE_V+1540)/50,0,1), np.clip((-956-PROFILE_V)/45,0,1))
    tau *= taper
    return tau / tau.max()

def main():
    ub = pd.read_csv(INPUTS / "ub_blend_samples.csv", float_precision="round_trip")
    w, f = ub.wavelength_air_A.to_numpy(), ub.flux.to_numpy(copy=True)
    f /= np.median(f[w<=3122.04])
    wavelengths = np.array([vel(w,l) for l in LAM])
    mask_fit = interval(w, 3114.78, 3121.62)
    spikes = np.logical_or.reduce([interval(w,*m) for m in MASKS])
    profiles = {name: fe_template(name) for name in FE}
    output = []
    pv = []
    fitted_curves = []
    for fe, choice, cf, keep, mode in product(FE, BE_BACKGROUNDS, (.6,.8,1.), (False,True), ("free","anchored")):
        a,b = BE_BACKGROUNDS[choice]
        anchors = interval(w,*a)|interval(w,*b)
        background = robust_linear(w[anchors],f[anchors])(w)
        y = f / background
        use = mask_fit & (~spikes if not keep else np.ones_like(spikes))
        tau = profiles[fe]

        def phi(v):
            return np.interp(v,PROFILE_V,tau,left=0.,right=0.)

        def parts(params):
            be, cr, vbe, vcr = params
            return np.array([be*phi(wavelengths[0]-vbe), gf_ratio*be*phi(wavelengths[1]-vbe), cr*phi(wavelengths[2]-vcr)])

        def trans(opacity):
            return 1 - cf * (-np.expm1(-opacity))

        def fit_resid(params):
            return trans(parts(params).sum(axis=0))[use]-y[use]

        def cr_resid(params):
            cr,dv = params
            return fit_resid((0.,cr,0.,dv))

        trials = [least_squares(fit_resid,[.12,.12,vb,vr],loss="soft_l1",f_scale=.025,
                                bounds=([0.,0.,-90.,-90.],[15.,15.,90.,90.]),x_scale=[.15,.15,60.,60.])
                  for vb,vr in ((0.,0.),(-70.,50.),(50.,-70.))]
        trial_cr = [least_squares(cr_resid,[.18,v0], loss="soft_l1",f_scale=.025,
                                 bounds=([0.,-90.],[15.,90.]), x_scale=[.15,60.]) for v0 in (-60.,0.,60.)]
        if mode == "free":
            f1 = min(trials,key=lambda x:x.cost)
            f0 = min(trial_cr,key=lambda x:x.cost)
            both = f1.x
            cr_only = (0.,f0.x[0],0.,f0.x[1])
        else:
            f1 = least_squares(lambda a: fit_resid((*a,0.,0.)),[.12,.12],bounds=(0.,15.),loss="soft_l1",f_scale=.025)
            f0 = least_squares(lambda a: cr_resid((a[0],0.)),[.18],bounds=(0.,15.),loss="soft_l1",f_scale=.025)
            both = (*f1.x,0.,0.)
            cr_only = (0.,f0.x[0],0.,0.)
        if not (f1.success and f0.success):
            raise RuntimeError(f"fit failed for {fe}, {choice}, {cf}, {keep}, {mode}")
        flux = trans(parts(both).sum(axis=0))
        no_be = trans(parts(cr_only).sum(axis=0))
        be = 1-trans(both[0]*phi(PROFILE_V-both[2]))
        red = 1-trans(gf_ratio*both[0]*phi(PROFILE_V-both[2]))
        isolate = trans(parts(both))
        q = dict(template=fe,background=choice,Cf=cf,keeps_sharp_dips=keep,velocity_mode=mode,be_amplitude=both[0],cr_amplitude=both[1],
                 be_offset_kms=both[2],cr_offset_kms=both[3],n_pixels=use.sum(),
                 conditional_W3130_mA=1000*LAM[0]/C*np.trapezoid(be,PROFILE_V),
                 conditional_W3131_mA=1000*LAM[1]/C*np.trapezoid(red,PROFILE_V),
                 rms_full=float(np.sqrt(np.mean(f1.fun**2))),rms_no_be=float(np.sqrt(np.mean(f0.fun**2))),
                 robust_cost_full=f1.cost,robust_cost_no_be=f0.cost,at_shift_bound=bool(np.max(np.abs(both[2:]))>89.9))
        output.append(q)
        pv.append((be,red))
        fitted_curves.append((y, flux, no_be, isolate, use))
    grid = pd.DataFrame(output)
    grid.to_csv(ROOT/"hvc_broad_fit_trials.csv",index=False)
    print(grid.groupby(["template","keeps_sharp_dips","velocity_mode"])[["conditional_W3130_mA","rms_full","rms_no_be"]].agg(["min","median","max"]).round(4).to_string())
    representative=grid.index[grid.template.eq(REFERENCE_TEMPLATE)&grid.background.eq("near")&grid.Cf.eq(.8)&grid.velocity_mode.eq("free")&~grid.keeps_sharp_dips][0]
    print("Reference:", grid.iloc[representative].to_dict())
    for _,q in grid.nsmallest(6,"rms_full").iterrows():
        print("low rms:",q.template,q.background,q.Cf,q.keeps_sharp_dips,q.conditional_W3130_mA,q.rms_full,q.rms_no_be)
    y, fit, no_be, isolate, use = fitted_curves[representative]
    pd.DataFrame(dict(wave=w,observed=y,fit=fit,no_be=no_be,Be_blue=isolate[0],Be_red=isolate[1],CrII=isolate[2],used_pixels=use)).to_csv(ROOT/"reference_hvc_decomposition.csv",index=False)
    select = ~grid.keeps_sharp_dips
    broad = np.array(pv)
    low, high = np.min(broad[select],axis=0), np.max(broad[select],axis=0)
    lvc_template = np.interp(PROFILE_V-V_LVC,lv.v_relative_kms,lv.phi_per_kms,left=0,right=0)
    lvc = .8*(-np.expm1(-np.array([1.,gf_ratio])[:,None]*lvc_amp*lvc_template[None,:]))
    np.savez(ROOT/"profile_curves.npz",v=PROFILE_V,best=broad[representative],lo=low,hi=high,lvc=lvc)

if __name__ == "__main__":
    main()
