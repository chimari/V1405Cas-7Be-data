# V1405 Cas HVC profile comparison (Figure 7)

LaTeX label `fig:hvc-profiles`. The [reference PDF](reference_plot.pdf)
is the figure used in the manuscript.

```sh
python -m pip install -r requirements.txt
python fit_profiles.py
python draw_hvc.py
```

`inputs/ub_blend_samples.csv` preserves the cropped pixels from the
reduced Subaru/HDS Ub spectrum. `inputs/observed_major_profiles.csv.gz`
contains the display-normalized optical profiles taken from the
[velocity-profile package](../v1405_cas_velocity_profiles/README.md).
The two LVC input CSVs come from the
[LVC decomposition](../be_cr_empirical_decomposition/README.md).

The near-UV fit uses 3114.78–3121.62 Å. The 108 trials vary the Fe II
multiplet 42 profile, local background, covering fraction, treatment of
two sharp dips and whether the Be and Cr velocities can shift. The
reference display uses Fe II 5018, the near background, a covering
fraction of 0.8 and free velocity offsets, with the two narrow dips
masked. The 3130 envelope includes the trials with those dips masked.
The envelope reflects line-profile and background choices and includes
zero Be absorption.

`hvc_broad_fit_trials.csv` records the fitted strengths, conditional EWs
and RMS residuals of the joint and Cr-only fits.
`reference_hvc_decomposition.csv` gives the wavelength samples and fitted
fluxes in panel (a). `profile_curves.npz` contains the isolated profiles
in panel (b). The manuscript uses LVC columns for the quantitative
ionization and abundance analysis.
