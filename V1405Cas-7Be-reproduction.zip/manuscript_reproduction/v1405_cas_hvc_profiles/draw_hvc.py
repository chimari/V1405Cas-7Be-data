import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MultipleLocator
import numpy as np
import pandas as pd

from fit_profiles import LAM, MASKS, ROOT, V_LVC, sampled_profile, vel

BLUE, RED, GREEN, OCHRE = "#265c88", "#a5473c", "#39745f", "#98682b"
CHARCOAL = "#292e34"
HVC_FILL = "#eaf0f6"
MASK_COLOR = "#e9e0db"
LVC_LINE = "#475667"
V_RANGE = (-1600, -715)
V_TICKS = [-1600,-1400,-1200,-1000,-800]


def label(ax, tag, title):
    ax.set_title(f"({tag})  {title}", loc="left", pad=6, fontsize=9.6, fontweight="semibold")


def velocity_axis(ax, show=False, unit_line=True):
    ax.set_xlim(*V_RANGE)
    ax.set_xticks(V_TICKS)
    ax.xaxis.set_minor_locator(MultipleLocator(50))
    ax.tick_params(labelbottom=show)
    ax.axvspan(-1500,-1000,color=HVC_FILL,zorder=-5)
    ax.axvline(V_LVC,color=LVC_LINE,ls=(0,(2,3)),lw=.82,alpha=.82,zorder=-1)
    if unit_line:
        ax.axhline(1,color=".64",lw=.65,zorder=-2)


def observed_lines(ax, tags):
    for tag, description, color in tags:
        velocity, flux = sampled_profile(tag)
        extent = (velocity>=-1650)&(velocity<=-670)
        ax.plot(velocity[extent],flux[extent],label=description,color=color,lw=.95,zorder=2)
    if len(tags) > 1:
        ax.legend(loc="lower left",frameon=False,ncol=len(tags),handlelength=1.65,handletextpad=.5,
                  columnspacing=.85,borderaxespad=.35)


def main():
    plt.rcParams.update({
        "font.family":"DejaVu Sans","font.size":8.4,"axes.labelsize":9.0,
        "legend.fontsize":7.3,"pdf.fonttype":42,"axes.linewidth":.72,"axes.spines.top":False,
        "axes.spines.right":False,"xtick.direction":"out","ytick.direction":"out"
    })
    fig=plt.figure(figsize=(8,7.25),facecolor="white")
    grid=fig.add_gridspec(3,2,height_ratios=[1.32,1,1],
                          left=.101,right=.983,top=.956,bottom=.155,wspace=.21,hspace=.40)
    first=grid[0,0].subgridspec(2,1,height_ratios=[3.4,1],hspace=.038)
    a=fig.add_subplot(first[0])
    ar=fig.add_subplot(first[1],sharex=a)
    b=fig.add_subplot(grid[0,1])
    c=fig.add_subplot(grid[1,0])
    d=fig.add_subplot(grid[1,1])
    e=fig.add_subplot(grid[2,0])
    f=fig.add_subplot(grid[2,1])
    for ax in (a, b, c, d, e, f):
        velocity_axis(ax,show=ax in (e,f))
    velocity_axis(ar,unit_line=False)
    line=pd.read_csv(ROOT/"reference_hvc_decomposition.csv")
    wavelength=line.wave.to_numpy()
    v_blend=vel(wavelength,LAM[0])
    y=line.observed.to_numpy()
    displayed_fit=(wavelength>=3114.78)&(wavelength<=3121.62)
    fits=[np.where(displayed_fit,line[name],np.nan) for name in ("fit","no_be")]
    for ax in (a, ar):
        for lo,hi in MASKS:
            ax.axvspan(vel(lo,LAM[0]),vel(hi,LAM[0]),color=MASK_COLOR,zorder=-4)
    a.step(v_blend,y,where="mid",color=CHARCOAL,lw=.86,label="HDS spectrum")
    a.plot(v_blend,fits[0],color=BLUE,lw=1.30,label=r"$^7$Be II + Cr II")
    a.plot(v_blend,fits[1],color=OCHRE,lw=1.15,ls=(0,(5,2.4)),label="Cr II alone")
    a.plot(v_blend,np.where(displayed_fit,line.CrII,np.nan),color=GREEN,lw=.98,
           ls=(0,(1.4,2.5)),label="Cr II in joint fit")
    a.set_ylim(.14,1.18)
    a.set_yticks([.2,.6,1])
    a.set_ylabel("Normalized flux")
    a.tick_params(axis="x",length=0)
    a.spines["bottom"].set_visible(False)
    a.legend(loc="lower right",ncol=2,borderaxespad=.27,columnspacing=.68,
             handlelength=1.35,handletextpad=.32,frameon=True,facecolor="white",
             edgecolor="none",framealpha=.93,fontsize=6.75)
    label(a,"a",r"Observed $^7$Be II–Cr II blend")
    a.text(.015,.966,r"3130 Å velocity frame; $C_f=0.8$",transform=a.transAxes,fontsize=7.0,va="top",color=".27")
    ar.axhline(0,color=".55",lw=.6)
    ar.step(v_blend,y-fits[0],where="mid",color=BLUE,lw=.64)
    ar.step(v_blend,y-fits[1],where="mid",color=OCHRE,ls=(0,(3.7,2.1)),lw=.62)
    ar.set_ylim(-.14,.14)
    ar.set_yticks([-.1,.1])
    ar.set_ylabel("Residual",fontsize=7.3)
    for w in (3116.70,3120.42):
        v=vel(w,LAM[0])
        ar.annotate("",xy=(v,-.134),xytext=(v,-.067),
                    arrowprops={"arrowstyle":"-|>","mutation_scale":7,"lw":.65,"color":".35"})
    p=np.load(ROOT/"profile_curves.npz")
    v=p["v"]
    band=b.fill_between(v,1-p["hi"][0],1-p["lo"][0],color="#9dbbd7",alpha=.68,lw=0,label="3130 trial envelope")
    blue,=b.plot(v,1-p["best"][0],color=BLUE,lw=1.30,label=r"$^7$Be II 3130")
    red,=b.plot(v,1-p["best"][1],color=RED,lw=1.21,label=r"$^7$Be II 3131")
    for j,col in enumerate([BLUE,RED]):
        sel=(v>=-900)&(v<=-723)
        b.plot(v[sel],1-p["lvc"][j][sel],color=col,ls=(0,(2.8,2.4)),lw=1)
    b.set_ylim(.52,1.095)
    b.set_yticks([.6,.8,1])
    b.set_ylabel("Model transmission")
    b.legend(loc="lower left",ncol=2,
             handles=[blue,red,band,Line2D([],[],color=".32",ls=(0,(2.8,2.4)),label="LVC fit (B1)")],
             frameon=False,handlelength=1.6,columnspacing=.97,borderaxespad=.34)
    b.text(-1480,1.043,"HVC",color=LVC_LINE,fontsize=7.5,va="center")
    b.text(-782,1.043,"LVC",color=LVC_LINE,fontsize=7.5,va="center")
    label(b,"b",r"Isolated $^7$Be II model profiles")
    observed_lines(c,[("Ca II K","Ca II K",BLUE)])
    c.set_ylim(.11,1.11)
    c.set_yticks([.2,.6,1])
    c.set_ylabel("Relative flux")
    label(c,"c","Ca II K")
    observed_lines(d,[("H beta","Hβ",BLUE),("H gamma","Hγ",OCHRE),("H eta","Hη",GREEN)])
    d.set_ylim(.005,1.85)
    d.set_yticks([0,.5,1,1.5])
    label(d,"d","H I Balmer")
    observed_lines(e,[("Fe II 4924","4924",BLUE),("Fe II 5018","5018",OCHRE),("Fe II 5169","5169",GREEN)])
    e.set_ylim(.09,1.25)
    e.set_ylabel("Relative flux")
    e.set_yticks([.2,.6,1])
    label(e,"e","Fe II multiplet 42")
    observed_lines(f,[("Na I D2",r"D$_2$",BLUE),("Na I D1",r"D$_1$",OCHRE)])
    f.set_ylim(.43,1.08)
    f.set_yticks([.5,.75,1])
    label(f,"f","Na I D")
    f.annotate(r"D$_2$ LVC on D$_1$ scale",xy=(-1096.86,.78),xytext=(-1225,.61),
               ha="center",va="center",fontsize=7,color=".30",
               arrowprops={"arrowstyle":"-","color":".38","lw":.71,"shrinkB":1})
    fig.supxlabel("Heliocentric velocity (km s⁻¹)",y=.100,fontsize=9.2)
    fig.text(.101,.064,
             "Gray marks the two sharp dips omitted from the broad fit in (a). Arrows indicate clipped residuals.",
             color=".28",fontsize=7)
    fig.text(.101,.045,
             "The 3130 trial envelope includes zero Be absorption. Panels (c)–(f) use separate display normalizations.",
             color=".28",fontsize=7)
    panels=(a, ar, b, c, d, e, f)
    velocities={tuple(ax.get_xlim()) for ax in panels}
    widths=np.array([ax.get_position().width for ax in panels])
    assert len(velocities)==1 and velocities.pop()==V_RANGE and np.ptp(widths)<1e-10
    for ext in ("pdf","png"):
        fig.savefig(ROOT/f"V1405Cas_HVC_Be_profile_comparison.{ext}",dpi=210 if ext=="png" else 350)


if __name__=="__main__":
    main()
