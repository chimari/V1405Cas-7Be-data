# Conditional uncertainty propagation for V1405 Cas

Manuscript figure with LaTeX label `fig:empirical-errors`. Reproduce the PDF and PNG with:

```sh
python -m pip install -r requirements.txt
MPLBACKEND=Agg python render_uncertainty.py
```

The inputs are saved numerical summaries of the paired observational realizations. The left panel displays the 16th–84th percentile offsets from nominal column ratios to Fe II. The right panel compares the observing-epoch elemental Be/Ca interval at fixed K_g with the interval from the local Cloudy abundance response evaluated around the earlier B1 solution and anchored to the revised central model. The included reference PDF is the manuscript graphic. The renderer starts from the precomputed intervals.
