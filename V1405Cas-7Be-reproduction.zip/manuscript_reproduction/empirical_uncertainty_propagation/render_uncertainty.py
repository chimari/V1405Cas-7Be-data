"""Plot paired observation intervals for the verified UV025 B1 model."""
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
a = pd.read_csv(HERE/'verified_abundance_pattern_points.csv',index_col=0)
v = json.loads((HERE/'verified_abundance_summary.json').read_text())
ground = {'Be', 'Na', 'Ca'}
blue, teal = '#21558a', '#17897f'

fig, axs = plt.subplots(1, 2, figsize=(10, 3.9), layout='constrained', gridspec_kw={'width_ratios':[1.65, 1]})
ax = axs[0]
mask = np.isfinite(a.obs_lo) & (a.index != 'Fe')
b = a[mask]
y = np.arange(len(b))
for j, (_, row) in enumerate(b.iterrows()):
    ax.hlines(j, row.obs_lo-row.observed, row.obs_hi-row.observed, color=blue, lw=2)
    ax.scatter(0, j, color=blue, s=11)
ax.axvline(0, color='#aaa', lw=.8, zorder=0)
ax.set_yticks(y, [f'{el} (ground)' if el in ground else el for el in b.index])
ax.invert_yaxis()
ax.set(title='(a) Paired column-ratio intervals', xlabel='Offset from nominal log(N/Fe II) (dex)')
ax = axs[1]
for y,keys,color in [
    (1, ('BeCa_fixed_center','BeCa_fixed_p16','BeCa_fixed_p84'), blue),
    (0, ('BeCa','BeCa_p16','BeCa_p84'), teal),
]:
    center,lo,hi = [v[key]*1e5 for key in keys]
    ax.hlines(y, lo, hi, color=color, lw=2)
    ax.scatter(center, y, color=color, s=31)
ax.set_yticks([1,0], ['Fixed correction','Local Cloudy response'])
ax.set(ylim=(-.65,1.65),title='(b) Elemental Be/Ca',xlabel=r'Observed epoch ($10^{-5}$)')
for extension in ('pdf', 'png'):
    fig.savefig(HERE/f'empirical_uncertainty_propagation.{extension}', bbox_inches='tight', dpi=200)
plt.close(fig)
