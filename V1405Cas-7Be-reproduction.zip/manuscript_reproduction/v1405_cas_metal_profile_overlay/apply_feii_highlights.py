"""Place the saved vector panel (a) with Fe II multiplet 42 highlights."""
from pathlib import Path
import fitz

root = Path(__file__).resolve().parent
with fitz.open(root / "metal_overlay.pdf") as doc, fitz.open(root / "feii_panel_a.pdf") as panel:
    region = fitz.Rect(44,32,270,174)
    doc[0].draw_rect(region, color=None, fill=(1,1,1))
    doc[0].show_pdf_page(region,panel,0)
    doc.save(root / "metal_overlay_with_feii_highlights.pdf", garbage=4, deflate=True)
