"""Append the adopted empirical opacity template to the six vector panels."""
import csv
from io import BytesIO
from pathlib import Path

import fitz
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

here = Path(__file__).resolve().parent
with (here / 'opacity_templates.csv').open() as stream:
    rows = [(float(r['v_relative_kms']), float(r['phi_per_kms']))
            for r in csv.DictReader(stream) if float(r['Cf']) == 0.8]
v, phi = np.array(rows).T
assert (np.diff(v) > 0).all() and (phi >= 0).all()
assert not phi[(v < -60) | (v > 40)].any()
assert np.isclose(np.trapezoid(phi, v), 1., atol=1e-8)

plt.rcParams.update({'font.family': 'serif', 'font.size': 9, 'pdf.fonttype': 42})
height = 123
with fitz.open(here / 'metal_overlay_panels_a-f.pdf') as original:
    rect = original[0].rect
    fig = plt.figure(figsize=(rect.width/72, height/72))
    ax = fig.add_axes([48/rect.width, .27, 455/rect.width, .68])
    ax.plot(v, phi, color='#242424', lw=1.25)
    ax.axvline(0, color='#777777', linestyle=':', linewidth=.75)
    ax.text(.025, .91, '(g) Empirical opacity template (48 weak lines)',
            transform=ax.transAxes, va='top', fontsize=9)
    ax.set(xlim=(-66, 48), ylim=(-.001, 1.24*phi.max()),
           xlabel=r'Velocity relative to the LVC (km s$^{-1}$)',
           ylabel=r'$\phi(v)$ [(km s$^{-1}$)$^{-1}$]')
    ax.tick_params(direction='in', top=True, right=True, labelsize=8)
    panel_bytes = BytesIO()
    fig.savefig(panel_bytes, format='pdf')
    plt.close(fig)
    with fitz.open(stream=panel_bytes.getvalue(), filetype='pdf') as panel, fitz.open() as output:
        page = output.new_page(width=rect.width, height=rect.height + height)
        page.show_pdf_page(rect, original, 0)
        page.show_pdf_page(fitz.Rect(0, rect.height, rect.width, rect.height+height), panel, 0)
        panels = [drawing['rect'] for drawing in page.get_drawings()
                  if drawing['type'] == 'f' and abs(drawing['rect'].y0 - 331.21) < .02
                  and abs(drawing['rect'].x0 - 284.2604) < .02 and drawing['rect'].width > 200]
        panel, = panels
        ticks = []
        for label in ('−850', '−825'):
            x, = [(word[0] + word[2])/2 for word in page.get_text('words')
                  if word[4] == label and abs(word[1] - panel.y1) < 14
                  and panel.x0 < word[0] < panel.x1]
            ticks.append(x)
        page.draw_rect(fitz.Rect(ticks[0], panel.y0, ticks[1], panel.y1),
                       color=None, fill=(.15, .50, .82), fill_opacity=.13, overlay=True)
        # Use the shared velocity ticks and the Cr II panel's flux scale.
        ticks = {w[4]: (w[0]+w[2])/2 for w in page.get_text('words')
                 if w[0] < 270 and 465 < w[1] < 470}
        x0 = ticks['−850']
        slope = (ticks['−750']-x0)/100
        with (here / 'crii_profiles.csv').open() as stream:
            highlights = list(csv.DictReader(stream))
        for wave, color, dash, y in [
            ('3120.359', (.60,.22,.50), None, 272),
            ('3124.973', (.72,.32,.07), '[3 1.5] 0', 286),
        ]:
            profile = sorted(
                (float(r['heliocentric_velocity_kms']), float(r['depth_scaled_flux']))
                for r in highlights if r['wavelength_A'] == wave
            )
            pts = [(x0+slope*(v+850), 301.7788-98.5963*f) for v,f in profile]
            pts = [(x,y0) for x,y0 in pts if 48.5 <= x <= 266.75 and 183.5 <= y0 <= 316.5]
            page.draw_polyline(pts, color=color, width=1.05, dashes=dash)
            page.draw_line((189,y-2), (204,y-2), color=color, width=1.15, dashes=dash)
            page.insert_text((208,y), f'{wave} Å', fontsize=8, color=color)
        output.save(here / 'metal_overlay.pdf', garbage=4, deflate=True)
