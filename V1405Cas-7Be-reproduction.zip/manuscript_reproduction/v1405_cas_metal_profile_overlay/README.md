# V1405 Cas metal profile overlay and opacity template

Reproduces the manuscript figure with LaTeX label `metalshape`. Install the listed dependencies and run `python render_overlay.py`.

The renderer starts from archived vector panels containing the 118 metal-line profiles and ion averages. It appends the unit-integral empirical opacity template from 48 weak lines at covering fraction 0.8 and marks -850 to -825 km/s in the ion-average panel. It also highlights Cr II 3120.359 and 3124.973 Å using the saved depth-scaled profiles in `crii_profiles.csv`. The reference PDF and caption are from the updated manuscript.

The current reference additionally highlights the Fe II multiplet 42 profiles in (a). The existing renderer rebuilds the underlying seven-panel plot. Run `python apply_feii_highlights.py` (PyMuPDF) after rendering to insert the archived final vector panel (a) into the plot.

