from pathlib import Path
import json
import numpy as np,pandas as pd
from scipy.optimize import brentq,least_squares
from scipy.interpolate import PchipInterpolator
R=Path(__file__).resolve().parent;I=R/'inputs';CF=.8;T=12146.29896614716;C=299792.458
K=1.497e-15*np.sqrt(np.pi);TH=1/(8.617333262e-5*np.log(10))
d=pd.read_csv(I/'diagnostic_current.csv').set_index('ID');components=pd.read_csv(I/'MgI_components_PR17.csv')
temp=pd.read_csv(I/'opacity_templates.csv').query('Cf==0.8');grid=temp.v_relative_kms.to_numpy();phi=temp.phi_per_kms.to_numpy()
qU=pd.read_csv(I/'partition_MgI_VII.csv').query("species=='Mg I'");U=float(np.exp(PchipInterpolator(np.log(qU.T_K),np.log(qU.U))(np.log(T))))
def opacity(u,n,lid,split=True):
 r=d.loc[lid];S=K*10**(n+r.loggf)*r.rest_air_A*10**(-TH*r.Elow_eV/T)
 if lid=='D12' and split:
  q=components[components.ID==lid];frac=10**q.loggf.to_numpy()/10**r.loggf
  shift=C*(26045.87/q.wavenumber_cm1.to_numpy()-1)
  # Relative wavenumber separations anchored to adopted 3838.2918 A centroid convention.
  return S*sum(f*np.interp(u-dv,grid,phi,left=0,right=0) for f,dv in zip(frac,shift))
 return S*np.interp(u,grid,phi,left=0,right=0)
def flux(u,n,lid,split=True,step=.025):
 side=np.r_[np.arange(-77,-62+step/2,step),np.arange(38,58+step/2,step)]
 fs=1-CF+CF*np.exp(-opacity(side,n,lid,split));co=np.linalg.lstsq(np.c_[np.ones(len(side)),side],fs,rcond=None)[0]
 return (1-CF+CF*np.exp(-opacity(u,n,lid,split)))/(co[0]+co[1]*u)
def predict(lid,n,split=True,step=.025):
 u=np.arange(-57,28+step/2,step);return float(np.trapezoid(1-flux(u,n,lid,split,step),u)*d.loc[lid,'rest_air_A']/C*1000)
def inverse(lid,E,split=True,step=.025):return brentq(lambda n:predict(lid,n,split,step)-E,8,17,xtol=1e-12)
def analyze():
 obs=pd.read_csv(I/'Mg_profiles.csv');records=[];profiles=[]
 for lid in ['D12','D13']:
  r=d.loc[lid];n=inverse(lid,r.EW_rest_mA);collapsed=inverse(lid,r.EW_rest_mA,False)
  q=obs[np.isclose(obs.rest_air_A,r.rest_air_A,rtol=0,atol=1e-5)].sort_values('v_kms');u=q.v_kms.to_numpy()+793;f=q.outer_window_normalized_flux.to_numpy()
  x=np.r_[-57,u[(u>-57)&(u<28)],28];E=float(np.trapezoid(1-np.interp(x,u,f),x)*r.rest_air_A/C*1000)
  lineu=np.arange(-57,28.001,.025);linearEW=np.trapezoid(opacity(lineu,n,lid),lineu)*CF*r.rest_air_A/C*1000
  records.append(dict(ID=lid,label=r.label,EW_adopted_mA=r.EW_rest_mA,EW_reintegrated_mA=E,EW_reintegration_delta_mA=E-r.EW_rest_mA,log_N_over_U=n,U=U,log_Nion_LTE=n+np.log10(U),log_Nlower=n+np.log10(5)-TH*r.Elow_eV/T,collapsed_single_line_logNU=collapsed,split_minus_collapsed_dex=n-collapsed,quadrature_halfstep_delta_dex=inverse(lid,r.EW_rest_mA,True,.0125)-n,saturation_correction_dex=np.log10(linearEW/r.EW_rest_mA),profile_RMS=float(np.sqrt(np.mean((f[(u>=-57)&(u<=28)]-flux(u[(u>=-57)&(u<=28)],n,lid))**2)))))
  profiles.extend(dict(ID=lid,u_kms=x,observed=f0,model_individual=ff) for x,f0,ff in zip(u,f,flux(u,n,lid)))
 fit=least_squares(lambda a:[np.log10(predict(lid,a[0])/d.loc[lid,'EW_rest_mA']) for lid in ['D12','D13']],[records[1]['log_N_over_U']],ftol=1e-12,xtol=1e-12,gtol=1e-12)
 for a in records:
  a['joint_log_N_over_U']=float(fit.x[0]);a['joint_model_EW_mA']=predict(a['ID'],fit.x[0]);a['joint_residual_logEW_dex']=np.log10(a['EW_adopted_mA']/a['joint_model_EW_mA'])
 pd.DataFrame(records).to_csv(R/'MgI_columns_and_controls.csv',index=False);pd.DataFrame(profiles).to_csv(R/'MgI_profile_predictions.csv',index=False)
 out=dict(Cf=CF,T_K=T,EW_fixed=True,primary_refit=False,MC_rerun=False,loggf_sum=float(np.log10(np.sum(10**components.query("ID=='D12'").loggf))),Mg5184_baseline_logNU=records[1]['log_N_over_U'],Mg3838_control_logNU=records[0]['log_N_over_U'],delta_3838_minus_5184_dex=records[0]['log_N_over_U']-records[1]['log_N_over_U'],joint_display_logNU=float(fit.x[0]),joint_display_role='consistency control only; two feature EWs, not four independent lines',source='https://arxiv.org/pdf/1611.07000 Tables 2 and 3',split_reference='relative wavenumber separations anchored to adopted rest wavelength; table precision 0.01 cm^-1',uncertainty='not propagated; do not reuse archived Gaussian intervals',Cloudy_runs=0)
 (R/'MgI_validation.json').write_text(json.dumps(out,indent=2));print(pd.DataFrame(records).to_string(index=False));print(json.dumps(out,indent=2))
if __name__=='__main__':analyze()
