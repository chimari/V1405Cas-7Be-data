from pathlib import Path
import json
import numpy as np,pandas as pd
from scipy.optimize import least_squares
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import mg_model
R=Path(__file__).resolve().parent;I=R/'inputs';CF=.8;T=12146.29896614716;C=299792.458
K=1.497e-15*np.sqrt(np.pi);TH=1/(8.617333262e-5*np.log(10))
primary=pd.read_csv(I/'primary_points_Cf08.csv');assert len(primary)==118
temp=pd.read_csv(I/'opacity_templates.csv').query('Cf==0.8')
v=temp.v_relative_kms.to_numpy();phi=temp.phi_per_kms.to_numpy()
def shape(u):return np.interp(u,v,phi,left=0,right=0)
vf=np.arange(-100,100.001,.025);pf=shape(vf)
def full(S):return CF*np.trapezoid(-np.expm1(-np.atleast_1d(S)[:,None]*pf),vf,axis=1)/C
def strength(r,n):return K*10**(n+r.loggf)*r.rest_air_A*10**(-TH*r.Elow_eV/T)
def predict(r,n):
    S=strength(r,n)
    if r.ion=='Mg I':return mg_model.predict(r.ID,n)
    if r.ion=='7Be II':return float(full(S)[0]*r.rest_air_A*1000)
    lo,hi=(-60,35) if r.ID=='D16' else (-57,28)
    windows=[(-100,-80),(40,60)] if r.ID=='D16' else [(-77,-57),(33,53)]
    if r.ID=='D14': windows=[(-77,-57),(68,93)]
    if r.ID=='D15': windows=[(-82,-62),(33,53)]
    if r.ion=='Fe I':
        fr=fei_windows[fei_windows.label==r.label].iloc[0]
        windows=[(fr.blue_lo+793,fr.blue_hi+793),(fr.red_lo+793,fr.red_hi+793)]
    u=np.linspace(lo,hi,round((hi-lo)*10)+1)
    side=np.concatenate([np.linspace(a,b,round((b-a)*10)+1) for a,b in windows])
    fs=1-CF+CF*np.exp(-S*shape(side));co=np.linalg.lstsq(np.c_[np.ones(len(side)),side],fs,rcond=None)[0]
    f=(1-CF+CF*np.exp(-S*shape(u)))/(co[0]+co[1]*u)
    return np.trapezoid(1-f,u)*r.rest_air_A/C*1000
fei_windows=pd.read_csv(I/'FeI_diagnostics5.csv')
d=pd.read_csv(R/'diagnostic_current.csv');d=d[d.ID.isin(['D01','D02','D03','D04','D05','D06','D07','D08','D09','D10','D11','D12','D13','D14','D15','D16'])].copy()
be_fit = pd.read_csv(R/'be_lvc/no_red_component_summary.csv').set_index('background')
be_norm = float(be_fit.loc['B1', 'logN_BeII_ground']) - np.log10(2)
d['EW_source'] = 'frozen manuscript registry'
d['status'] = np.where(d.ion.isin(['V II','Fe I']), 'provisional', 'conditional diagnostic')
be = d.ion.eq('7Be II')
d.loc[be,'EW_rest_mA'] = [predict(r, be_norm) for r in d[be].itertuples()]
d.loc[be,'EW_source'] = 'B1 three-transition empirical profile fit; full isolated EW'
d.loc[be,'status'] = 'profile-derived diagnostic'
d.loc[be,'sigma_correlated_mA'] = np.nan
nominal=json.loads((I/'nominal_log_N_over_U.json').read_text())
nominal['Be B1'] = be_norm
normalization_keys={'7Be II':'Be B1','Ca II':'Ca HK','Na I':'Na joint control','Fe I':'Fe I linear EW','V II':'V II provisional'}
nominal['Mg joint display']=json.loads((R/'MgI_validation.json').read_text())['joint_display_logNU']
normalization_keys['Mg I']='Mg joint display'
pars=[]
for ion,q in d.groupby('ion',sort=False):
    fit=least_squares(lambda n:np.array([np.log10(predict(r,n[0])) for r in q.itertuples()])-np.log10(q.EW_rest_mA.to_numpy()),[12.],bounds=([7],[20]),ftol=1e-12,xtol=1e-12,gtol=1e-12)
    assert fit.success
    if ion in normalization_keys: fit.x[0]=nominal[normalization_keys[ion]]
    fit.fun=np.array([np.log10(predict(r,fit.x[0])/r.EW_rest_mA) for r in q.itertuples()])
    for idx,r in q.iterrows():
        model=predict(r,fit.x[0]);d.loc[idx,'log_N_over_U_display']=fit.x[0]
        d.loc[idx,'log_integrated_tau_kms']=np.log10(strength(r,fit.x[0]))
        d.loc[idx,'observed_log_Wrest_over_lambda']=np.log10(r.EW_rest_mA/1000/r.rest_air_A)
        d.loc[idx,'model_log_Wrest_over_lambda']=np.log10(model/1000/r.rest_air_A)
        d.loc[idx,'residual_dex']=np.log10(r.EW_rest_mA/model)
    pars.append(dict(ion=ion,n_lines=len(q),log_N_over_U_display=fit.x[0],RMS_logEW_dex=np.sqrt(np.mean(fit.fun**2))))
d.to_csv(R/'diagnostic_CoG_points.csv',index=False);pd.DataFrame(pars).to_csv(R/'diagnostic_normalizations.csv',index=False)
primary.to_csv(R/'primary_CoG_points.csv',index=False)
assert np.max(abs(d[d.ion=='7Be II'].residual_dex))<1e-8
assert np.isclose(np.sqrt(np.mean(primary.residual_dex**2)),.08530213724303641)
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,axes=plt.subplots(2,2,figsize=(11.3,7.2),sharex='col',gridspec_kw={'height_ratios':[3.2,1],'hspace':.06,'wspace':.23})
x=np.linspace(-.65,2.8,600);curve=np.log10(full(10**x))
colors=['#276bad','#ca7937','#35946c','#9862a5','#af5874']
for color,(ion,q) in zip(colors,primary.groupby('ion',sort=False)):
    axes[0,0].scatter(q.log_integrated_tau_kms,q.observed_log_Wrest_over_lambda,s=20,color=color,label=f'{ion} ({len(q)})',alpha=.8)
    axes[0,0].scatter(q.log_integrated_tau_kms,q.model_log_Wrest_over_lambda,s=24,color=color,marker='_')
    axes[1,0].scatter(q.log_integrated_tau_kms,q.residual_dex,s=18,color=color,alpha=.8)
style={'7Be II':('#7656a6','o',r'$^7$Be II'), 'Ca II':('#ca7937','s','Ca II H/K'),
       'Na I':('#278b79','^','Na I'), 'V II':('#bd4b65','D','V II (provisional)'), 'Mg I':('#237f9c','P','Mg I (joint fit)'), 'Fe I':('#8c672c','v','Fe I (provisional)')}
targets={'D01':(1.25,-4.55),'D02':(.95,-5.23),'D03':(2.03,-4.03),'D04':(1.62,-4.33),'D05':(1.38,-4.91),'D06':(.35,-5.34),
         'D14':(1.2,-4.28),'D15':(.32,-4.45),'D16':(-.25,-5.97)}
targets.update({'D07':(.6,-5.52),'D08':(-.35,-5.54),'D09':(.4,-6.5),'D10':(.45,-5.95),'D11':(-.05,-6.35)})
targets['D16']=(.22,-5.72)
targets.update({'D12':(.92,-5.15),'D13':(.05,-5.19)})
# Be 3131 left of its point; Be 3130 slightly lower right, clear of the curve.
targets.update({'D01':(1.52,-4.76),'D02':(.20,-4.76)})
labels={'D01':r'$^7$Be 3130','D02':r'$^7$Be 3131','D03':'Ca K','D04':'Ca H','D05':'Na D2','D06':'Na D1','D14':'V 3093','D15':'V 3102','D16':'V 3517'}
labels.update({'D12':'Mg I 3838','D13':'Mg I 5184','D07':'Fe I 3581','D08':'Fe I 3820','D09':'Fe I 3826','D10':'Fe I 4046','D11':'Fe I 4064'})
for ion,q in d.groupby('ion',sort=False):
    color,marker,label=style[ion]
    axes[0,1].scatter(q.log_integrated_tau_kms,q.observed_log_Wrest_over_lambda,s=56,facecolors='white',edgecolors=color,marker=marker,label=label,lw=1.8 if ion=='7Be II' else 1.5,zorder=8 if ion=='7Be II' else 4)
    axes[0,1].scatter(q.log_integrated_tau_kms,q.model_log_Wrest_over_lambda,s=45,color=color,marker='_',zorder=3)
    axes[1,1].scatter(q.log_integrated_tau_kms,q.residual_dex,s=42,facecolors='white',edgecolors=color,marker=marker,lw=1.3,zorder=4)
    for r in q.itertuples():
        isbe=r.ion=='7Be II'
        axes[0,1].annotate(labels[r.ID],(r.log_integrated_tau_kms,r.observed_log_Wrest_over_lambda),xytext=targets[r.ID],fontsize=10 if isbe else 8,fontweight='bold' if isbe else 'normal',color=color,ha='center',va='center',zorder=10 if isbe else 5,bbox=dict(facecolor='white',edgecolor='none',pad=1.4) if isbe else None,arrowprops=dict(arrowstyle='-',color=color,lw=.9 if isbe else .6,shrinkB=7 if isbe else 6))
for j in [0,1]:
    axes[0,j].plot(x,curve,'k-',lw=1.3,zorder=1)
    axes[0,j].set(xlim=(-.65,2.8),ylim=(-6.7,-3.65))
    axes[1,j].axhline(0,color='.55',lw=.8);axes[1,j].set(ylim=(-.3,.3),xlabel=r'$\log_{10}[S_i/(\mathrm{km\,s^{-1}})]$')
    axes[0,j].legend(loc='lower right',bbox_to_anchor=(.99,.01),fontsize=8,frameon=False)
axes[0,0].set_title('(a) Primary lines (118 transitions)',loc='left',fontsize=11)
axes[0,1].set_title('(b) Diagnostic features',loc='left',fontsize=11)
axes[0,0].set_ylabel(r'$\log_{10}(W_{\rm rest}/\lambda)$');axes[1,0].set_ylabel('Observed - model\n(dex)')
fig.suptitle(r'V1405 Cas | empirical CoG | $C_f=0.8$, $T_{\rm ex}=12146$ K',fontsize=14,y=.975)
fig.subplots_adjust(top=.90,bottom=.16,left=.085,right=.985)
for ext in ['png','pdf']:fig.savefig(R/f'V1405Cas_empirical_CoG_diagnostics.{ext}',dpi=200)
(R/'validation.json').write_text(json.dumps(dict(primary_count=len(primary),diagnostic_count=len(d),Ca_H_excluded=False,
 primary_unchanged=True,primary_EW_RMS=float(np.sqrt(np.mean(primary.residual_dex**2))),
 diagnostic_EW_sources=d[['ID','EW_rest_mA','EW_source']].to_dict('records'),
 diagnostic_normalization='saved corrected CaHK512 nominal values; Fe I signed linear-EW sigma weighted; Na joint display; not abundances',
 residuals='finite-window and background response for Ca Na V; full isolated support for deblended Be',
 Mg3838_three_components=True,Mg_joint_display_control_only=True,Be_doublet_tied=True,uncertainties_propagated=False),indent=2))
print(pd.DataFrame(pars).to_string(index=False))
