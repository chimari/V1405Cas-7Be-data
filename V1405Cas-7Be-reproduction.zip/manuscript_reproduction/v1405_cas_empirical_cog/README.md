# V1405 Cas empirical curve of growth

Manuscript figure with LaTeX label `cog`. Install requirements, unzip `cog_inputs.zip` alongside the scripts, then run `python build.py`.

The build starts from the saved 118-line solution and empirical opacity template at covering fraction 0.8. It generates the diagnostic points and the plot with 16 diagnostic features, including the revised B1 Be II doublet, joint Ca II H/K, and Mg I. The reference PDF is the manuscript graphic.
