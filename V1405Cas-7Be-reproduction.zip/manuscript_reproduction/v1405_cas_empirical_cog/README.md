# V1405 Cas empirical curve of growth (Figure 7)

LaTeX label `cog`. To reproduce the [figure](reference_plot.pdf), install the
dependencies in `requirements.txt`, extract the inputs, and run the renderer.

    unzip cog_inputs.zip
    python build.py

The inputs contain the adopted 118-line fit at a covering fraction of 0.8.
The model equivalent widths and residuals agree with the
[primary-line catalog](../v1405_cas_primary_line_catalog/primary_lines.csv).
The rms log-EW residual is 0.08530 dex. The script writes
`V1405Cas_empirical_CoG_diagnostics.pdf` and the plotted CSVs. The 16
diagnostic features include the B1 Be II doublet, joint Ca II H/K, and Mg I.
