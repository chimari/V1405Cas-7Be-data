# V1405 Cas abundance diagnostics (Figure 12)

LaTeX label `ab`. To reproduce the [figure](reference_plot.pdf), install the
dependencies in `requirements.txt`, extract the inputs, and run the renderer.

    unzip abundance_plot_inputs.zip
    MPLBACKEND=Agg python render_abundance_pattern.py

The renderer writes `empirical_abundance_pattern.pdf` and
`verified_abundance_pattern_points.csv`. Compare the latter with
[reference_points.csv](reference_points.csv). Panel (b) includes an
illustrative one-zone Saha calculation. Panel (c) uses the irradiated
UV025 B1 slab. Capped bars give conditional noise percentiles. The
[caption](caption.tex) gives the Cr II level dispersion.
