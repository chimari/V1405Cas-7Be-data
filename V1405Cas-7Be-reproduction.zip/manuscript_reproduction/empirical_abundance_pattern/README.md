# Empirical abundance pattern for V1405 Cas

Manuscript figure with LaTeX label `ab`. The archive contains the saved inputs for the three panels.

```sh
python -m pip install -r requirements.txt
unzip abundance_plot_inputs.zip
MPLBACKEND=Agg python render_abundance_pattern.py
```

Panel (a) labels the ions and identifies ground-level columns with asterisks. Panels (b) and (c) label elements. Panel (b) shows separate LTE-excitation and Saha series at the observing epoch, including Be without a decay correction. Panel (c) connects the observing-epoch UV025 B1 abundances through Fe and skips V. It also shows the discovery-epoch Be equivalent at the same horizontal position, with an arrow to the observed value at about +100 d. The Be abundance scale uses solar Li.

The renderer uses the saved analysis products and recomputes the conditional percentile bars. The reference CSV includes both Cloudy Be epochs. The reference PDF is the manuscript graphic and `caption.tex` contains its caption.
