import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
I = HERE/'inputs'
a = pd.read_csv(I/'composition_points_previous.csv').set_index('element')
be = pd.read_csv(HERE/'paired_be_draws.csv').set_index('draw')
new = pd.read_csv(I/'no_red_component_summary.csv').set_index('background')
previous = pd.read_csv(I/'model_comparison.csv').set_index('case').loc['center']
delta = new.loc['B1','logN_BeII_ground']-previous.log_be_target
a.loc['Be','observed'] += delta
a.loc['Be',['obs_lo','obs_hi']] = be.log_N_BeII_over_FeII_ground.quantile([.16,.84]).to_numpy()
a.loc['Be',['lte','saha_1040']] += delta
solar = json.loads((I/'solar_reference.json').read_text())['values']
decay_dex = (100/53.22)*np.log10(2)
shift = solar['Fe']['logeps']-solar['Li']['logeps']
a.loc['Be','lte'] -= decay_dex
paired = pd.read_csv(I/'paired_columns_and_ratios.csv').set_index('draw')
lte_draws = be.log_N_BeII_LTE-paired.log_N_FeII+shift
a.loc['Be',['lte_lo','lte_hi']] = lte_draws.quantile([.16,.84]).to_numpy()
center = pd.read_csv(HERE/'verified_cloudy_abundances.csv',index_col=0).cloudy_1040
saha = pd.read_csv(HERE/'verified_saha_offsets.csv',index_col=0).saha_offset
a['saha_1040'] = a.lte + saha.reindex(a.index)
draws = pd.read_csv(HERE/'provisional_abundance_draws_dex.csv').set_index('draw')
names={'Be':'beryllium','Na':'sodium','Mg':'magnesium','Ca':'calcium',
       'Ti':'titanium','Cr':'chromium','Mn':'manganese','Ni':'nickel'}
for symbol, element in names.items():
    a.loc[symbol,'cloudy_1040'] = center[symbol]
    a.loc[symbol,['cloudy_lo','cloudy_hi']] = a.loc[symbol,'cloudy_1040']+draws[element].quantile([.16,.84]).to_numpy()
# The archived Cloudy Be point and its bounds are on the discovery-epoch scale.
cloudy_fields = ['cloudy_1040', 'cloudy_lo', 'cloudy_hi']
be_discovery = a.loc['Be', cloudy_fields].copy()
a.loc['Be', cloudy_fields] -= decay_dex
a.loc['Be', ['cloudy_discovery', 'cloudy_discovery_lo', 'cloudy_discovery_hi']] = be_discovery.to_numpy()
a.drop(columns=['cloudy_1045','saha_1045']).to_csv(HERE/'verified_abundance_pattern_points.csv')

plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False,
                     'pdf.fonttype': 42, 'savefig.dpi': 200})
blue, teal, orange = '#21568a', '#087e76', '#b65f26'
x = np.arange(len(a))

def dots(ax, x, y, low, high, color, marker='o', label=None):
    valid = np.isfinite(low) & np.isfinite(high) & (high > low)
    ax.vlines(x[valid], low[valid], high[valid], color=color, linewidth=1.25, zorder=4)
    for bound in (low, high):
        ax.scatter(x[valid], bound[valid], color=color, marker='_',
                   s=69, linewidths=1.15, zorder=5)
    ax.scatter(x, y, facecolors='white', edgecolors=color, linewidths=1,
               marker=marker, s=19, label=label, zorder=3)

def clean(ax):
    ax.grid(axis='y', alpha=.18)
    ax.set_xlim(-.55, len(a)-.45)

def save(fig, stem):
    for ext in ('pdf', 'png'):
        fig.savefig(HERE / f'{stem}.{ext}', bbox_inches='tight')
    plt.close(fig)

fig, axs = plt.subplots(3, 1, figsize=(8, 8.5), layout='constrained')
ax = axs[0]
ax.plot(x, a.observed, color=blue, linestyle=':', lw=1.2, alpha=.8, zorder=2)
dots(ax, x, a.observed, a.obs_lo, a.obs_hi, blue, label='Column ratio, 16th–84th percentiles where available')
ax.set(title='(a) Ionic and ground-level column ratios', ylabel=r'$\log_{10}[N/N(\mathrm{Fe\,II})]$')
ax.legend(loc='lower right', frameon=False)
ax = axs[1]
# Connect adjacent elements within each series.
ax.plot(x-.15, a.lte, color=orange, linestyle=':', lw=1.1, zorder=2)
ax.plot(x+.12, a.saha_1040, color=teal, linestyle='--', lw=1.1, zorder=2)
dots(ax, x-.15, a.lte, a.lte_lo, a.lte_hi, orange, label='LTE-excitation ionic proxy')
saha_shift = a.saha_1040 - a.lte
dots(ax, x+.12, a.saha_1040, a.lte_lo+saha_shift, a.lte_hi+saha_shift,
     teal, marker='D', label='One-zone Saha (LTE ionization)')
ax.set(title='(b) LTE excitation and ionization comparisons', ylabel=r'$[\mathrm{X/Fe}]$')
ax.legend(loc='lower right', ncol=2, frameon=False, fontsize=8.5)
ax = axs[2]
# Skip elements without an adopted Cloudy abundance.
has_abundance = np.isfinite(a.cloudy_1040)
ax.plot(x[has_abundance], a.cloudy_1040[has_abundance],
        color=blue, linestyle=':', lw=1.2, alpha=.8, zorder=2)
dots(ax, x, a.cloudy_1040, a.cloudy_lo, a.cloudy_hi, blue, label=r'UV025, $\log n_{\rm H}=10.40$')
be_x = a.index.get_loc('Be')
be_now = a.at['Be', 'cloudy_1040']
be_start, be_low, be_high = be_discovery.to_numpy(dtype=float)
ax.annotate('', xy=(be_x, be_now), xytext=(be_x, be_start),
            arrowprops=dict(arrowstyle='->', color=blue, lw=1.0, shrinkA=4, shrinkB=4),
            zorder=2)
dots(ax, np.array([be_x]), np.array([be_start]), np.array([be_low]),
     np.array([be_high]), blue, marker='s')
for value, epoch in [(be_start, 'Discovery (decay-corrected)'), (be_now, 'Observed (+100 d)')]:
    ax.annotate(epoch, (be_x, value), xytext=(8, 0), textcoords='offset points',
                va='center', color=blue, fontsize=8)
ax.set(title='(c) Cloudy non-LTE abundances', ylabel=r'$[\mathrm{X/Fe}]$')
ax.legend(loc='upper right', frameon=False, fontsize=9)
ax.annotate('ionic only', (x[5], -.78), ha='center', color='#555', fontsize=8)
for ax in axs[1:]:
    ax.axhline(0, color='#888', lw=.8)
for ax in axs:
    clean(ax)
ions = [r'$^7$Be II*', 'Na I*', 'Mg I', 'Ca II*', 'Ti II', 'V II', 'Cr II',
        'Mn II', 'Fe II', 'Ni II']
elements = [r'$^7$Be', 'Na', 'Mg', 'Ca', 'Ti', 'V', 'Cr', 'Mn', 'Fe', 'Ni']
axs[0].set_xticks(x, ions)
for ax in axs[1:]:
    ax.set_xticks(x, elements)
fig.supxlabel('* Ground-level column. Be in (b,c) uses solar photospheric Li/Fe.\n'
              'Capped bars show conditional 16th–84th percentiles from measurement noise.', fontsize=8.5)
save(fig, 'empirical_abundance_pattern')

