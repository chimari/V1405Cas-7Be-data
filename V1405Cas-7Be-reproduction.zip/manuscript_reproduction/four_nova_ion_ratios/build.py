HEADER = '\\begin{table}[t]\n\\centering\n\\small\\setlength{\\tabcolsep}{3pt}\n\\begin{lrbox}{\\manuscripttable}\n\\begin{tabular}{lrrlrr}\n\\hline\nNova & $v$ (km s$^{-1}$) & $C_f$ & Ca II & CoG ratio & Thin EW \\\\\n\\hline\n'
FOOTER = '\\hline\n\\end{tabular}\n\\end{lrbox}\n\\aligntablecaption{\\wd\\manuscripttable}\n\\caption{Observed-epoch $^{7}$Be II/Ca II ground-level column ratios in the four nova absorbers.}\n\\label{tab:comparison-ratios}\n\\usebox{\\manuscripttable}\n\\begin{tabnote}\nVelocities are heliocentric. The CoG values use the indicated reference covering fractions and the tied $^{7}$Be II doublet fit. The optically thin comparison uses the rest-frame EWs of the isolated $^{7}$Be II 3131 profile and Ca II K. No ionization or decay corrections enter these ratios. The values depend on the adopted profile and background, particularly for saturated lines.\n\\end{tabnote}\n\\end{table}\n'
BACKSLASHES = '\\\\'
NEWLINE = "\n"

"""Render the manuscript table from archived CoG and EW inputs."""
import csv
from pathlib import Path

HERE = Path(__file__).resolve().parent
GF_RATIO_CA_K_TO_BE_3131 = 10**(0.1163442197517741 + 0.479)


def build_table():
    rows = []
    with (HERE / "inputs.csv").open(newline="", encoding="utf-8") as stream:
        for item in csv.DictReader(stream):
            wave_ratio = float(item["caK_wavelength_A"]) / float(item["be3131_wavelength_A"])
            thin = (float(item["be3131_ew_mA"]) / float(item["caK_ew_mA"])
                    * GF_RATIO_CA_K_TO_BE_3131 * wave_ratio**2)
            cog = item["adopted_joint_ratio"]
            if not cog:
                ratio = float(item["be3131_S_kms"]) / float(item["caK_S_kms"])
                cog = f"{ratio * GF_RATIO_CA_K_TO_BE_3131 * wave_ratio:.2f}"
            rows.append(
                f'{item["nova"]} & ${item["velocity_kms"]}$ & {float(item["cf"]):.2f} & '
                f'{item["ca_lines"]} & {cog} & {thin:.2f} ' + BACKSLASHES
            )
    return HEADER + NEWLINE.join(rows) + NEWLINE + FOOTER


if __name__ == "__main__":
    print(build_table(), end="")
