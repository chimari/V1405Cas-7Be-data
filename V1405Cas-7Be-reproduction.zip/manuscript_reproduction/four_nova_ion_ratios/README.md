# Four-nova ground-level Be II/Ca II comparison

Source for the comparison table in the revised V1405 Cas manuscript (LaTeX label `tab:comparison-ratios`). Run from any directory:

```sh
python3 build.py > rebuilt.tex
diff -u comparison_ratios.tex rebuilt.tex
```

The three comparison-nova rows use the archived diagnostic CoG outputs associated with the adopted composite figures. S is the velocity-integrated optical depth in km/s. The 3131 amplitude represents the tied Be doublet, and Ca II K supplies the comparison column. The V1405 Cas CoG entry is the adopted joint H/K ratio from the revised B1 fit (rounded log ground columns 12.6312 for Be II and 12.8599 for Ca II in cm^-2). Its 3131 EW is 45.69 mÅ and its Ca II K EW is 295.0 mÅ. All four thin conversions use the deblended 3131 EW and Ca II K EW with the same oscillator strengths. Both transitions have ground-level statistical weight 2, so the gf ratio is also the f ratio. The velocities are heliocentric.

These are observing-epoch ratios. Ionization and radioactive decay corrections are outside the scope of this table.

[ionic_ratios.csv](ionic_ratios.csv) gives the values printed in Table 10.
