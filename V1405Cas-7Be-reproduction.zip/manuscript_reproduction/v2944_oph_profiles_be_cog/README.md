# V2944 Oph absorption profiles, Be II blend and empirical curve of growth

Manuscript figure with LaTeX label `fig:comparison-oph`. The Subaru/HDS spectrum used by Tajitsu et al. (2016) was taken 80 days after optical maximum (95.2 days after discovery). The figure uses the -878 km/s component and a reference covering fraction of 0.25. The Na I D doublet inset uses the optical covering fraction of 0.176.

```sh
python -m pip install -r requirements.txt
unzip oph_comparison_inputs.zip
python render_comparison.py
```

The archive contains the normalized metal and diagnostic profiles, the saved Be II and Cr II blend decomposition, and the 21-line empirical CoG, opacity template and diagnostic points. The renderer uses saved fit products. The reference PDF is the exact manuscript graphic.
