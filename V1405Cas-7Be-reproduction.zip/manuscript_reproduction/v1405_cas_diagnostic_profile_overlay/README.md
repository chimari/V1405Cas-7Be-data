# V1405 Cas diagnostic profile overlay

Reproduces the manuscript figure with LaTeX label `diagshape`. Install the requirements and the DejaVu Serif font at the path used in the script, then run `python render_overlay.py`.

The renderer starts from the archived vector profiles. It retains and relabels the Ca II H/K, Na I D, Fe I and V II panels and marks -850 to -825 km/s in the Fe I panel. The V II panel retains the observed and Cr-corrected 3093 profiles. The two audit CSVs document the V II checks, and the reference PDF is the exact manuscript graphic.
