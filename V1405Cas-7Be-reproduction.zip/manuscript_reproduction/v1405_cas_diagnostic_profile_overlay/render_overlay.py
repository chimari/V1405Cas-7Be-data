"""Rebuild the diagnostic overlay and mark the Fe I blue-wing interval."""
from pathlib import Path
import re

import fitz

here = Path(__file__).resolve().parent
with fitz.open(here/'diagnostic_overlay_previous.pdf') as original:
    page = original[0]
    panels = []
    for block in page.get_text('dict')['blocks']:
        for line in block.get('lines', []):
            for span in line['spans']:
                if re.match(r'^\([c-h]\) ',span['text']):
                    panels.append(span)
                    page.add_redact_annot(span['bbox'],fill=False)
    assert len(panels)==6
    page.apply_redactions(images=0,graphics=0,text=0)
    font = '/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf'
    for span in panels:
        label = chr(ord(span['text'][1])-2)
        page.insert_text(span['origin'],f'({label})'+span['text'][3:],
                         fontname='diagnostic_serif',fontfile=font,fontsize=span['size'])
    clip = fitz.Rect(0,166,page.rect.width,page.rect.height)
    with fitz.open() as result:
        result.new_page(width=clip.width,height=clip.height).show_pdf_page(
            fitz.Rect(0,0,clip.width,clip.height),original,0,clip=clip)
        page = result[0]
        panel, = [d['rect'] for d in page.get_drawings() if d['type']=='f'
                  and abs(d['rect'].y0-288.75)<.02 and abs(d['rect'].x0-48.4724)<.02
                  and d['rect'].width>200]
        ticks = []
        for label in ('−850','−825'):
            x, = [(w[0]+w[2])/2 for w in page.get_text('words') if w[4]==label
                  and abs(w[1]-panel.y1)<14 and panel.x0<w[0]<panel.x1]
            ticks.append(x)
        page.draw_rect(fitz.Rect(ticks[0],panel.y0,ticks[1],panel.y1),
                       color=None,fill=(.15,.50,.82),fill_opacity=.13,overlay=True)
        result.save(here/'diagnostic_overlay.pdf',garbage=4,deflate=True)
