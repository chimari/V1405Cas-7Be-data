# UV025 spectral attenuation

LaTeX label `app:uv025`. Run `python3 verify_uv025.py` to check the
attenuation window on the tabulated energy grid of the two archived
Cloudy inputs. The script also verifies that the hydrogen-ionizing
photon flux is shared by the two inputs.
