"""Verify the UV025 attenuation window on the archived Cloudy energy grid."""
from math import cos, log, pi
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
SED = re.compile(r'^\s*(?:interpolate|continue)\s+\(([\d.eE+-]+)\s+([\d.eE+-]+)\)', re.M)
PHI = re.compile(r'^\s*phi\(H\)\s+([\d.eE+-]+)', re.M | re.I)
RYD_E_V = 13.605693


def window(energy):
    if 10.0 < energy < 10.1:
        return (1 - cos(pi * (energy - 10.0) / 0.1)) / 2
    if 10.1 <= energy <= 13.49:
        return 1.0
    if 13.49 < energy < 13.59:
        return (1 + cos(pi * (energy - 13.49) / 0.1)) / 2
    return 0.0


def grid(content):
    return [(float(e), float(f)) for e, f in SED.findall(content)]


def main():
    unfiltered = (HERE / 'unfiltered.in').read_text()
    filtered = (HERE / 'uv025_b1.in').read_text()
    phi = PHI.findall(unfiltered)
    assert len(phi) == 1 and phi == PHI.findall(filtered)
    before, after = grid(unfiltered), grid(filtered)
    assert len(before) == len(after) == 2564
    errors = []
    for (e, before_flux), (e_after, after_flux) in zip(before, after, strict=True):
        assert e == e_after
        actual_tau = (before_flux - after_flux) * log(10)
        errors.append(abs(actual_tau - 0.25 * window(e * RYD_E_V)))
    maximum = max(errors)
    assert maximum <= 1.2e-10, maximum
    print(f'{len(before)} shared nodes; log Phi(H)={phi[0]}; maximum optical-depth discrepancy {maximum:.3g}')


if __name__ == '__main__':
    main()
