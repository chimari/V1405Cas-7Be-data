# Table 8 — Discovery-epoch beryllium mass fractions

The TeX and CSV give the current manuscript values. The EW-to-Cloudy ratio uses the current thin-limit EW estimate. Lower and upper columns retain the CSV layout and coincide for each adopted point estimate. Empty cells mark unavailable or unadopted estimates. The V339 Del value uses the +47 d STIS-shaped slab. See the Figure 17 package for the plotted values and model summaries.
