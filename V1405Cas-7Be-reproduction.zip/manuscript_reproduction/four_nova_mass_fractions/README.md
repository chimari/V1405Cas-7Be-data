# Discovery-epoch beryllium mass fractions (Table 8)
    
`be_mass_fraction_comparison.tex` is the current table source. The two EW estimates use the adopted solar calcium mass fraction; the CoG + Cloudy column uses the model gas composition and the component-specific population correction. See the manuscript for the conversion and time origin. The V339 Del range uses the final snapshot of each of nine runs; see [Figure 18](../comparison_novae_abundance_patterns/README.md).
