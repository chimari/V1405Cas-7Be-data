# Discovery-epoch beryllium mass fractions (Table 12)

LaTeX label `tab:be-mass-comparison`. The
[reference values](be_mass_fraction_comparison.csv) reproduce part
(a). The ratio columns use the current optically thin EW
numerator. The low and high columns agree for a single reference
estimate. Empty fields follow the ellipses or unavailable errors
in the table. The V2944 Oph elemental estimate remains unresolved.

The [trial ranges](mass_fraction_trial_ranges.csv) reproduce part
(b). They retain the distinction between conditional measurement
noise and the extrema of each stated trial set. The values in
part (a) also match [Figure 19](../comparison_novae_abundance_patterns/README.md).

The equivalent daughter lithium abundances in the Table 12 note follow
from the three reference mass fractions in part (a), using
`12 + log10(X_Be * 1.356 / 7)` after complete decay of the inferred
discovery-epoch beryllium inventory.
