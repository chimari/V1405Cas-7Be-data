# Empirical Be II and Cr II decomposition in V1405 Cas

Source for the V1405 Cas manuscript figure identified by the LaTeX label `be`. The adopted B1 fit uses the -793 km/s component and a covering fraction of 0.8. Each of the two 7Be II lines and the neighbouring Cr II line uses one copy of the same weak-line opacity template. The Be doublet strengths are tied through gf times wavelength. The fit adds optical depths before applying partial covering.

Use Python 3.11 or later with the listed dependencies:

```sh
python -m pip install -r requirements.txt
python fit_be_lvc.py
```

The script refits the archived B0 and B1 locally normalized spectra, writes fit profiles and summaries, and renders `be_empirical_B1.pdf`. It checks the B1 model flux and the Be II ground-level column against the saved solution within 2e-6. `be_empirical_B1_reference.pdf` is the exact manuscript graphic. The supplied template and saved comparison-profile CSV contain the subsets used by the script. `fit_summary_reference.csv` records the archived B0/B1 fits. `adopted_be_ews.csv` records the isolated B1 equivalent widths carried into the manuscript and the diagnostic CoG (85.00 and 45.69 mÅ, rounded). The inputs start from the locally normalized B0 and B1 spectra.

The figure uses no separate velocity component for either Be II transition. Blue and red line colours distinguish the short- and long-wavelength members.

The current renderer uses the original B0/B1 fitting procedure and the manuscript's single-column styling for the B1 plot.

