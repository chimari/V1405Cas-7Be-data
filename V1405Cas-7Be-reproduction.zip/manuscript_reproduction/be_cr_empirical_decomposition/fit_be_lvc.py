"""Fit the adopted empirical LVC template to Be II and Cr II only."""
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import least_squares

root = Path(__file__).resolve().parent
prof = pd.read_csv(root/'be_saved_background_profiles.csv')
template = pd.read_csv(root/'opacity_templates.csv').query('Cf == 0.8')
saved = pd.read_csv(root/'be_empirical_profiles.csv').query("case=='empirical08_main_Cr'")
cf, c = .8, 299792.458
lb, lr, lc = 3130.583557665, 3131.228107417, 3132.056630
ratio = 10**(-.479+.178)*lr/lb

def flux(tau):
    return 1-cf+cf*np.exp(-tau)

def phi(v):
    return np.interp(v, template.v_relative_kms, template.phi_per_kms, left=0, right=0)

rows, profiles = [], []
for background, g in prof.groupby('background'):
    w, y = g.wave_air_A.to_numpy(), g.normalized_flux.to_numpy()
    vb, vr, vc = [c*((w/l)**2-1)/((w/l)**2+1)+793 for l in (lb,lr,lc)]
    b, r, cr = phi(vb), ratio*phi(vr), phi(vc)
    def residual(logs):
        strength, cr_strength = 10**logs
        return flux(strength*(b+r)+cr_strength*cr)-y

    fits = [least_squares(residual, start, bounds=(-4,5), max_nfev=250)
            for start in ((1,2),(2,3),(2,2))]
    assert all(f.success for f in fits)
    f = min(fits,key=lambda v: np.sum(v.fun**2))
    strength, cr_strength = 10**f.x
    model = y+f.fun
    log_n = np.log10(2*strength/(1.497e-15*np.sqrt(np.pi)*10**(-.178)*lb))
    rows.append(dict(background=background,logN_BeII_ground=log_n,
                     rms_flux=np.sqrt(np.mean(f.fun**2)),
                     main_blue_strength_kms=strength,Cr_strength_kms=cr_strength,
                     ionic_ground_ratio=10**(log_n-12.859858882272023)))
    q = pd.DataFrame(dict(background=background,wave_air_A=w,observed=y,model=model,residual=y-model,
                          Be3130=flux(strength*b),Be3131=flux(strength*r),CrII=flux(cr_strength*cr)))
    profiles.append(q)
    if background=='B1':
        np.testing.assert_allclose(w,saved.wave_air_A,rtol=0,atol=1e-9)
        np.testing.assert_allclose(model,saved.model,rtol=0,atol=2e-6)
        np.testing.assert_allclose(log_n,12.631200137386307,rtol=0,atol=2e-6)
        b1=q
out = pd.DataFrame(rows).set_index('background')
out.to_csv(root/'no_red_component_summary.csv')
pd.concat(profiles).to_csv(root/'no_red_component_profiles.csv',index=False)
print(out.to_string())
print('B0 minus B1 (dex):',out.loc['B0','logN_BeII_ground']-out.loc['B1','logN_BeII_ground'])

plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'font.size':7.5,'pdf.fonttype':42})
fig, ax = plt.subplots(3,1,figsize=(3.32,3.02),sharex=True,
                       gridspec_kw={'height_ratios':[2.3,1.55,1],'hspace':.16})
w=b1.wave_air_A
ax[0].step(w,b1.observed,where='mid',color='.25',lw=.8,label='HDS (B1)')
ax[0].plot(w,b1.model,color='#226994',lw=1.4,label='LVC fit')
ax[0].legend(loc='lower left',frameon=False,ncol=2,fontsize=7)
for key,color,label in [('Be3130','#226994',r'$^7$Be II 3130'),
                        ('Be3131','#ad3e52',r'$^7$Be II 3131'),
                        ('CrII','#906230','Cr II')]:
    ax[1].plot(w,b1[key],color=color,lw=1.2,label=label)
ax[1].legend(loc='lower left',frameon=False,ncol=3,fontsize=7)
ax[2].axhline(0,color='.65',lw=.7)
ax[2].step(w,b1.residual,where='mid',color='.25',lw=.8)
for axis in ax[:2]:
    axis.set(ylabel='Norm. flux',ylim=(.14,1.09))
ax[2].set(ylabel='Obs. − model',xlabel=r'Air wavelength ($\mathrm{\AA}$)')
for i,axis in enumerate(ax):
    axis.text(.01,.94,f'({chr(97+i)})',transform=axis.transAxes,va='top')
fig.subplots_adjust(left=.17,right=.98,bottom=.15,top=.98)
fig.savefig(root/'be_empirical_B1.pdf')
