# V5668 Sgr absorption profiles, Be II blend and empirical curve of growth

Manuscript figure with LaTeX label `fig:comparison-sgr`. The spectrum is the Subaru/HDS observation used by Tajitsu et al. (2016), taken 69 days after optical maximum (74.4 days after discovery). The plotted component is at -786.2 km/s with covering fraction 0.60.

```sh
python -m pip install -r requirements.txt
unzip sgr_comparison_inputs.zip
python render_comparison.py
```

The renderer starts from saved normalized profiles, the saved Be II and Cr II decomposition, and empirical CoG points and opacity template. It renders the observed and isolated profiles, fitted blend and residuals, and the 38-line CoG with Ca II K and Na I diagnostics. `reference_plot.pdf` is the exact manuscript graphic. Ionization and decay corrections are outside the scope of this figure.
