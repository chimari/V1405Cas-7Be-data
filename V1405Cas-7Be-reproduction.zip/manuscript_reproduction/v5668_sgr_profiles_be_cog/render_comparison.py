import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from pathlib import Path
import json
import matplotlib

C = 299792.458
IONS = ['Fe II', 'Ti II', 'Cr II']
COLORS = ['#2563a0', '#a44a28', '#18806a']


def reduced_width(strength, u, phi, cf):
    return cf*np.trapezoid(-np.expm1(-strength[:,None]*phi),u,axis=1)/C


def profile_panels(fig, axs, key, g, diagnostics, befit, wavelengths, vc, plt):
    c = 299792.458
    solid = ['#a56529','#007361','#275eb0','#9e496b','#68518f']
    for j, (name, v, flux) in enumerate(diagnostics):
        order = np.argsort(v)
        v, flux = np.asarray(v)[order], np.asarray(flux)[order]
        smooth = np.convolve(flux, np.ones(3)/3, 'valid')
        axs[2,0].plot(v[1:-1],smooth, color=solid[j],lw=1.15,label=name.replace('†',' (provisional)'))
    axs[2,0].set_title('Observed diagnostic lines')
    axs[2,0].legend(frameon=False, fontsize=8, ncol=2, loc='lower right')
    ax = axs[2,0]
    lo, hi = ax.get_ylim()
    ax.set_ylim(lo - .19*(hi-lo), hi)

    wave, _, _, parts = befit
    for j, tag, depth in parts:
        if j == 2 or tag == 'blue':
            continue
        if key == 'V5668Sgr':
            rest = (3130.583,3131.228)[j]
            relative = c*(wave/rest-1)-vc
        else:
            center = wavelengths[j]*np.sqrt((1+vc/c)/(1-vc/c))
            relative = c*(wave/center-1)
        axs[2,1].plot(relative,1-depth,lw=1.35,
                      ls='-' if j==0 else '--',color=['#71468d','#ae5978'][j],
                      label=['⁷Be II 3130','⁷Be II 3131'][j])
    title = 'Isolated ⁷Be II fit'
    if key=='V339Del':
        title += ' · red velocity component'
    axs[2,1].set_title(title)
    axs[2,1].legend(frameon=False, fontsize=8, loc='lower right')

    for ax in axs[2]:
        ax.axhline(1,color='.65',lw=.6,zorder=0)
        ax.axvline(0,color='.65',lw=.6,ls='--',zorder=0)
        ax.set(xlim=(g[0],g[-1]), xlabel='Relative velocity (km/s)')
    axs[2,0].set_ylabel('Normalized flux')
    axs[2,1].set_ylabel('Normalized flux')



OUT = Path(__file__).resolve().parent
SOURCE = OUT / 'inputs'
LAM = [3130.583557665,3131.228107417,3132.05663]

def draw(key,title,vc,cf,T,points,u,phi,profiles,befit,diags,lim,diagnostics):
    points = pd.read_csv(SOURCE/f'{key}_metal_CoG.csv')
    diags = pd.read_csv(SOURCE/f'{key}_diagnostics.csv')
    plt.rcParams.update({'font.size':7,'axes.titlesize':7.5,'axes.labelsize':7,
                         'xtick.labelsize':6.5,'ytick.labelsize':6.5,
                         'xtick.major.pad':2,'ytick.major.pad':2})
    fig = plt.figure(figsize=(7.25,5.72))
    gs = fig.add_gridspec(2,2, left=.073,right=.988,bottom=.135,top=.872,
                          width_ratios=[1,1],height_ratios=[1,1.03],wspace=.245,hspace=.36)
    day={'V5668Sgr':69,'V2944Oph':80,'V339Del':47}[key]
    title=title.removesuffix(' +47 d')
    epoch=f'+{day} d from optical maximum'
    discovery_day = {'V5668Sgr': 74.4, 'V2944Oph': 95.2, 'V339Del': 48.7}[key]
    epoch += f' (+{discovery_day:g} d from discovery)'
    fig.text(.073,.970,f'{title}  |  {epoch}  |  {vc:g} km/s',size=10.5,weight='bold')
    fig.text(.073,.922,'(a) Absorption profiles',size=9,weight='bold')
    right = gs[0,1].get_position(fig).x0
    fig.text(right,.922,'(b) ⁷Be II and Cr II decomposition',size=9,weight='bold')
    fig.text(right,gs[1,1].get_position(fig).y1+.018,'(c) Empirical curve of growth',size=9,weight='bold')

    sub = gs[:,0].subgridspec(3,2,hspace=.34,wspace=.18)
    axs = np.empty((3,2),object)
    grid = np.arange(lim[0],lim[1]+.01,.5)
    stack = []
    for (ion,line), seq in profiles.groupby(['ion','line_id']):
        curves = []
        for _, q in seq.groupby('arm'):
            q = q.sort_values('v')
            sm = np.convolve(q.flux,np.ones(3)/3,'valid')
            curves.append(np.interp(grid,q.v.to_numpy()[1:-1],sm,left=np.nan,right=np.nan))
        flux = np.nanmean(curves,axis=0)
        depth = 1-flux
        stack.append((ion, depth/np.nanmax(depth[abs(grid)<=30])))
    assert len(stack)==len(points)
    for i,group in enumerate([None,*IONS]):
        row,col = divmod(i,2)
        ax = axs[row,col] = fig.add_subplot(sub[row,col],sharey=axs[0,0] if i else None)
        traces = [(ion,y) for ion,y in stack if group is None or ion==group]
        for ion,y in traces:
            ax.plot(grid,1-y,color=COLORS[IONS.index(ion)],alpha=.3,lw=.46)
        ax.plot(grid,1-np.nanmedian([y for _,y in traces],axis=0),color='#172836',lw=.95)
        ax.axhline(1,color='.7',lw=.45)
        ax.axvline(0,color='.7',lw=.45,ls='--')
        ax.set(title=f'{group or "All metals"} ({len(traces)})',xlim=lim)
        ax.tick_params(labelbottom=False,labelleft=col==0)
        if col==0: ax.set_ylabel('Depth-scaled flux')
    for col in range(2):
        axs[2,col] = fig.add_subplot(sub[2,col])
    profile_panels(fig,axs,key,grid,diagnostics,befit,LAM,vc,plt)
    axs[2,0].set_title('Observed diagnostics')
    axs[2,1].set_ylabel('')
    axs[2,1].set_title('Isolated ⁷Be II'+(' (red velocity)' if key=='V339Del' else ''))
    for ax in axs[2]:
        ax.set_xlabel('')
        ax.xaxis.set_major_locator(plt.MaxNLocator(4,prune='both'))
        ax.legend(frameon=False,fontsize=5.8,loc='upper center',ncol=2,handlelength=1.1,
                  columnspacing=.7,bbox_to_anchor=(.5,-.22))
    ax = axs[2,0]
    h,l = ax.get_legend_handles_labels()
    ax.legend(h,[q.replace(' (provisional)','†') for q in l],frameon=False,fontsize=5.8,
              loc='upper center',ncol=2,handlelength=1.1,columnspacing=.7,bbox_to_anchor=(.5,-.22))
    fig.text((.073+gs[0,0].get_position(fig).x1)/2,.011,'Relative velocity (km/s)',ha='center')
    if key=='V339Del':
        fig.text(.073,.022,'† Possible Fe I blend',size=5.6)

    begrid = gs[0,1].subgridspec(3,1,height_ratios=[2,1.25,.85],hspace=.09)
    ax = fig.add_subplot(begrid[0])
    bx = fig.add_subplot(begrid[1],sharex=ax)
    rx = fig.add_subplot(begrid[2],sharex=ax)
    w,y,pred,parts = befit
    ax.plot(w,y,color='.36',lw=.65,label='Observed')
    ax.plot(w,pred,color='#17364a',lw=.9,label='Fit')
    ax.legend(frameon=False,ncol=2,loc='upper center',fontsize=6,handlelength=1.5)
    if key=='V339Del':
        ax.set_ylim(top=ax.get_ylim()[1]+.024)
        bx.text(.98,.12,'Dashed: blue velocity',transform=bx.transAxes,ha='right',size=5.4)
    ax.set_ylabel('Norm. flux')
    component_labels=['⁷Be II 3130','⁷Be II 3131','Cr II 3132']
    for j,tag,depth in parts:
        bx.plot(w,depth,c=COLORS[j],ls='--' if tag=='blue' else '-',lw=.85,
                label=component_labels[j] if tag!='blue' else None)
    bx.set_ylabel('Depth')
    bx.yaxis.set_major_locator(plt.MaxNLocator(3,prune='both'))
    bx.legend(frameon=False,ncol=3,fontsize=5.7,loc='upper center',handlelength=1.25,columnspacing=.8)
    bx.set_ylim(top=max(np.nanmax(depth) for _,_,depth in parts)*1.43)
    rx.plot(w,y-pred,color='.32',lw=.57)
    rx.axhline(0,color='.6',lw=.5)
    rx.set(xlabel='Observed air wavelength (Å)',ylabel='Residual')
    ax.tick_params(labelbottom=False)
    bx.tick_params(labelbottom=False)

    cg = gs[1,1].subgridspec(2,1,height_ratios=[2.4,1],hspace=.09)
    ax = fig.add_subplot(cg[0])
    rx = fig.add_subplot(cg[1],sharex=ax)
    na = diags.label.str.startswith('Na')
    main = diags[~na] if key=='V2944Oph' else diags
    s = np.geomspace(min(points.S.min(),main.S.min())*.71,max(points.S.max(),main.S.max())*1.52,400)
    ax.plot(np.log10(s),np.log10(reduced_width(s,u,phi,cf)),color='#17364a',lw=.85)
    for ion,color in zip(IONS,COLORS):
        q = points[points.ion.eq(ion)]
        x = np.log10(q.S)
        ax.scatter(x,np.log10(q.ew/(1000*q.wavelength)),s=9,color=color,zorder=3)
        ax.scatter(x,np.log10(q.ew_model/(1000*q.wavelength)),s=12,facecolor='none',edgecolor=color,marker='s',lw=.52)
        rx.scatter(x,np.log10(q.ew/q.ew_model),s=8,color=color,label=ion)
    offsets = {'⁷Be II 3130':(-5,-13),'⁷Be II 3131':(-9,8),'Ca II K':(-5,13),
               'Na I D2':(4,-11),'Na I D1':(5,-9),'Ni II 3374':(5,-12),'Mn II 3442†':(-7,8)}
    if key=='V5668Sgr':
        offsets.update({'Ca II K':(2,18),'⁷Be II 3131':(-17,16),
                        '⁷Be II 3130':(1,9),'Na I D2':(9,-15),'Na I D1':(-5,-25)})
    if key=='V339Del':
        offsets.update({'Ca II K':(-6,16),'⁷Be II 3130':(-3,-22),'⁷Be II 3131':(-12,9)})
    if key=='V2944Oph':
        offsets.update({'Ca II K':(-7,13),'⁷Be II 3130':(4,6),'⁷Be II 3131':(-8,9)})
    for q in main.itertuples():
        ion = ' '.join(q.label.split()[:2])
        color, marker = {'⁷Be II':('#7656a6','o'), 'Ca II':('#ca7937','s'),
                         'Na I':('#278b79','^'), 'Ni II':('#454c67','h'),
                         'Mn II':('#454c67','d')}[ion]
        x,y = np.log10(q.S), np.log10(q.ew/(1000*q.wavelength))
        ax.scatter(x,y,s=21,facecolor='white',edgecolor=color,marker=marker,lw=.85,zorder=5)
        if not q.label.startswith(('⁷Be','Ca','Na')):
            continue
        dx,dy = offsets[q.label]
        ax.annotate(q.label,(x,y),xytext=(dx,dy),textcoords='offset points',
                    color=color,ha='right' if dx<0 else 'left',fontsize=5.8,
                    arrowprops=dict(arrowstyle='-',lw=.45,color=color))
    ax.legend(handles=[Line2D([],[],color='#17364a',lw=.85,label='Reference CoG'),
                       Line2D([],[],marker='o',ms=3,ls='',c='.32',label='Observed EW'),
                       Line2D([],[],marker='s',ms=3,ls='',mfc='none',mec='.32',label='Native-sampling model')],
              loc='upper left',frameon=False,fontsize=5.7,handlelength=1.6)
    ax.text(.98,.035,rf'$C_f={cf:.2f}$ · $T_{{\rm ex}}={T:,.0f}$ K',
            transform=ax.transAxes,ha='right',size=6)
    if key=='V2944Oph':
        inset = ax.inset_axes([.61,.19,.35,.35])
        q = diags[na]
        sv = np.geomspace(q.S.min()*.69,q.S.max()*1.45,150)
        inset.plot(np.log10(sv),np.log10(reduced_width(sv,u,phi,.176)),color='#66788c',lw=.6)
        inset.scatter(np.log10(q.S),np.log10(q.ew/(1000*q.wavelength)),s=12,facecolor='white',
                      edgecolor='#278b79',marker='^',lw=.65,zorder=5)
        for n in q.itertuples():
            d2 = n.label.endswith('2')
            inset.annotate(n.label.split()[-1],(np.log10(n.S),np.log10(n.ew/(1000*n.wavelength))),
                           xytext=(-3,4) if d2 else (4,-4),textcoords='offset points',
                           ha='right' if d2 else 'left',va='bottom' if d2 else 'top',
                           fontsize=4.7,color='#425579')
        inset.set_title(r'Na I  $C_f=0.176$',fontsize=5.5,pad=1)
        inset.locator_params(axis='both',nbins=3)
        inset.tick_params(labelsize=4.7,pad=1,length=2)
    ax.margins(x=.17,y=.25)
    ax.set_ylabel(r'$\log_{10}(W_\lambda/\lambda)$')
    ax.tick_params(labelbottom=False)
    rx.axhline(0,color='.55',lw=.5)
    rx.legend(ncol=3,frameon=False,fontsize=5.5,loc='lower left',handletextpad=.2,columnspacing=.8)
    rx.set(xlabel=r'$\log_{10}$ integrated optical depth (km/s)',ylabel='EW residual\n(dex)')
    for ext in ['pdf','png']:
        fig.savefig(OUT/f'{key}_profiles_Be_CoG.{ext}',dpi=190,bbox_inches='tight',pad_inches=.035)
    plt.close(fig)

if __name__ == '__main__':
    matplotlib.use('Agg')
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,
                         'axes.spines.right':False,'pdf.fonttype':42})
    solution = json.loads((SOURCE/'reference_solution.json').read_text())
    template = pd.read_csv(SOURCE/'reference_opacity_template.csv')
    native = pd.read_csv(SOURCE/'metal_profiles.csv.gz', float_precision='round_trip').rename(
        columns={'v_relative_kms':'v', 'normalized_flux':'flux'})
    fit = pd.read_csv(SOURCE/'reference_BeCr_profile.csv')
    fit = fit[fit.wavelength_air_A.between(3121.2,3124.8)]
    parts = [(i,'',1-fit[k]) for i,k in enumerate(['Be_blue_alone','Be_red_alone','Cr_alone'])]
    diag = pd.read_csv(SOURCE/'diagnostic_profiles.csv.gz', float_precision='round_trip')
    diagnostics = [(label,q.v_relative_kms,q.normalized_flux)
                   for code,label in [('Ca_K','Ca II K'),('Na_D2','Na I D₂'),('Na_D1','Na I D₁')]
                   for q in [diag[diag.name.eq(code)]]]
    draw('V5668Sgr','V5668 Sgr',-786.2,.6,solution['T_exc_K'],None,
         template.v_relative_kms.to_numpy()/(1-786.2/C),template.phi_per_kms.to_numpy(),
         native,(fit.wavelength_air_A,fit.observed,fit.model,parts),None,(-110,110),diagnostics)
