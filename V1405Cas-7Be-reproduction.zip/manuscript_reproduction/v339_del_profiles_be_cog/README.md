# V339 Del absorption profiles, Be II blend and empirical curve of growth

Manuscript figure with LaTeX label `fig:comparison-del`. The Subaru/HDS spectrum used by Tajitsu et al. (2015) was taken 47 days after optical maximum (approximately 48.7 days after discovery). The blend model includes blue and red velocity components. The CoG and isolated Be II profiles refer to the -1103 km/s red component at covering fraction 0.30.

```sh
python -m pip install -r requirements.txt
unzip del_comparison_inputs.zip
python render_comparison.py
```

The input ZIP contains normalized profiles, fitted blend and component depths, and the 29-line empirical CoG, opacity template, and diagnostic points for Be II, Ca II K, Ni II and provisional Mn II. The renderer uses saved fit products. The reference PDF is the exact manuscript graphic.
