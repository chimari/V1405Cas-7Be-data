# V1405 Cas photoionization sensitivity (Table 8)

LaTeX label `tab:photoionization-pilot`. The
[compiled CSV](photoionization_trials.csv) gives the reported
quantities at full precision for the 14 rows, including unfiltered
Ca/H adjustment and the two Fe-rich reclosures.

The `sources/` directory contains the original local trial, joint
grid, and reclosure summaries. A model passes when the Fe I and Fe II
rms log-EW residuals are each at most 0.20 dex and the absolute Balmer
residual is at most 0.10 dex. Four of the 54 joint-grid cases meet all
three criteria. Use the columns with `at_target` in their names to
compare models at shared observational targets. The separate columns
for model Be/Ca, Be/H and daughter Li/Fe use each run's own columns.
