"""Rebuild the UV025 B1 ionization correction from saved Cloudy columns."""
from pathlib import Path
import re

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

out = Path(__file__).resolve().parent


def read_columns(name):
    with (out / 'cloudy_columns' / name).open() as stream:
        header = stream.readline().strip().removeprefix('#column density ').split('\t')
        return pd.DataFrame(np.loadtxt(stream, ndmin=2), columns=header).iloc[0]


ions = read_columns('model.ions')
ground_columns = {
    'Be': read_columns('model.be2col')['Be+[1]'],
    'Ca': read_columns('model.ca2col')['Ca+[1]'],
}

# Stage sums from model.ions and ground levels from the separate level outputs.
population = {}
for element in ('Be','Ca'):
    ion = ions[element+'+']
    names = [name for name in ions.index if re.fullmatch(element+r'(?:\+\d*)?', name)]
    total = ions[names].sum()
    ground = ground_columns[element]
    population[element] = dict(total_column=total, ion_column=ion, ground_column=ground,
        ion_fraction=ion/total, ground_fraction_within_ion=ground/ion,
        ground_fraction_of_element=ground/total)
    assert 0 < ground/ion < 1.001 and 0 < ion/total <= 1
pop = pd.DataFrame(population).T
pop.to_csv(out/'ionization_fractions.csv',index_label='element')
kg = pop.loc['Ca','ground_fraction_of_element']/pop.loc['Be','ground_fraction_of_element']
model_ratio = pop.loc['Be','total_column']/pop.loc['Ca','total_column']
ground_ratio = pop.loc['Be','ground_column']/pop.loc['Ca','ground_column']
np.testing.assert_allclose(model_ratio, kg*ground_ratio, rtol=1e-12)
be_target = 12.631200110355929
ca_target = 12.859858882272023
ratio_target = 10**(be_target-ca_target)
summary = dict(K_g=kg, model_elemental_Be_Ca=model_ratio, model_ground_BeII_CaII=ground_ratio,
               target_ground_BeII_CaII=ratio_target, target_ratio_times_K_g=ratio_target*kg,
               Be_ground_residual_dex=np.log10(pop.loc['Be','ground_column'])-be_target,
               Ca_ground_residual_dex=np.log10(pop.loc['Ca','ground_column'])-ca_target)
pd.DataFrame([summary]).to_csv(out/'ionization_summary.csv',index=False)
print(pd.Series(summary).to_string())

fig, ax = plt.subplots(figsize=(3.55,2.30))
fig.subplots_adjust(left=.32,right=.98,top=.72,bottom=.30)
fig.suptitle(r'UV025 B1, $\log(n_{\rm H}/{\rm cm}^{-3})=10.40$',
             x=.65,y=.98,fontsize=9.5)
y = np.arange(3)[::-1]
fields = ['ion_fraction','ground_fraction_within_ion','ground_fraction_of_element']
for i, pos in enumerate(y):
    if i % 2 == 0:
        ax.axhspan(pos-.46,pos+.46,color='#f3f6f8',zorder=0)
for element, shift, marker, color in [
        ('Be', .15, 'o', '#235f99'),
        ('Ca', -.15, 'D', '#ad4d24'),
]:
    values = pop.loc[element,fields].to_numpy()
    ax.scatter(values,y+shift,s=22,color=color,marker=marker,label=element,zorder=3)
    for value, pos in zip(values,y+shift):
        if value >= .99:
            label = f'{value:.5f}'
        elif value < .001:
            exponent = int(np.floor(np.log10(value)))
            label = rf'${value/10**exponent:.3f}\times10^{{{exponent}}}$'
        else:
            label = f'{value:.3f}'
        side = -1 if value >= .1 else 1
        ax.annotate(label,(value,pos),xytext=(4*side,0),textcoords='offset points',
                    ha='right' if side<0 else 'left',va='center',fontsize=7.4,color=color)
exponent = int(np.floor(np.log10(kg)))
fig.text(.65,.038,rf'$K_g={kg/10**exponent:.3f}\times10^{{{exponent}}}$',
         ha='center',fontsize=8.5)
ax.set(xscale='log',xlim=(7e-5,1.26),ylim=(-.5,2.5),
       xlabel='Slab-integrated population fraction',yticks=y,
       yticklabels=['Ion II / element','Ground / ion II','Ground / element'])
ax.set_xticks(10.**np.arange(-4,1))
ax.grid(axis='x',which='major',alpha=.26)
ax.tick_params(axis='y',length=0,pad=4,labelsize=7.5)
ax.tick_params(axis='x',length=3,pad=2,labelsize=7.5)
ax.xaxis.label.set_size(8)
ax.spines[['top','right','left']].set_visible(False)
fig.legend(loc='center',bbox_to_anchor=(.65,.82),ncol=2,frameon=False,fontsize=8,
           columnspacing=1.2,handletextpad=.25)
fig.savefig(out/'uv025_b1_ionization_correction.pdf')
