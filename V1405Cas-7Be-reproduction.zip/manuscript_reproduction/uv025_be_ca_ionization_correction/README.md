# UV025 B1 Be and Ca ionization correction

V1405 Cas manuscript figure with LaTeX label `cloud`. Run:

```sh
python -m pip install -r requirements.txt
python render_ionization_correction.py
```

The three files in `cloudy_columns/` are unmodified integrated column outputs from the converged UV025 B1 recheck at log n_H = 10.40 (cm^-3). The renderer sums the saved stages of each element, derives its stage-II and ground-level fractions, and computes K_g as the ratio of the Ca and Be ground-level fractions relative to the respective elemental columns. It writes the plot, fractions, and ratio summary. Reference files record the manuscript PDF and archived numerical results.

Source archive: `V1405Cas_UV025_revised_B1_recheck_return.zip` (SHA-256 `3b7493232197a1e06c88c4ddeab5df760872bd837cbceff322ebffd63577b293`). This is a plot reconstruction from saved Cloudy outputs.
