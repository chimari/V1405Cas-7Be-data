"""Reconstruct cumulative columns from the saved final Cloudy zones."""
from pathlib import Path
import zipfile

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

out = Path(__file__).resolve().parent
with zipfile.ZipFile(out / 'cloudy_depth_outputs.zip') as src:
    def table(name, prefix):
        with src.open(name) as f:
            header = f.readline().decode().strip().removeprefix(prefix).split('\t')
            return pd.DataFrame(np.loadtxt(f, ndmin=2), columns=header)

    overview = table('model.ovr', '#')
    structure = table('model.ca_structure', '#')
    density = table('model.densities', '#')
    ions = table('model.ions', '#column density ').iloc[0]
    n_h = 10**10.40
    total_h = ions['H'] + ions['H+']
    columns = {
        'Be II ground': (structure['Be+[1]'], table('model.be2col', '#column density ').iloc[0]['Be+[1]']),
        'Ca II ground': (structure['Ca+[1]'], table('model.ca2col', '#column density ').iloc[0]['Ca+[1]']),
        'Fe II total': (density['Fe+'], ions['Fe+']),
    }

z = overview.depth.to_numpy()
for t in (structure, density):
    np.testing.assert_array_equal(z, t['depth densities'])
edges = np.r_[0, (z[:-1]+z[1:])/2, total_h/n_h]
widths = np.diff(edges)
assert (widths > 0).all()
nh_edge = edges*n_h
df = pd.DataFrame({'depth_cm': edges, 'NH_cm-2': nh_edge})
stats = []
fig, (top, bottom) = plt.subplots(2, 1, figsize=(6.2, 5), sharex=True, layout='constrained')
top.plot(z*n_h/1e22, overview.HI, color='#303030')
top.set(ylabel='Neutral H fraction', ylim=(0, 1.04))
for (name, (values, ref)), color, style in zip(columns.items(), ['#235f99', '#ad4d24', '#555555'], ['-', '-', '--']):
    cum = np.r_[0, np.cumsum(values.to_numpy()*widths)]
    np.testing.assert_allclose(cum[-1], ref, rtol=0.002)
    fraction = cum/cum[-1]
    df[name+' cumulative cm-2'] = cum
    df[name+' cumulative fraction'] = fraction
    q10, q50, q90 = np.interp([.1, .5, .9], fraction, nh_edge)
    stats.append([name, ref, cum[-1], cum[-1]/ref-1, q10, q50, q90])
    bottom.plot(nh_edge/1e22, fraction, label=name, color=color, linestyle=style)
bottom.axhline(.5, color='#aaa', linewidth=.7, zorder=0)
bottom.set(xlabel=r'H column from illuminated face ($10^{22}$ cm$^{-2}$)',
           ylabel='Cumulative column fraction', ylim=(0, 1.04), xlim=(0, total_h/1e22))
bottom.legend(loc='upper left', frameon=False)
fig.suptitle(r'UV025 B1, $\log(n_{\rm H}/{\rm cm}^{-3})=10.40$')
fig.savefig(out/'UV025_B1_depth_profiles.pdf')
df.to_csv(out/'depth_cumulative.csv', index=False)
pd.DataFrame(stats, columns=['quantity','cloudy_column_cm-2','reconstructed_column_cm-2',
                              'relative_difference','NH_p10_cm-2','NH_p50_cm-2','NH_p90_cm-2']
             ).to_csv(out/'depth_summary.csv', index=False)

