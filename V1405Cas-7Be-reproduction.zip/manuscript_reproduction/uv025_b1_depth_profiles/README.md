# UV025 B1 slab depth profiles

V1405 Cas manuscript figure with LaTeX label `depth`. Install the dependencies with `python -m pip install -r requirements.txt`, then run `python render_depth_profiles.py`.

The ZIP contains six unmodified output tables from the UV025 B1 recheck at log n_H = 10.40 (cm^-3). The script estimates zone widths using adjacent zone centres and the total H column, plots the neutral H fraction and cumulative Be II and Ca II ground-level and total Fe II columns, and writes cumulative profiles and 10/50/90 percent accumulation depths. It checks the reconstructed totals against the saved columns. The reference PDF is the exact manuscript graphic.

Source archive: `V1405Cas_UV025_revised_B1_recheck_return.zip` (SHA-256 `3b7493232197a1e06c88c4ddeab5df760872bd837cbceff322ebffd63577b293`). The reconstruction starts from saved Cloudy outputs.
