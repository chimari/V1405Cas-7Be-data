# Covering sensitivity of the comparison novae (Table 9)

LaTeX label `tab:comparison-covering`. The
[scan](covering_scan.csv) contains the 20 discrete trials with the
blend floor checks and observational CoG ⁷Be II/Fe II ratios. The
[summary](covering_summary.csv) gives the reference and extrema in
unscaled units. Multiply the ratio columns by 1000 to match the TeX
table. The scan holds the template shape and excitation fixed.
