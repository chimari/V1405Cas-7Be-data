"""Update only the provisional V339 Del Cloudy symbols in Fig. 18(c)."""
import csv
from pathlib import Path

import fitz

root = Path(__file__).resolve().parent
fig = fitz.open(root / "initial_reference_plot.pdf")
page = fig[0]
with (root / "v339del_final_snapshots.csv").open() as stream:
    runs = list(csv.DictReader(stream))
assert len(runs) == 9
be = [float(run["cloudy_Be_Fe_observed_dex"]) for run in runs]
ca = [float(run["cloudy_Ca_Fe_dex"]) for run in runs]
from math import log10
decay = 48.7 / 53.22 * log10(2)

# Erase the original markers and intervals; retain axes, grid, and text.
for area in [(373.5, 274.5, 382, 286.5), (420, 325, 428, 332)]:
    page.add_redact_annot(fitz.Rect(*area), fill=False, cross_out=False)
page.apply_redactions(images=0, graphics=1, text=1)
blue = (40/255, 92/255, 148/255)
white = (1, 1, 1)
zero = 334.8807373046875
unit = (zero - 284.62103271484375) / 3
def draw(marker_x, values, filled):
    plot_y = lambda value: zero - value * unit
    top, bottom = plot_y(max(values)), plot_y(min(values))
    center = (top + bottom) / 2
    side = 2.35
    page.draw_rect((marker_x-side, center-side, marker_x+side, center+side),
                   color=blue, fill=blue if filled else white, width=1.05)
    x = marker_x + 5.1
    page.draw_line((x, top), (x, bottom), color=blue, width=0.85)
    for y in (top, bottom):
        page.draw_line((x-1.3, y), (x+1.3, y), color=blue, width=0.85)
draw(371.9, be, False)
draw(381.5, [value + decay for value in be], True)
draw(423.8, ca, False)
fig.save(root / "comparison_novae_abundance_patterns.pdf", garbage=4, deflate=True)
