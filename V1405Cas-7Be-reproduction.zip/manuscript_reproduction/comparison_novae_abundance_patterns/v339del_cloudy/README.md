# V339 Del Cloudy iteration check

Each model folder contains the input deck, the saved ion and level-column histories used in the analysis, final columns, and the final depth profile. The text extract preserves the reported gas-phase composition and normal-exit line from the run log.

Run `python3 assess.py` to regenerate the nine-run numerical summary used in section 8.2. The manuscript uses one final snapshot per run for Table 8 and Figure 18(c).
