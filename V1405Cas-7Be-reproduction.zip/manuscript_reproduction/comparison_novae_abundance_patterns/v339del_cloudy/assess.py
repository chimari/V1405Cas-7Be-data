from pathlib import Path
from math import log10
import csv,json,re
P=Path(__file__).parent
t=json.loads((P/'observational_targets.json').read_text())
def load(p):
 return [[float(s) for s in l.split()] for l in p.read_text().splitlines() if l.strip() and not l.startswith('#')]
atomic_mass = dict(zip(
 "H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn".split(),
 [1.008,4.003,6.94,9.012,10.81,12.011,14.007,16,19,20.18,22.99,24.305,26.982,28.085,30.974,32.06,35.45,39.948,39.098,40.078,44.956,47.867,50.942,51.996,54.938,55.845,58.933,58.693,63.546,65.38],
 strict=True))
rows=[]
for r in csv.DictReader((P/'grid.csv').open()):
 p=P/'models'/r['name']
 h={k:load(p/('model.'+k+'history')) for k in ['ca2','be2','na1','ions']}
 assert all(len(v)==32 for v in h.values())
 arr=h['ions']; ca=[c[0] for c in h['ca2']];be=[c[0] for c in h['be2']];na=[c[0] for c in h['na1']]
 caf=[ca[i]/sum(v[7:14]) for i,v in enumerate(arr)]
 bef=[be[i]/sum(v[21:26]) for i,v in enumerate(arr)]
 kg=[a/b for a,b in zip(caf,bef)]
 def span(x,n):return log10(max(x[-n:])/min(x[-n:]))
 for k,v in [('ca2',ca),('be2',be),('na1',na),('ions',arr)]:
  a=load(p/('model.'+k+('' if k=='ions' else 'col')))[-1]
  assert a==v[-1] if k=='ions' else a[0]==v[-1]
 out=(p/'model.out.extract.txt').read_text()
 assert 'Cloudy exited OK' in out
 row=dict(logU=float(r['log_U']),mode=r['mode'],logCa=log10(ca[-1]),Ca_res=log10(ca[-1])-t['log_N_CaII_ground'],Na=na[-1],CaSpan3=span(ca,3),CaSpan8=span(ca,8),Kg=kg[-1],KgSpan8=span(kg,8),BeCa=kg[-1]*t['BeII_CaII_ground_ratio'],Ca_g=caf[-1],Be_g=bef[-1],Ca_g_ion=ca[-1]/arr[-1][8],Be_g_ion=be[-1]/arr[-1][22],CaIII=arr[-1][9]/sum(arr[-1][7:14]))
 mix=out.split('Gas Phase Chemical Composition',1)[1].split('####',1)[0]
 abund={el:float(value) for el,value in re.findall(r'\b([A-Z][a-z]?)\s*:\s*(-?\d+\.\d+)',mix)}
 assert abund.keys()==atomic_mass.keys()
 xca=atomic_mass['Ca']*10**abund['Ca']/sum(atomic_mass[k]*10**v for k,v in abund.items())
 row.update(XCa=xca,XBe_discovery=7/40*row['BeCa']*xca*2**(48.7/53.22))
 rows.append(row)
 print(' '.join(f'{k}={v:.5g}' if isinstance(v,float) else f'{k}={v}' for k,v in row.items()))
with (P/'summary.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
