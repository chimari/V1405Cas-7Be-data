# Three comparison-nova abundance patterns (Figure 18)

The current manuscript graphic is `reference_plot.pdf`. Install `requirements.txt` and run `python render.py` to reproduce it from `initial_reference_plot.pdf` and `v339del_final_snapshots.csv`. The latter contains the nine 32-iteration V339 Del runs (three ionization parameters by three spatial zoning choices). The Cloudy ranges in panel (c) use one final snapshot per run. Open squares show the observing epoch; filled Be squares include the decay correction to discovery. Bars give the model spans and markers their midpoints. No elemental Na value is adopted for V339 Del.

The LTE-excitation and Saha series in panels (a) and (b) retain the original data; V339 Del Saha spans use the initial three Ca-adjusted models. `composition_points.csv` and `model_points.csv` preserve the input to that initial plot, including its legacy Cloudy values; use the nine-run CSV for the current V339 Del Cloudy comparison.

The regenerated current figure has been compared pixel-for-pixel with the manuscript reference at 144 dpi.


[Cloudy inputs and diagnostic outputs](v339del_cloudy/README.md) reproduce the nine-run summary, including the iteration spans and calcium normalization.
