# Abundances in the four nova absorbers (Figure 19)

LaTeX label `fig:comparison-abundance-patterns`. Install the dependencies
in `requirements.txt` and run `python plot.py` to reproduce the
[figure](reference_plot.pdf). The script writes
`rebuilt_comparison_novae_abundance_patterns.pdf` and four plotted CSVs.

- [Be and daughter lithium relative to iron](be_li_fe_comparison.csv).
  The V1405 Cas ionic point uses the CoG Fe II column. Its elemental
  point uses the slab Fe II stopping column, 0.45 dex higher. The
  V2944 Oph elemental point is the conditional baseline trial.
- [Discovery-epoch ⁷Be mass fractions](method_mass_fractions.csv).
  The plotting input includes a copy of the Abstract-final
  [Table 12 TeX](inputs/tables/be_mass_fraction_comparison.tex).
- [Ti and Cr relative to iron](ti_cr_comparison.csv). The inputs retain
  the relevant lines from the final Cloudy column-density output.
  [SHA-256 checksums](inputs/ionic_column_extracts/SHA256SUMS-original.txt)
  identify the full model outputs supplied with the manuscript package.
- [Plotted intervals](uncertainty_intervals.csv) gives the conditional
  measurement noise, published errors, and V5668 Sgr profile-trial extrema.

The [caption](caption.tex) describes the plotted quantities. The older
three-nova composition plot uses `render.py` and its original inputs.
