import json
import math
from pathlib import Path
from statistics import fmean, stdev

HERE = Path(__file__).resolve().parent
HEADER = '\\begin{table}[t]\n\\caption{Lower-level column residuals in the UV025 B1 slab.}\n\\label{tab:level-residuals}\n\\centering\\small\n\\begin{tabular}{lrrr}\n\\hline\nIon & Target levels & $s_{\\rm lev}$ (dex) & $\\max |r_l|$ (dex)\\\\\n\\hline\n'
FOOTER = '\\hline\n\\end{tabular}\n\\begin{tabnote}\n$s_{\\rm lev}$ is the sample dispersion over distinct lower levels (equation~\\ref{eq:level-scatter}). Each ion meets the mean-residual convergence criterion $|\\overline r|\\leq0.001$ dex. The dispersion and maximum residual describe the remaining level-population mismatch.\n\\end{tabnote}\n\\end{table}\n'

def main():
    elements = json.loads((HERE / 'v14recheck_assessment.json').read_text())['elements']
    print(HEADER, end='')
    for ion, element, count in [('Ti II','titanium',24), ('Cr II','chromium',19),
                                ('Mn II','manganese',4), ('Ni II','nickel',3)]:
        data = elements[element]
        levels = data['individual_residuals_dex']
        assert len(levels) == count
        mean, scatter, maximum = fmean(levels), stdev(levels), max(map(abs, levels))
        assert abs(mean) <= 0.001
        for key, value in [('mean_residual_dex', mean), ('level_scatter_dex', scatter),
                           ('max_level_residual_dex', maximum)]:
            assert math.isclose(value, data[key], rel_tol=1e-12, abs_tol=1e-12)
        print(rf'{ion} & {count} & {scatter:.3f} & {maximum:.3f}\\')
    print(FOOTER, end='')

if __name__ == '__main__':
    main()
