import json
import math
from pathlib import Path
from statistics import fmean, stdev

HERE = Path(__file__).resolve().parent
HEADER = '\\begin{table}[t]\n\\caption{Lower-level column residuals in the revised UV025 B1 slab.}\n\\label{tab:level-residuals}\n\\centering\\small\n\\begin{tabular}{lrrrr}\n\\hline\nIon & $L_{\\rm X}$ & $\\overline r$ & $s_{\\rm lev}$ & $\\max|r_l|$\\\\\n & & (dex) & (dex) & (dex)\\\\\n\\hline\n'
FOOTER = '\\hline\n\\end{tabular}\n\\begin{tabnote}\nResiduals use the empirical-template targets and final UV025 B1 iteration. Positive $r_l$ denotes an overpredicted level column. Values are unweighted over distinct levels. The sample standard deviation $s_{\\rm lev}$ uses divisor $L_{\\rm X}-1$ (equation~\\ref{eq:level-scatter}). A single-level target cannot constrain a level-to-level dispersion. The Fe EW and Balmer screens are defined in subsection~\\ref{sec:cloudy-grid}; their values for the reference slab are reported in subsection~\\ref{sec:empirical-abundances}.\n\\end{tabnote}\n\\end{table}\n'

def main():
    elements = json.loads((HERE / 'v14recheck_assessment.json').read_text())['elements']
    print(HEADER, end='')
    for ion, element, count in [('Ti II','titanium',24), ('Cr II','chromium',19),
                                ('Mn II','manganese',4), ('Ni II','nickel',3)]:
        data = elements[element]
        levels = data['individual_residuals_dex']
        assert len(levels) == count
        mean, scatter, maximum = fmean(levels), stdev(levels), max(map(abs, levels))
        for key, value in [('mean_residual_dex', mean), ('level_scatter_dex', scatter),
                           ('max_level_residual_dex', maximum)]:
            assert math.isclose(value, data[key], rel_tol=1e-12, abs_tol=1e-12)
        print(rf'{ion} & {count} & ${mean:+.6f}$ & {scatter:.3f} & {maximum:.3f}\\')
    print(FOOTER, end='')

if __name__ == '__main__':
    main()
