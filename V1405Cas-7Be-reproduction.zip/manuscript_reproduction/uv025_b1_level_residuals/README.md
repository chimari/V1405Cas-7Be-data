# UV025 B1 lower-level column residuals

Source for the manuscript table with LaTeX label `tab:level-residuals`. Run `python3 build_table.py > rebuilt.tex` and compare with `level_residuals.tex`.

The input is the saved assessment of the revised UV025 B1 slab. The script recomputes the unweighted mean, sample standard deviation, and largest absolute residual for each ion from the saved per-level residuals. Positive residuals indicate model columns above the targets.

The table, assessment, and manuscript equation `eq:level-scatter` use divisor L-1 for the sample standard deviation across distinct levels.
