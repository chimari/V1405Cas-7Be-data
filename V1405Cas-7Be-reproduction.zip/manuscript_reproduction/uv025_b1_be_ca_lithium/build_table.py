import csv
from pathlib import Path

HERE = Path(__file__).resolve().parent
HEADER = '\\begin{table*}[t]\n\\centering\n\\small\n\\begin{lrbox}{\\manuscripttable}\n\\begin{tabular}{@{}lcccc@{}}\n\\hline\n\\multicolumn{5}{@{}l}{\\textit{(a) Reference values, conditional noise intervals, and compact trials}} \\\\\n & \\multicolumn{2}{c}{UV025 B1} & \\multicolumn{2}{c}{Compact slabs} \\\\\nQuantity & Reference & Noise, 16th--84th percentile & $\\log n_{\\rm H}=10.74$ & 10.82 \\\\\n\\hline\n'
MIDTABLE = '\\hline\n\\multicolumn{5}{@{}l}{\\textit{(b) Minimum--maximum over specified sensitivity trials}} \\\\\n\\multicolumn{2}{@{}l}{Trial set} & Ground-level $^{7}$Be II/Ca II & $^{7}{\\rm Be/Ca}$ ($10^{-4}$) & \\liiso/Fe ($10^{-5}$) \\\\\n\\hline\n'
FOOTER = "\\hline\n\\end{tabular}\n\\end{lrbox}\n\\aligntablecaption{\\wd\\manuscripttable}\n\\caption{V1405 Cas reference abundances, conditional noise intervals, and sensitivity trials.}\n\\label{tab:empirical-be}\n\\usebox{\\manuscripttable}\n\\par\\smallskip\n\\parbox{\\wd\\manuscripttable}{\\footnotesize\n(a) The noise percentiles use the adopted B1 background and covering, and the elemental intervals propagate measurement noise through the local Cloudy response. The compact trials apply their own $K_g$ to the reference ionic ratio. The compact slabs share the optical flux normalization, Fe/H and the Fe II stopping column. Daughter Li uses the discovery-epoch Be inventory (100 d of decay with a 53.22 d half-life, followed by complete conversion to Li).\n(b) The Be/Ca values refer to the observing epoch. The first two rows vary the fitted ionic columns (subsections~\\ref{sec:blue-opacity} and \\ref{sec:background-systematics}). The covering reruns use the refitted ionic targets (table~\\ref{tab:covering-cloudy}). The blend-fit reruns use the endpoint ratios 0.440 and 0.638 from the combined tests of template shape, background, fitting window and Cr II velocity (subsections~\\ref{sec:blue-opacity} and \\ref{sec:atomic-photoionization}). The joint-grid row applies the four screened models' ion and level fractions to the reference columns (subsection~\\ref{sec:atomic-photoionization}). Ellipses indicate quantities without a separate interval in a trial set.}\n\\end{table*}\n"
REFERENCE_LABELS = ('Ground-level $^{7}$Be II/Ca II', '$K_g$ ($10^{-4}$)', 'Observing-epoch $^{7}{\\rm Be/Ca}$ ($10^{-4}$)', 'Discovery-epoch $^{7}{\\rm Be/Ca}$ ($10^{-4}$)', 'Daughter \\liiso/Fe ($10^{-5}$)', '$A(\\liiso)_{\\rm equiv}$')
SENSITIVITY_LABELS = ('\\multicolumn{2}{@{}l}{Background and profile, fixed $K_g$}', '\\multicolumn{2}{@{}l}{Differential covering, fixed $K_g$}', '\\multicolumn{2}{@{}l}{Common covering and background reruns}', '\\multicolumn{2}{@{}l}{Cloudy reruns at two blend-fit targets}', '\\multicolumn{2}{@{}l}{Joint slab grid, four models passing Fe and Balmer screens}')


def rows(filename):
    with (HERE / filename).open(newline='') as stream:
        return list(csv.DictReader(stream))


def format_value(value, unit, digits):
    return f'{float(value) / unit:.{digits}f}' if value else r'\ldots'


def format_range(low, high, unit, digits, fixed=False):
    left = format_value(low, unit, digits)
    right = format_value(high, unit, digits)
    if not low and not high:
        return left
    if fixed:
        assert left == right
        return left + ' (fixed)'
    return f'{left}--{right}'


def print_row(label, values):
    print(' & '.join((label, *values)) + r' \\')


def main():
    reference = rows('reference_and_compact.csv')
    units = (1, 1e-4, 1e-4, 1e-4, 1e-5, 1)
    decimals = (3, 3, 3, 3, 2, 3)
    print(HEADER, end='')
    for label, row, unit, digits in zip(REFERENCE_LABELS, reference, units, decimals, strict=True):
        print_row(label, (
            format_value(row['uv025_b1_reference'], unit, digits),
            format_range(row['conditional_p16'], row['conditional_p84'], unit, digits),
            format_value(row['compact_log_nH_10p74'], unit, digits),
            format_value(row['compact_log_nH_10p82'], unit, digits),
        ))
    print(MIDTABLE, end='')
    for label, row in zip(SENSITIVITY_LABELS, rows('sensitivity_ranges.csv'), strict=True):
        fixed = row['trial'] == 'joint_grid_four_slab_passes'
        print_row(label, (
            format_range(row['ionic_min'], row['ionic_max'], 1, 3, fixed=fixed),
            format_range(row['observing_Be_Ca_min'], row['observing_Be_Ca_max'], 1e-4, 2 if fixed else 3),
            format_range(row['daughter_Li_Fe_min'], row['daughter_Li_Fe_max'], 1e-5, 2),
        ))
    print(FOOTER, end='')


if __name__ == '__main__':
    main()
