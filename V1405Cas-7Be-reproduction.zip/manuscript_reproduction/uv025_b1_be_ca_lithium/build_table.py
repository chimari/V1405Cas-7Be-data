import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
HEADER = '\\begin{table*}[t]\n\\centering\n\\caption{Be/Ca and daughter-lithium equivalent for the revised UV025 B1 model.}\n\\label{tab:empirical-be}\n\\begin{tabular}{lcc}\n\\hline\nQuantity & Central model & Observational 16th--84th percentiles \\\\\n\\hline\n'
FOOTER = '\\hline\n\\end{tabular}\n\\par\\smallskip\n\\parbox{0.94\\textwidth}{\\footnotesize The discovery-epoch values assume 100 d of decay with a half-life of 53.22 d. We use the local abundance-response matrix evaluated around the earlier B1 solution to propagate the paired observational draws, and apply the resulting offsets to the recomputed UV025 B1 abundances.}\n\\end{table*}\n'

def ratio_row(label, center, low, high, exponent):
    scale = 10**(-exponent)
    return (rf'{label} & ${center*scale:.3f}\times10^{{{exponent}}}$ & '
            rf'$({low*scale:.3f}$--${high*scale:.3f})\times10^{{{exponent}}}$ \\')

def main():
    data = json.loads((HERE / 'verified_abundance_summary.json').read_text())
    observed = [data[k] for k in ('BeCa', 'BeCa_p16', 'BeCa_p84')]
    discovery = [data[k] for k in ('discovery_BeCa', 'discovery_p16', 'discovery_p84')]
    factor = 2**(100/53.22)
    assert all(abs(o*factor/d-1) < 1e-12 for o,d in zip(observed, discovery))
    rows = [
        ratio_row(r'Observed-epoch $^{7}{\rm Be/Ca}$', *observed, -5),
        ratio_row(r'Discovery-epoch $^{7}{\rm Be/Ca}$', *discovery, -4),
        rf'$A(\liiso)_{{\rm equiv}}$ & {data["A_Li7"]:.3f} & '
        rf'{data["A_Li7_p16"]:.3f}--{data["A_Li7_p84"]:.3f} \\',
    ]
    print(HEADER + '\n'.join(rows) + '\n' + FOOTER, end='')

if __name__ == '__main__':
    main()
