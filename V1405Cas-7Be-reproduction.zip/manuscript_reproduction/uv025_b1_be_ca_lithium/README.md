# V1405 Cas reference abundances and sensitivity (Table 6)

LaTeX label `tab:empirical-be`. Run `python3 build_table.py > rebuilt.tex`
and compare with `be_ca_lithium.tex`.

- [Reference and compact slabs](reference_and_compact.csv) gives the
  six quantities in part (a), with the 16th–84th percentiles from
  conditional measurement noise and columns for the two compact slabs.
- [Sensitivity ranges](sensitivity_ranges.csv) gives the five trial
  ranges in part (b). The CSV records unscaled ratios at the precision
  printed in the table, with empty fields where no interval is shown.

The [reference-model JSON](verified_abundance_summary.json) preserves
unrounded Be/Ca and equivalent lithium values. The profile and template
tests are in `sources/`. The
[common-covering trials](../v1405_cas_covering_cloudy/covering_cloudy.csv)
and the [photoionization trials](../v1405_cas_photoionization_sensitivity/README.md)
provide the model summaries for part (b). The profile and model ranges
correspond to the stated trial sets.
