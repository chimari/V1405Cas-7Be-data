# Table 6 — V1405 Cas beryllium abundances

The current manuscript TeX and machine-readable values include UV025 B1 and both compact slabs. The CSV transcribes the displayed precision with the powers of ten already applied. Empty interval cells indicate unavailable percentiles.

The original build_table.py reconstructs the UV025 B1-only historical table from verified_abundance_summary.json; compare its output with uv025_b1_reference_only.tex. The compact-slab columns are archived here at manuscript precision.
