# UV025 B1 Be/Ca and daughter-lithium equivalent

Source for the manuscript table with LaTeX label `tab:empirical-be`. Run `python3 build_table.py > rebuilt.tex` and compare with `be_ca_lithium.tex`.

The JSON records the revised UV025 B1 central model and conditional 16th–84th percentile intervals from the saved response analysis. The script formats these values for LaTeX and checks the conversion to the discovery epoch with 100 days of decay and a half-life of 53.22 days. The daughter-lithium values are read from the saved summary. The archived inputs are numerical summaries of the analysis.
