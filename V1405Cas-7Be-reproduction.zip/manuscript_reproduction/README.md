# V1405 Cas 原稿図表の再現資料

現行原稿のLaTeXラベルで検索できる索引です。各リンク先に保存した入力、再現手順、照合範囲を記載しています。対象は図19件と表11件です。

## 図

| LaTeXラベル | 再現資料 |
| --- | --- |
| `lc` | [AAVSO光度曲線](v1405_cas_aavso_lightcurve/README.md) |
| `overview` | [スペクトル全体図](v1405_cas_spectrum_overview/README.md) |
| `vel` | [速度プロファイル比較](v1405_cas_velocity_profiles/README.md) |
| `metalshape` | [主線プロファイルと光学的厚さテンプレート](v1405_cas_metal_profile_overlay/README.md) |
| `diagshape` | [診断線プロファイル比較](v1405_cas_diagnostic_profile_overlay/README.md) |
| `be` | [⁷Be II・Cr II分解](be_cr_empirical_decomposition/README.md) |
| `cog` | [V1405 Casの経験的CoG](v1405_cas_empirical_cog/README.md) |
| `cogres` | [CoGの残差診断](empirical_cog_residual_diagnostics/README.md) |
| `doublet-ew` | [Ca II・Na I二重線のEW比較](ca_na_doublet_ew_comparison/README.md) |
| `cloud` | [UV025 B1の電離補正](uv025_be_ca_ionization_correction/README.md) |
| `depth` | [UV025 B1の深さ方向の分布](uv025_b1_depth_profiles/README.md) |
| `ab` | [三段組成図](empirical_abundance_pattern/README.md) |
| `fig:empirical-errors` | [条件付き誤差伝播](empirical_uncertainty_propagation/README.md) |
| `fig:comparison-sgr` | [V5668 Sgrの比較図](v5668_sgr_profiles_be_cog/README.md) |
| `fig:comparison-oph` | [V2944 Ophの比較図](v2944_oph_profiles_be_cog/README.md) |
| `fig:comparison-del` | [V339 Delの比較図](v339_del_profiles_be_cog/README.md) |
| `fig:comparison-abundance-patterns` | [Fig. 17 — 4新星のBe・Li・Ti・Cr比較](four_nova_abundance_comparison/README.md) |
| `cover` | [Fig. 18 — Fe II強線の被覆率診断](v1405_cas_feii_covering_diagnostic/README.md) |
| `fig:v339del-38d-integrated-cog` | [Fig. 19 — V339 Delの極大後38日](v339_del_38d_profiles_be_cog/README.md) |

## 表

| LaTeXラベル | 再現資料 |
| --- | --- |
| `tab:obs` | [Subaru/HDS観測ログ](v1405_cas_hds_observation_log/README.md) |
| `tab:thar` | [ThAr波長較正と分解能](v1405_cas_thar_calibration/README.md) |
| `tab:diagnostics` | [診断線のEW](v1405_cas_diagnostic_ew/README.md) |
| `tab:cloudy-grid` | [UV025 B1の入力条件](uv025_b1_slab_inputs/README.md) |
| `tab:level-residuals` | [下準位柱密度残差](uv025_b1_level_residuals/README.md) |
| `tab:empirical-be` | [⁷Be/Caと娘核⁷Li換算](uv025_b1_be_ca_lithium/README.md) |
| `tab:comparison-ratios` | [4天体の⁷Be II/Ca II柱密度比](four_nova_ion_ratios/README.md) |
| `tab:be-mass-comparison` | [4天体の発見時点の⁷Be質量分率](four_nova_mass_fractions/README.md) |
| `tab:primary` | [CoG採用主線](v1405_cas_primary_line_catalog/README.md) |
| `tab:excluded` | [定量解析から除外した吸収特徴](v1405_cas_excluded_features/README.md) |
| `tab:comparison-ew` | [比較3天体のEW](comparison_nova_ew_measurements/README.md) |

ThAr波長較正・分解能表は検出器別の集計値から再生成できます。元のランププロファイルと個々の線幅測定値は、この保存資料では確認できていません。


[旧版の比較3新星の三段組成図](comparison_novae_abundance_patterns/README.md)は履歴資料です。
