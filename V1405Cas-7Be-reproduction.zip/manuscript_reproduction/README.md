# V1405 Cas 原稿図表の再現資料

LaTeXラベルで検索できる再現資料の索引です。対象原稿は再査読対応版（2026年11月25日、版ID `V1405Cas-PASJ-rereview-edit-20261125`）です。全21図、全16表、電子表4件を収録し、この版の表4のキャプションと表12の脚注を反映しています。各項目のREADMEに入力、再現手順、照合範囲を記載しています。

## 図

| LaTeXラベル | 再現資料 |
| --- | --- |
| `lc` | [AAVSO光度曲線](v1405_cas_aavso_lightcurve/README.md) |
| `overview` | [スペクトル全体図](v1405_cas_spectrum_overview/README.md) |
| `vel` | [速度プロファイル比較](v1405_cas_velocity_profiles/README.md) |
| `metalshape` | [主線プロファイルと光学的厚さテンプレート](v1405_cas_metal_profile_overlay/README.md) |
| `diagshape` | [診断線プロファイル比較](v1405_cas_diagnostic_profile_overlay/README.md) |
| `be` | [⁷Be II・Cr II分解](be_cr_empirical_decomposition/README.md) |
| `cog` | [V1405 Casの経験的CoG](v1405_cas_empirical_cog/README.md) |
| `cogres` | [CoGの残差診断](empirical_cog_residual_diagnostics/README.md) |
| `doublet-ew` | [Ca II・Na I二重線のEW比較](ca_na_doublet_ew_comparison/README.md) |
| `cloud` | [UV025 B1の電離補正](uv025_be_ca_ionization_correction/README.md) |
| `depth` | [UV025 B1の深さ方向の分布](uv025_b1_depth_profiles/README.md) |
| `ab` | [三段組成図](empirical_abundance_pattern/README.md) |
| `fig:empirical-errors` | [条件付き誤差伝播](empirical_uncertainty_propagation/README.md) |
| `fig:covering-sensitivity` | [共通被覆率への感度（図14）](v1405_cas_covering_sensitivity/README.md) |
| `fig:comparison-sgr` | [V5668 Sgrの比較図](v5668_sgr_profiles_be_cog/README.md) |
| `fig:comparison-oph` | [V2944 Ophの比較図](v2944_oph_profiles_be_cog/README.md) |
| `fig:comparison-del` | [V339 Delの比較図](v339_del_profiles_be_cog/README.md) |
| `fig:comparison-abundance-patterns` | [4天体の吸収成分の組成比較（図18）](comparison_novae_abundance_patterns/README.md) |
| `cover` | [Fe II強線の被覆率診断（図19）](v1405_cas_feii_covering_diagnostic/README.md) |
| `fig:v339del-38d-integrated-cog` | [V339 Delの +38 d スペクトルとCoG（図20）](v339_del_38d_profiles_be_cog/README.md) |
| `fig:total-rates` | [UV025 B1のCa電離・再結合レート（図21）](uv025_b1_ca_rate_budget/README.md) |

## 表

| 表 | LaTeXラベル | 再現資料 |
| --- | --- | --- |
| 1 | `tab:obs` | [Subaru/HDS観測ログ](v1405_cas_hds_observation_log/README.md) |
| 2 | `tab:thar` | [ThAr波長較正と分解能](v1405_cas_thar_calibration/README.md) |
| 3 | `tab:diagnostics` | [診断線のEW](v1405_cas_diagnostic_ew/README.md) |
| 4 | `tab:cloudy-grid` | [UV025 B1の入力条件](uv025_b1_slab_inputs/README.md) |
| 5 | `tab:level-residuals` | [下準位柱密度残差](uv025_b1_level_residuals/README.md) |
| 6 | `tab:empirical-be` | [V1405 Casの基準存在量と感度試験](uv025_b1_be_ca_lithium/README.md) |
| 7 | `tab:covering-cloudy` | [V1405 Casの被覆率と背景のCloudy試験](v1405_cas_covering_cloudy/README.md) |
| 8 | `tab:photoionization-pilot` | [V1405 Casの光電離モデル感度](v1405_cas_photoionization_sensitivity/README.md) |
| 9 | `tab:comparison-covering` | [比較新星の被覆率感度](comparison_nova_covering_sensitivity/README.md) |
| 10 | `tab:comparison-ratios` | [4天体の観測時⁷Be II/Ca II](four_nova_ion_ratios/README.md) |
| 11 | `tab:comparison-model-checks` | [比較新星のスラブ診断](comparison_nova_slab_diagnostics/README.md) |
| 12 | `tab:be-mass-comparison` | [4天体の発見時⁷Be質量分率](four_nova_mass_fractions/README.md) |
| 13 | `tab:ca-fe-normalizations` | [Ca・Feの規格化と薄線法との差の分解](four_nova_ca_fe_normalizations/README.md) |
| 14 | `tab:primary` | [CoG採用主線](v1405_cas_primary_line_catalog/README.md) |
| 15 | `tab:excluded` | [定量解析から除外した吸収特徴](v1405_cas_excluded_features/README.md) |
| 16 | `tab:comparison-ew` | [比較3天体のEW](comparison_nova_ew_measurements/README.md) |

ThAr波長較正・分解能表は検出器別の集計値から再生成できます。元のランププロファイルと個々の線幅測定値は、この保存資料では確認できていません。


[Appendix 5 のUV025入射スペクトルと検証](uv025_sed_validation/README.md)
