from pathlib import Path
import csv
from collections import Counter

root=Path(__file__).resolve().parent
table=root/'Three_nova_EW_measurements.csv'
with table.open() as f:
    rows=list(csv.DictReader(f))
order=['V5668 Sgr','V2944 Oph','V339 Del']
assert Counter(r['nova'] for r in rows)==dict(zip(order,[43,26,34]))
assert Counter(r['use'] for r in rows)=={'primary CoG':88,'diagnostic':14,'provisional diagnostic':1}
assert sum(r['EW_method']=='isolated blend-fit profile' for r in rows)==6

head=r'''\begingroup
\footnotesize\setlength{\tabcolsep}{2pt}
% Caption width matches the printed width of the table below.
\aligntablecaption{456bp}
\begin{longtable}[h]{@{}llrrrrl@{\hspace{12pt}}llrrrrl@{}}
\caption{Rest-frame equivalent widths for the three comparison novae.\newline P denotes a primary curve-of-growth line and D a diagnostic feature.}\label{tab:comparison-ew}\\
\hline
Nova & Ion or feature & $\lambda_{\rm air}$ & $\chi$ & $\log gf$ & $W_{\rm rest}$ & Use & Nova & Ion or feature & $\lambda_{\rm air}$ & $\chi$ & $\log gf$ & $W_{\rm rest}$ & Use\\
\hline
\endfirsthead
\multicolumn{14}{l}{\tablename~\thetable\ (continued)}\\
\hline
Nova & Ion or feature & $\lambda_{\rm air}$ & $\chi$ & $\log gf$ & $W_{\rm rest}$ & Use & Nova & Ion or feature & $\lambda_{\rm air}$ & $\chi$ & $\log gf$ & $W_{\rm rest}$ & Use\\
\hline
\endhead
\hline
\endfoot
'''
def num(value,digits):
    return f'${float(value):.{digits}f}$' if value else r'\ldots'

lines=[]
for name in order:
    for row in sorted((r for r in rows if r['nova']==name),key=lambda r:float(r['rest_air_A'])):
        feature=(row['transition'] or row['ion']).replace('⁷Be',r'\beiso').replace('†','')
        role={'primary CoG':'P','diagnostic':'D','provisional diagnostic':r'D\textsuperscript{c}'}[row['use']]
        if row['EW_method']=='isolated blend-fit profile':
            role=r'D\textsuperscript{b}'
        values=[name,feature,num(row['rest_air_A'],3),num(row['E_lower_eV'],4),num(row['loggf'],3),num(row['EW_rest_mA'],2),role]
        lines.append(' & '.join(values))
assert len(lines)==103
midpoint = (len(lines) + 1) // 2
left, right = lines[:midpoint], lines[midpoint:]
right.append(' & '.join([''] * 7))
lines = [f'{first} & {second}' + r'\\' for first, second in zip(left, right)]
(root/'rebuilt_comparison_ew.tex').write_text(head+'\n'.join(lines)+'\n'+r'''\end{longtable}
\endgroup
''')
