# Rest-frame equivalent widths for the comparison novae

Machine-readable source and manuscript TeX for LaTeX label `tab:comparison-ew`.

Run `python3 build_table.py` and compare `rebuilt_comparison_ew.tex` with `comparison_ew.tex`. The script uses the standard library and checks the row counts and measurement categories.

The CSV contains 103 rows: 88 primary CoG measurements and 15 diagnostic features for V5668 Sgr, V2944 Oph and V339 Del. It records the selected velocity components, covering fractions and integration and continuum windows where available. Six Be II widths are from isolated blend-fit profiles. The V339 Del Mn II diagnostic is provisional because of possible Fe I contamination. This package reconstructs the table from the archived measurements.

The reference LaTeX uses the current manuscript layout. The table builder reproduces the numeric rows; its generated formatting can differ.
