# Comparison-nova slab diagnostics (Table 11)

LaTeX label `tab:comparison-model-checks`. The
[diagnostic summary](diagnostic_summary.csv) reports the results from
the primary joint or stopping-column grid for each comparison nova.
The `sources/` directory gives the underlying trial rows, the V339
Del Balmer fits, and the reference illumination trial summaries.

The Fe II screen uses a 0.20 dex rms log-EW tolerance. V5668 Sgr and
V2944 Oph use different observational constraints on Na I, as
specified in the manuscript. Empty summary cells mark a diagnostic
count that is unavailable for the stated grid or handled separately
in the reference illumination trials.
