# V1405 Cas velocity profiles

Manuscript figure with LaTeX label `vel`. The reference PDF is byte-identical to the manuscript figure. The caption is from the current manuscript.

Extract `reproduction.zip` and follow the included instructions in `major_velocity_profiles_20261029`. The archive preserves the inputs and plotting code. The current caption documents the display normalizations, velocity guides and retained blends. The plotting code was not rerun for this preservation check.
