import csv
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
HEADER = r'''\begingroup
\footnotesize\setlength{\tabcolsep}{2pt}
\renewcommand{\arraystretch}{0.88}
% Caption width matches the printed width of the table below.
\aligntablecaption{405bp}
\begin{longtable}[h]{@{}lrrrrrrl@{\hspace{12pt}}lrrrrrrl@{}}
\caption{Primary transitions adopted in the joint curve-of-growth analysis.}\label{tab:primary}\\
\hline
Ion & $\lambda_{\rm air}$ & $\chi$ & $\log gf$ & $W_\lambda$ & $s_{\rm c}$ & $s_{\rm i}$ & Source & Ion & $\lambda_{\rm air}$ & $\chi$ & $\log gf$ & $W_\lambda$ & $s_{\rm c}$ & $s_{\rm i}$ & Source\\
\hline
\endhead
\hline

\endlastfoot
'''
FOOTER = r'''\end{longtable}
\par\smallskip
\footnotesize All 118 transitions have unit weight in the joint logarithmic-EW fit. Air wavelengths are in \AA, excitation energies in eV, and signed rest-frame equivalent widths and their uncertainties in m\AA. $s_{\rm c}$ is the current conditional noise estimate including short-range sample correlation and the local linear-background fit; $s_{\rm i}$ uses an independent-output-sample approximation. Both estimates have been evaluated for all 118 transitions using the current measurement windows and pooled empirical sample-correlation model; $s_{\rm i}$ is a control, not an additional independent error to combine with $s_{\rm c}$. Neither includes continuum alternatives, blends, atomic-data or model systematics; ellipses mean not evaluated, not zero. Exact windows and full precision are in the electronic table. MB09L/S: \citet{mb09}, laboratory/solar multiplet normalization; DH19: \citet{dh19}; W13: \citet{wood13}; PTP01: \citet{ptp01} through VALD, checked against the corrected Table 3 of \citet{ptp02}; L17: \citet{law17}; DH11/DH11e: \citet{dh11}, Table 3 recommended/experimental columns, respectively; C26: \citet{clear26}. RU98 denotes the retained VALD RU calculations and author distribution linked to \citet{ru98}; correspondence with current author files does not establish the historical version. KK87: \citet{kk87}; T83av: VALD averaged compilation described by \citet{rya99}. BGHRc denotes \citet{bas70} through VALD, whose bibliography records a +0.16 dex adjustment. These labels identify $gf$ provenance; wavelength and level sources can differ. No strengths are changed in constructing this table.

\endgroup
'''

ION_COUNTS = {'Fe II': 38, 'Ti II': 35, 'Cr II': 36, 'Mn II': 4, 'Ni II': 5}

def main():
    with (HERE / 'primary_lines.csv').open(newline='', encoding='utf-8') as stream:
        rows = list(csv.DictReader(stream))
    assert Counter(r['ion'] for r in rows) == ION_COUNTS
    assert len({r['ID'] for r in rows}) == 118
    assert all(float(r['CoG_fit_weight']) == 1 for r in rows)
    rows.sort(key=lambda r: (list(ION_COUNTS).index(r['ion']), float(r['rest_air_A'])))
    print(HEADER, end='')
    entries = []
    for row in rows:
        fields = [
            row['ion'], f"{float(row['rest_air_A']):.3f}", f"{float(row['Elow_eV']):.4f}",
            f"${float(row['loggf']):+.3f}$", f"{float(row['EW_rest_mA']):.2f}",
            f"{float(row['EW_sigma_short_correlated_noise_mA']):.2f}",
            f"{float(row['EW_sigma_independent_noise_control_mA']):.2f}", row['gf_source_code'],
        ]
        entries.append((' & '.join(fields), row['ID']))
    midpoint = len(entries) // 2
    for index, ((left, left_id), (right, right_id)) in enumerate(
        zip(entries[:midpoint], entries[midpoint:])
    ):
        if index == 0:
            left = r'\rule{0pt}{8pt}' + left
        print(f'{left} & {right}' + r'\\'
              + f' % internal ID: {left_id} % internal ID: {right_id}')
    print(FOOTER, end='')

if __name__ == '__main__':
    main()
