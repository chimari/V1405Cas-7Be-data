import csv
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
HEADER = '\\begingroup\n\\small\\setlength{\\tabcolsep}{4pt}\n\\begin{longtable}{lrrrrrrl}\n\\caption{Primary transitions adopted in the joint curve-of-growth analysis.}\\label{tab:primary}\\\\\n\\hline\nIon & $\\lambda_{\\rm air}$ (\\AA) & $\\chi$ (eV) & $\\log gf$ & $W_\\lambda$ (m\\AA) & $s_{\\rm c}$ (m\\AA) & $s_{\\rm i}$ (m\\AA) & $gf$ source\\\\\n\\hline\n\\endhead\n\\hline\n\n\\endlastfoot\n'
FOOTER = '\\end{longtable}\n\\par\\smallskip\n\\footnotesize All 118 transitions have unit weight in the joint logarithmic-EW fit. Wavelengths are in air and equivalent widths are signed rest-frame values. $s_{\\rm c}$ is the current conditional noise estimate including short-range sample correlation and the local linear-background fit; $s_{\\rm i}$ uses an independent-output-sample approximation. Both estimates have been evaluated for all 118 transitions using the current measurement windows and pooled empirical sample-correlation model; $s_{\\rm i}$ is a control, not an additional independent error to combine with $s_{\\rm c}$. Neither includes continuum alternatives, blends, atomic-data or model systematics; ellipses mean not evaluated, not zero. Exact windows and full precision are in the electronic table. MB09L/S: \\citet{mb09}, laboratory/solar multiplet normalization; DH19: \\citet{dh19}; W13: \\citet{wood13}; PTP01: \\citet{ptp01} through VALD, checked against the corrected Table 3 of \\citet{ptp02}; L17: \\citet{law17}; DH11/DH11e: \\citet{dh11}, Table 3 recommended/experimental columns, respectively; C26: \\citet{clear26}. RU98 denotes the retained VALD RU calculations and author distribution linked to \\citet{ru98}; correspondence with current author files does not establish the historical version. KK87: \\citet{kk87}; T83av: VALD averaged compilation described by \\citet{rya99}. BGHRc denotes \\citet{bas70} through VALD, whose bibliography records a +0.16 dex adjustment. These labels identify $gf$ provenance; wavelength and level sources can differ. No strengths are changed in constructing this table.\n\n\\endgroup\n'

ION_COUNTS = {'Fe II': 38, 'Ti II': 35, 'Cr II': 36, 'Mn II': 4, 'Ni II': 5}

def main():
    with (HERE / 'primary_lines.csv').open(newline='', encoding='utf-8') as stream:
        rows = list(csv.DictReader(stream))
    assert Counter(r['ion'] for r in rows) == ION_COUNTS
    assert len({r['ID'] for r in rows}) == 118
    assert all(float(r['CoG_fit_weight']) == 1 for r in rows)
    rows.sort(key=lambda r: (list(ION_COUNTS).index(r['ion']), float(r['rest_air_A'])))
    print(HEADER, end='')
    for row in rows:
        fields = [
            row['ion'], f"{float(row['rest_air_A']):.3f}", f"{float(row['Elow_eV']):.4f}",
            f"${float(row['loggf']):+.3f}$", f"{float(row['EW_rest_mA']):.2f}",
            f"{float(row['EW_sigma_short_correlated_noise_mA']):.2f}",
            f"{float(row['EW_sigma_independent_noise_control_mA']):.2f}", row['gf_source_code'],
        ]
        print(' & '.join(fields) + r'\\' + f" % internal ID: {row['ID']}")
    print(FOOTER, end='')

if __name__ == '__main__':
    main()
