# V1405 Cas primary transition catalog

Machine-readable source for the manuscript table with LaTeX label `tab:primary`. Rebuild it with `python3 build_table.py > rebuilt.tex` and compare with `primary_lines.tex`.

The CSV records the 118 unit-weight CoG transitions, signed rest-frame equivalent widths, measurement windows, oscillator-strength sources, and conditional noise estimates. The independent-sample noise column is a control. The two noise columns describe the same measurements under different assumptions. The generator formats the archived measurements for the manuscript.

The reference LaTeX uses the current manuscript layout. The table builder reproduces the numeric rows; its generated formatting can differ.
