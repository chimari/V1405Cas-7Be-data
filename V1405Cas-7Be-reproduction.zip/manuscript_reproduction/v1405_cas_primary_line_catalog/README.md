# V1405 Cas primary transition catalog

Electronic catalog for manuscript Table 14 (LaTeX label `tab:primary`).
To regenerate the manuscript TeX and verify an exact match, run:

    python3 build_table.py > rebuilt.tex
    cmp primary_lines.tex rebuilt.tex

The generated table uses the manuscript preamble's `\aligntablecaption`
macro to align the caption with the table.

The CSV records the 118 unit-weight CoG transitions, signed rest-frame equivalent widths, measurement windows, oscillator-strength sources, and conditional noise estimates. The independent-sample noise column is a control. The two noise columns describe the same measurements under different assumptions. The table prints the observed measurements. The CSV also records the fitted model equivalent widths and residuals.

The model equivalent widths and residuals are from the
[Figure 8 fit](../v1405_cas_empirical_cog/README.md). The rms log-EW
residual for the 118 lines is 0.08530 dex.
