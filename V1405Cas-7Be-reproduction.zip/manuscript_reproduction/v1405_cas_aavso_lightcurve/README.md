# V1405 Cas AAVSO light curve

Manuscript figure with LaTeX label `lc`. The reference PDF is byte-identical to the current manuscript figure. The caption is from the current manuscript.

Unzip `lightcurve_reproduction.zip` and run `python build_lightcurve.py` from the included `Lightcurve_20261022` directory with Python, NumPy, pandas and Matplotlib. The archive contains the original AAVSO inputs, plotting code and selected Johnson BV and Cousins RI points through 1050 days after discovery. The HDS epoch marker denotes 2021 June 26. See the README inside the archive for the selection, timing conventions and provenance.

This entry preserves the previously archived reproduction package and verifies the identity of the reference PDF. The renderer was not rerun for this entry.
