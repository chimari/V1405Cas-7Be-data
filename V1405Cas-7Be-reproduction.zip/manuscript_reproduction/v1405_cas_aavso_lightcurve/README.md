# V1405 Cas light curve (Figure 1)

`reference_plot.pdf` is the exact graphic included under LaTeX label `lc` in the manuscript. It contains the long-term AAVSO visual light curve and a close-up of optical photometry and Swift UVW1 near the Subaru/HDS epoch.

Extract `lightcurve_reproduction.zip` and follow `Fig1/README.md`. The archive includes both photometry tables and the plotting script. `caption.tex` preserves the manuscript caption and alternative text.
