# V1405 Cas Subaru/HDS observation log

Reproduction of the manuscript table with LaTeX label `tab:obs`. Run `python3 build_table.py > rebuilt.tex` and compare with `observations.tex`.

The exposure inventory is preserved from the previous observation-table support archive. The script selects the 300 s Ub and 60 s Yb frames used in the reduced spectra, and derives exposure counts, totals, slit dimensions and binning. Wavelength coverage and other reduced-spectrum metadata come from the manuscript.
