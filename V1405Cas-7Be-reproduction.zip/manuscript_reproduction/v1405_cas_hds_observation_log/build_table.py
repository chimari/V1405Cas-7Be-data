import csv
from pathlib import Path

HERE = Path(__file__).resolve().parent
HEADER = '\\begin{table*}[t]\n\\caption{Subaru/HDS observations of V1405 Cas on 2021 June 26 UT.}\n\\label{tab:obs}\n\\centering\\small\n\\begin{tabular}{lccccc}\n\\hline\nSetting & Adopted exposures & Total (s) & Slit (arcsec) & Binning & Usable range (\\AA)\\\\\n\\hline\n'
FOOTER = '\\hline\n\\end{tabular}\n\\begin{tabnote}\nThe main CCD gaps are 3750--3792\\,\\AA\\ (Ub) and 5436--5519\\,\\AA\\ (Yb), with additional short gaps and masks. The merged spectra are sampled at 0.01784\\,\\AA\\ (Ub) and 0.02420\\,\\AA\\ (Yb).\n\\end{tabnote}\n\\end{table*}\n'

with (HERE / 'exposure_inventory.csv').open(newline='') as stream:
    frames = list(csv.DictReader(stream))

# The adopted reduced spectra define these exposure durations and usable ranges.
settings = [('Ub', 300, '3017--4632'), ('Yb', 60, '4111--6865')]
print(HEADER, end='')
for setting, seconds, coverage in settings:
    adopted = [row for row in frames
               if row['setting'] == setting and int(row['exposure_s']) == seconds]
    slit, = {r'\times'.join(s.strip() for s in row['slit_as_logged'].split('/'))
             for row in adopted}
    binning, = {row['binning'].replace('x', r'\times') for row in adopted}
    count = len(adopted)
    print(rf'{setting} & ${count}\times{seconds}$ s & {count*seconds} & '
          rf'${slit}$ & ${binning}$ & {coverage}\\')
print(FOOTER, end='')
