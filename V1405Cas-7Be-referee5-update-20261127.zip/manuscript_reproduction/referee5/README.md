# Fifth-review revision

- [Synthetic photometry](evidence/V1405Cas_synthetic_photometry/README.md)
  for the UV025 reference and optical normalization in section 7.1.
- [Table 14](evidence/V1405Cas_Fe_column_contrasts/README.md) compares three
  Fe II prescriptions and includes the source CSVs and calculation script.
- [Table 18](evidence/V1405Cas_Balmer_sensitivity/README.md) compares all
  eight Balmer sensitivity runs and includes the Cloudy input package,
  selected diagnostic arrays, and the summary CSV.

Scripts use the accompanying evidence tree. For the comparison with Swift,
the observational values accompany the synthetic photometry under
evidence/Fig1. The model-derived Balmer counts refer to the 54 trial
observational profiles and the adopted 0.10 dex tolerance.
