"""Reproduce the Fe II column comparison in Section 8.3.3.

Run this script with Python 3 from the manuscript source tree.
"""

import csv
import math
from pathlib import Path


HERE = Path(__file__).resolve().parent
EVIDENCE = HERE.parent
HALF_LIFE_D = 53.22
NOVAE = ("V1405 Cas", "V339 Del", "V5668 Sgr")


def read_rows(path):
    with (EVIDENCE / path).open(newline="") as file:
        return list(csv.DictReader(file))


def main():
    comparison = {
        row["nova"]: row
        for row in read_rows("Fig18_ionization_comparison/be_li_fe_comparison.csv")
    }
    reference = next(
        row for row in read_rows("V1405Cas_FeH_sensitivity/grid_summary.csv")
        if row["case"] == "reference_B1"
    )
    iron_rich, = read_rows("V1405Cas_FeH_sensitivity/feh_ca_reclosure_summary.csv")

    ionic = [float(comparison[nova]["CoG_BeII_ground_over_FeII"]) for nova in NOVAE]
    decay = [2**(float(comparison[nova]["days_from_discovery"]) / HALF_LIFE_D) for nova in NOVAE]
    decay_corrected = [ratio * factor for ratio, factor in zip(ionic, decay)]
    daughter = [float(comparison[nova]["daughter_Li_over_Fe_equivalent"]) for nova in NOVAE]

    log_fe_cog = float(reference["target_logN_BeII"]) - math.log10(ionic[0])
    rows = [
        ("Common CoG", "Decay-corrected ionic", log_fe_cog, decay_corrected),
        ("UV025 B1", "Daughter Li/Fe", float(reference["logN_FeII"]), daughter),
        (
            "Iron-enhanced trial", "Daughter Li/Fe", float(iron_rich["logN_FeII"]),
            [float(iron_rich["LiFe_at_target_Be_fixed_structure"]), *daughter[1:]],
        ),
    ]
    with (HERE / "fe_column_contrasts.csv").open("w", newline="") as file:
        writer = csv.writer(file, lineterminator="\n")
        writer.writerow([
            "FeII_prescription_V1405_Cas", "quantity", "log10_FeII_V1405_Cas_cm-2",
            *NOVAE, "V339 Del / V1405 Cas", "V5668 Sgr / V1405 Cas",
        ])
        for prescription, quantity, log_fe, (cas, delphini, sgr) in rows:
            writer.writerow([prescription, quantity, log_fe, cas, delphini, sgr, delphini/cas, sgr/cas])


if __name__ == "__main__":
    main()
