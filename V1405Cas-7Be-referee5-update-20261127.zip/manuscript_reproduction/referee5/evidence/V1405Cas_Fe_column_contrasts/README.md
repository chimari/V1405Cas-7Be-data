# Fe II column comparison for V1405 Cas

The files reproduce Table 14. Run python3 derive.py within this directory
to regenerate fe_column_contrasts.csv from the accompanying comparison and
Fe/H grid CSVs. The first row uses decay-corrected CoG ionic ratios. The
other two rows use modeled daughter lithium-to-iron ratios and fix the
reference calculations for V339 Del and V5668 Sgr.
