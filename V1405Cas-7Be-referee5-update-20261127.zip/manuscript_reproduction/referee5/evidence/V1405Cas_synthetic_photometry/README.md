# V1405 Cas synthetic photometry

Run python3 evidence/V1405Cas_synthetic_photometry/synthetic_photometry.py
from the manuscript directory with NumPy installed. It reproduces the UV025
continuum check in Section 7.1 and writes synthetic_photometry.csv.

The calculation reads the tabulated incident UV025 continuum, ionizing flux
and radius from evidence/V1405Cas_rate_budget/inputs/model.in. It applies
Cardelli, Clayton & Mathis (1989) foreground extinction with E(B-V)=0.53 and
R_V=3.1. The Bessell V response and the CALSPEC Vega optical spectrum are
taken from evidence/V5668Sgr_Vnorm_ionization. The observed V=7.293 sets the
optical scale. The UVW1 mean flux uses photon weighting and the band-averaged
Vega zero point of 4.14563e-9 erg cm^-2 s^-1 Angstrom^-1. The UV025 B1
magnitudes are shifted from this optical scale by the ratio of the two input
ionizing fluxes at the same radius.

Swift_UVOT_UVW1.csv contains the CALDB UVOT UVW1 effective area from the
SVO Filter Profile Service (Rodrigo et al. 2024, A&A, 689, A93).
Source: https://svo2.cab.inta-csic.es/svo/theory/fps3/index.php?id=Swift%2FUVOT.UVW1
Data: https://svo2.cab.inta-csic.es/svo/theory/fps3/getdata.php?format=ascii&id=Swift%2FUVOT.UVW1

The compact-trial magnitudes are the previous results from Section 5.3.
The two Swift UVW1 measurements in evidence/Fig1/swift_uvw1.csv are
approximately four days after spectroscopy and brighter than the calibrated
readout-streak limit. Treat the comparison as qualitative.
