"""Check the optical and UV normalization of the UV025 reference continuum."""

import csv
from pathlib import Path
import re
from xml.etree import ElementTree

import numpy as np


HERE = Path(__file__).resolve().parent
EVIDENCE = HERE.parent
INTEGRATE = np.trapezoid if hasattr(np, "trapezoid") else np.trapz
RYD_WAVELENGTH_A = 911.2670506
OPTICAL_MAG = 7.293
EBV = 0.53
RV = 3.1
UVW1_VEGA_FLUX = 4.14563e-9
LOG_PHI_V_NORMALIZED = 15.49  # At the B1 radius.
COMPACT_RADIUS_CM = 3.08e14
LOG_PHI_COMPACT = 16.184


def foreground_transmission(wavelength):
    """Cardelli, Clayton & Mathis (1989) extinction for the two passbands."""
    x = 1e4 / wavelength
    y = x - 1.82
    a_optical = np.polynomial.polynomial.polyval(
        y, [1, 0.17699, -0.50447, -0.02427, 0.72085, 0.01979, -0.77530, 0.32999]
    )
    b_optical = np.polynomial.polynomial.polyval(
        y, [0, 1.41338, 2.28305, 1.07233, -5.38434, -0.62251, 5.30260, -2.09002]
    )
    bend = np.maximum(0, x - 5.9)
    a_uv = 1.752 - 0.316*x - 0.104/((x - 4.67)**2 + 0.341) - 0.04473*bend**2 - 0.009779*bend**3
    b_uv = -3.090 + 1.825*x + 1.206/((x - 4.62)**2 + 0.263) + 0.2130*bend**2 + 0.1207*bend**3
    a = np.where(x < 3.3, a_optical, a_uv)
    b = np.where(x < 3.3, b_optical, b_uv)
    return 10**(-0.4 * EBV * (RV*a + b))


def main():
    deck = (EVIDENCE / "V1405Cas_rate_budget/inputs/model.in").read_text()
    tabulated = re.findall(r"^(?:interpolate|continue)\s*\(\s*(\S+)\s+(\S+)\s*\)", deck, re.M)
    energy_ryd, log_f_nu = np.array(tabulated, dtype=float).T
    log_phi_b1 = float(re.search(r"^phi\(H\)\s+(\S+)", deck, re.M)[1])
    radius_b1 = 10**float(re.search(r"^radius\s+(\S+)", deck, re.M)[1])

    def source_flux(wavelength):
        energy = RYD_WAVELENGTH_A / wavelength
        log_flux = np.interp(np.log10(energy), np.log10(energy_ryd), log_f_nu)
        # The overall scale cancels in the V-band normalization.
        return 10**log_flux / wavelength**2 * foreground_transmission(wavelength)

    optical = EVIDENCE / "V5668Sgr_Vnorm_ionization"
    table = ElementTree.parse(optical / "V.xml")
    wavelength_v, response_v = np.array([
        [float(cell.text) for cell in row] for row in table.findall(".//{*}TR")
    ]).T
    vega = np.loadtxt(optical / "vega_optical.csv", delimiter=",", skiprows=1)
    vega_v = np.interp(wavelength_v, *vega.T)
    optical_scale = (
        INTEGRATE(vega_v * response_v, wavelength_v) * 10**(-0.4 * OPTICAL_MAG)
        / INTEGRATE(source_flux(wavelength_v) * response_v, wavelength_v)
    )

    wavelength_uv, effective_area = np.loadtxt(
        HERE / "Swift_UVOT_UVW1.csv", delimiter=",", skiprows=1, unpack=True
    )
    photon_weight = wavelength_uv * effective_area
    band_flux_uv = (
        optical_scale * INTEGRATE(source_flux(wavelength_uv) * photon_weight, wavelength_uv)
        / INTEGRATE(photon_weight, wavelength_uv)
    )
    uv_mag_v_normalized = -2.5 * np.log10(band_flux_uv / UVW1_VEGA_FLUX)
    mag_shift = 2.5 * (log_phi_b1 - LOG_PHI_V_NORMALIZED)
    rows = [
        ("UV025 B1", radius_b1, log_phi_b1, OPTICAL_MAG - mag_shift, uv_mag_v_normalized - mag_shift),
        ("UV025 at observed V", radius_b1, LOG_PHI_V_NORMALIZED, OPTICAL_MAG, uv_mag_v_normalized),
        ("Optically normalized compact trial", COMPACT_RADIUS_CM, LOG_PHI_COMPACT, OPTICAL_MAG, 7.33),
    ]
    with (HERE / "synthetic_photometry.csv").open("w", newline="") as f:
        writer = csv.writer(f, lineterminator="\n")
        writer.writerow(["prescription", "radius_cm", "log10_phi_H", "Q_H_s-1", "V_Vega_mag", "UVW1_Vega_mag"])
        for name, radius, log_phi, v_mag, uv_mag in rows:
            photon_rate = 4 * np.pi * radius**2 * 10**log_phi
            writer.writerow([name, f"{radius:.5e}", f"{log_phi:.6f}", f"{photon_rate:.5e}", f"{v_mag:.3f}", f"{uv_mag:.3f}"])


if __name__ == "__main__":
    main()
