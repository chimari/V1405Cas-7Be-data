# Balmer and Lyman-pumping sensitivity in V1405 Cas

The summary CSV records the eight Cloudy C25.00 runs in Appendix 9 and
Table 18. The comparison uses two previously adopted input decks and
changes one input at a time per parent model. The archive contains those
decks, the saved diagnostic arrays and the observational profile fits.
Each control reproduces its archived reference columns and residuals.
The full return archive is identified by SHA-256 in provenance.json.

The 54-fit counts use the individual observational log N(n=2) values
and an absolute log-column residual of at most 0.10 dex. Fe I and Fe II
rms values use the 5 and 38 line residuals, respectively. The table
compares each perturbation against the control of the same parent model.
The reported Be/H and daughter Li/Fe changes use the measured Be II
ground-level column for normalization at fixed slab structure.

The runnable Cloudy input package is V1405Cas_Balmer_sensitivity_kuromi.zip.
Use Cloudy C25.00 with the atomic data adopted for UV025 B1 and the Fe/H
grid. The package includes the input checks and the Fe and Balmer forward
diagnostics. Its runner accepts explicit paths to the executable and
atomic data. The ZIP's name identifies the original run environment.
