from pathlib import Path

import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MultipleLocator
import numpy as np
import pandas as pd

root = Path(__file__).resolve().parent
main = pd.read_csv(root / "grid_summary.csv")
extra = pd.read_csv(root / "feh_extension_summary.csv")
adjusted, = list(pd.read_csv(root / "feh_ca_reclosure_summary.csv").itertuples(index=False))
b1, = list(main.loc[main.case.eq("reference_B1")].itertuples(index=False))
solar, = list(main.loc[main.stop.eq("H") & main.FeH_dex.eq(0) & main.common_column].itertuples(index=False))
scan = pd.concat([main.loc[main.stop.eq("H")],extra],ignore_index=True).sort_values(["FeH_dex","logN_H"])
assert scan.case.nunique()==len(scan)==20
assert scan.groupby("FeH_dex").size().to_dict()=={-1.:4,-.3:3,0.:3,.3:6,1.:4}
assert set(scan.loc[scan.passes_Fe_and_Balmer,"case"])=={solar.case,adjusted.parent_case}
assert abs(adjusted.logN_H-22.20)<.00001 and adjusted.passes_Fe_and_Balmer
assert np.allclose(scan.logN_H,scan.logNH_target,rtol=0,atol=1e-5)
assert abs(solar.logN_H-b1.logN_H)<1e-5
assert abs(solar.Balmer_n2_residual_dex-b1.Balmer_n2_residual_dex)<1e-4

fits = pd.read_csv(root / "H15_H16_fit_trials.csv")
obs = fits.loc[fits.lines.eq("15-16"),"log_N2"]
assert len(obs)==54
def obs_fit_span(model):
    offsets=model.logN_HI_n2-obs
    return (offsets.min(),offsets.max(),int(offsets.abs().le(.10).sum()))
spans = {b1.case:obs_fit_span(b1),adjusted.case:obs_fit_span(adjusted)}
assert spans[b1.case][2]==54 and spans[adjusted.case][2]==8

mpl.rcParams.update({
    "font.family":"DejaVu Sans","font.size":9.5,"axes.labelsize":10,
    "axes.linewidth":.72,"axes.spines.top":False,"axes.spines.right":False,
    "pdf.fonttype":42,"savefig.facecolor":"white",
})
colors={-1.:"#723cb5",-.3:"#008b49",0.:"#0067c7",.3:"#d54d00",1.:"#c21976"}
band="#e7efe9"
edge="#85958a"
adjusted_color="#202020"
adopted_face="#d61028"

panels = [
    ("FeI_RMS_dex", "Fe I rms (dex)", "o"),
    ("FeII_RMS_dex", "Fe II rms (dex)", "s"),
    ("Balmer_n2_residual_dex", r"$\Delta\log N(n=2)$ (dex)", "o"),
]
fig, axes = plt.subplots(3, 2, figsize=(9.1, 6.22), sharex="col")
fig.subplots_adjust(left=.111, right=.975, bottom=.106, top=.787, hspace=.28, wspace=.29)
for column, heading in enumerate(("Full column-density scan", "Detail near the diagnostic limits")):
    box = axes[0, column].get_position()
    fig.text((box.x0 + box.x1)/2, .831, heading, ha="center", fontsize=11, weight="semibold")

for i, (field, axis_label, marker) in enumerate(panels):
    is_balmer = field == "Balmer_n2_residual_dex"
    for j, ax in enumerate(axes[i]):
        detail = j == 1
        subset = scan[scan.FeH_dex.isin([0, .30])] if detail else scan
        limits = (-.10, .10) if is_balmer else (0., .20)
        ax.axhspan(*limits, color=band, lw=0, zorder=-8)
        for value in (limits if is_balmer else (.20,)):
            ax.axhline(value, color=edge, ls=(0, (4, 2)), lw=.7, zorder=-7)
        if is_balmer:
            ax.axhline(0, color=".61", lw=.58, zorder=-8)
        for abundance, track in subset.groupby("FeH_dex"):
            color = colors[abundance]
            track_order = 4 if field == "FeI_RMS_dex" and abundance == 0.0 else 2
            ax.plot(track.logN_H, track[field], marker=marker, color=color, lw=1.17,
                    mfc="white" if i == 0 else color, mew=.88, ms=3.5, zorder=track_order)
        if detail and is_balmer:
            for model, color in ((b1, colors[0.]), (adjusted, adjusted_color)):
                lo, hi, _ = spans[model.case]
                ax.errorbar(model.logN_H, (lo+hi)/2, yerr=(hi-lo)/2, fmt="none",
                            color=color, capsize=3.3, lw=1.25, zorder=5)
        ax.plot(b1.logN_H, getattr(b1, field), marker="*", mfc=adopted_face, mec="white",
                mew=.95, ms=12 if detail else 11, ls="none", zorder=8)
        ax.plot(adjusted.logN_H, getattr(adjusted, field), marker="D", mfc="white",
                mec=adjusted_color, mew=1.05, ms=6.25 if detail else 4.8, ls="none", zorder=9)
        ax.tick_params(direction="out", length=3, width=.7, pad=3)
        ax.tick_params(which="minor", direction="out", length=1.6, width=.55)
        ax.xaxis.set_major_locator(MultipleLocator(.10 if detail else .5))
        ax.xaxis.set_minor_locator(MultipleLocator(.05 if detail else .25))
        ax.set_xlim((22.075, 22.33) if detail else (20.72, 23.54))
        if is_balmer:
            ax.set_ylim((-.225, .14) if detail else (-1.42, .6))
            ax.yaxis.set_major_locator(MultipleLocator(.10 if detail else .4))
        else:
            ax.set_ylim((.064, .277) if detail else (-.018, 1.31))
            ax.yaxis.set_major_locator(MultipleLocator(.05 if detail else .3))
        label = "abcdef"[2*i+j]
        ax.set_title(f"({label})", loc="left", fontsize=9.6, weight="semibold", pad=4)
        if not detail:
            ax.set_ylabel(axis_label)
        assert not ax.texts  # All model-identification text is outside the panels.

fig.supxlabel(r"$\log_{10}(N_{\rm H}/{\rm cm}^{-2})$", y=.034, fontsize=10.4)
abundance_legend = [Line2D([], [], color=color, lw=1.6, label=label)
                    for color, label in zip(colors.values(),
                    ["−1.0", "−0.30", "0", "+0.30", "+1.0"], strict=True)]
fig.legend(handles=abundance_legend, title="[Fe/H]", loc="upper center",
           bbox_to_anchor=(.54, .991), ncol=5, frameon=False,
           fontsize=9.3, title_fontsize=9.6, columnspacing=1.8, handlelength=1.75)
fig.legend(handles=[
    Line2D([], [], marker="*", mfc=adopted_face, mec="white", mew=.9, ms=12,
           ls="none", label="Adopted B1"),
    Line2D([], [], marker="D", mfc="white", mec=adjusted_color, mew=1.08, ms=6.2,
           ls="none", label="Ca-adjusted model"),
    Line2D([], [], color=".26", marker="|", mew=1.15, ms=9, ls="none",
           label="H15/H16 fit range"),
], loc="upper center", bbox_to_anchor=(.54, .906), ncol=3, frameon=False,
    fontsize=9.2, columnspacing=1.75, handlelength=1.5)
fig.savefig(root/"V1405Cas_FeH_Balmer_diagnostic.pdf")
print("20 hydrogen-stopped trials plus Ca adjustment; Balmer spans", spans)
