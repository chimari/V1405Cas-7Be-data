# V1405 Cas Fe/H and hydrogen-column sensitivity

Run 'python3 plot.py' with Matplotlib, NumPy and pandas to recreate
'V1405Cas_FeH_Balmer_diagnostic.pdf' next to the script. The manuscript's exact figure is [reference_plot.pdf](reference_plot.pdf). The
[caption](caption.tex) accompanies Figure 23 in Appendix 9.

The three summary CSVs come from the Cloudy C25.00 reference/grid, +0.30 dex
extension, and +0.30 dex Ca-adjustment runs. The scan has 20 hydrogen-stopped
models. The reference B1 run (Fe II stopping column) and the Ca-adjusted
rerun are overplotted separately. 'H15_H16_fit_trials.csv' contains the 54
joint H15/H16 fits used to calculate the Balmer residual bars and pass counts.
The columns with names ending in '_fixed_structure' apply the model
ion and level fractions to the observed ionic columns without recalculating
the structure. They are distinct from the elemental abundances used as inputs.

[Cloudy inputs and selected numerical outputs](../cloudy_feh_nh/README.md).
