"""Plot the comparison-nova Fe/H Cloudy grids with their observational screens."""
from dataclasses import dataclass
from pathlib import Path

import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.lines import Line2D
from matplotlib.ticker import MultipleLocator
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "output"
COLORS = {-1.: "#723cb5", -.3: "#008b49", 0.: "#0067c7", .3: "#d54d00", 1.: "#c21976"}
BAND, EDGE, ALT_BAND = "#e7efe9", "#73867d", "#f0f5f2"
RED, INK = "#d61028", "#202020"
FE, CA, NA = "FeII_rms_dex", "CaII_residual_dex", "log_NaI_ground"
BALMER = "Balmer_residual_nominal_Cf0p3_dex"
COG_FITS = {0.60: "0.60", 0.25: "0.25", 0.30: "0.30"}

mpl.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 9.3, "axes.labelsize": 9.5,
    "axes.linewidth": .72, "axes.spines.top": False, "axes.spines.right": False,
    "pdf.fonttype": 42, "savefig.facecolor": "white",
})


@dataclass(frozen=True)
class Diagnostic:
    column: str
    label: str
    ylim: tuple
    tick: float
    accepted: tuple
    limits: tuple
    zero: bool = False
    alternate: tuple = ()


def observed_balmer_span():
    fits = pd.read_csv(ROOT / "inputs/V339Del_balmer_fits.csv")
    joint = fits.loc[fits.lines.eq("H15+H16") & fits.Cf.eq(.30) & ~fits.bound_hit]
    adopted = joint.loc[joint.v_lo.eq(-60) & joint.v_hi.eq(48)
                        & joint.continuum_degree.eq(2), "log_N2"].item()
    offsets = np.sort(joint.log_N2.to_numpy() - adopted)
    assert len(offsets) == 6 and np.diff(offsets).max() < .20
    return offsets.min()-.10, offsets.max()+.10


def diagnostics(nova):
    fe = Diagnostic(FE, "Fe II rms (dex)", (-.035, 2.06), .4, (0., .20), (.20,))
    ca_limits = {
        "V339Del": (-1.65, 2.60),
        "V5668Sgr": (-1.79, 2.06),
        "V2944Oph": (-1.37, 4.12),
    }
    ca = Diagnostic(CA, r"$\Delta\log N_g(\mathrm{Ca\,II})$ (dex)",
                    ca_limits[nova], .8 if nova == "V2944Oph" else .6,
                    (-.30, .30), (-.30, .30), zero=True)
    na_label = r"$\log_{10}[N_g(\mathrm{Na\,I})/\mathrm{cm}^{-2}]$"
    if nova == "V339Del":
        limit = np.log10(1.4e12)
        na = Diagnostic(NA, na_label, (10.3, 14.3), 1., (10.3, limit), (limit,))
        balmer = Diagnostic(BALMER, r"$\Delta\log N(n=2)$ (dex)",
                            (-2.58, .26), .5, (-.10, .10), (-.10, .10),
                            zero=True, alternate=observed_balmer_span())
        return fe, balmer, ca, na
    na_range = (12.5641, 13.1641) if nova == "V5668Sgr" else (12.87, 13.16)
    na = Diagnostic(NA, na_label, (10.65, 14.87), 1., na_range, na_range)
    return fe, ca, na


def styles():
    return {
        "reference": dict(marker="*", markerfacecolor=RED, markeredgecolor="white",
                          markeredgewidth=.95, markersize=11),
        "control": dict(marker="D", markerfacecolor="white", markeredgecolor=INK,
                        markeredgewidth=1.05, markersize=5.7),
    }


def thresholds(ax, info):
    if info.alternate:
        ax.axhspan(*info.alternate, color=ALT_BAND, lw=0, zorder=-9)
        for value in info.alternate:
            ax.axhline(value, color="#a4b6ac", lw=.57, ls=(0, (1.2, 2.0)), zorder=-8)
    ax.axhspan(*info.accepted, color=BAND, lw=0, zorder=-7)
    for value in info.limits:
        ax.axhline(value, color=EDGE, lw=.72, ls=(0, (4, 2)), zorder=-6)
    if info.zero:
        ax.axhline(0, color=".63", lw=.55, zorder=-5)


def full_and_points(nova, scan, controls):
    reference=controls.loc[controls.case.eq("reference" if nova=="V339Del" else "reference_control")].iloc[0]
    if nova == "V339Del":
        matched = scan.loc[scan.grid_slice.eq("near_constant_total_Fe")
                           | (scan.FeH_dex.eq(0.) & scan.log_NH_target.eq(20.5526))]
        assert len(matched) == 5 and (matched.log_N_FeII - reference.log_N_FeII).abs().max() < .025
        return (
            (scan, True, reference, "reference",
             "Full column-density scan", "STIS-shaped illumination", (19.40, 22.51)),
            (matched, False, reference, "reference",
             "Near the reference Fe II column", r"$|\Delta\log N(\mathrm{Fe\,II})|<0.025$ dex", (19.40, 22.51)),
        )
    control = controls.loc[controls.case.eq("low_FeII_rms_control")].iloc[0]
    if nova == "V5668Sgr":
        headings = ("Reference blackbody", "Hotter blackbody")
        details = (r"$T_{\rm src}=15\,500$ K, $\log n_{\rm H}=11.125$",
                   r"$T_{\rm src}=20\,000$ K, $\log n_{\rm H}=10.625$")
        xlim = (20.27, 23.43)
    else:
        headings = ("Reference spectrum", "Near-UV enhanced spectrum")
        details = (r"$\log n_{\rm H}=10.25$", r"Peak enhancement $\times3$, $\log n_{\rm H}=10.25$")
        xlim = (20.12, 23.45)
    result = []
    for i, (family, row, symbol) in enumerate((
        ("reference", reference, "reference"), ("low_FeII_rms", control, "control"),
    )):
        result.append((scan.loc[scan.family.eq(family)], True, row, symbol,
                       headings[i], details[i], xlim))
    return result


def figure(nova, title, absorber, covering):
    source = pd.read_csv(ROOT / "inputs" / f"{nova}.csv")
    if nova=="V339Del":
        source = source.rename(columns={"logNH_target": "log_NH_target", "log_N_NaI_ground": NA})
    scan, controls = source.loc[source.stop.eq("H")], source.loc[source.stop.eq("Fe II")]
    assert len(scan) == (19 if nova == "V339Del" else 28)
    assert len(controls) == (1 if nova == "V339Del" else 2)
    assert set(scan.FeH_dex)==set(COLORS) and not scan.FeII_pass.any()
    assert round(scan[FE].min(), 3) == {"V339Del": .458, "V5668Sgr": .306, "V2944Oph": .385}[nova]
    arranged = full_and_points(nova, scan, controls)
    metrics = diagnostics(nova)
    n = len(metrics)
    fig, axes = plt.subplots(n, 2, figsize=(9.1, 7.65 if n==4 else 6.40), sharex="col")
    fig.subplots_adjust(left=.115, right=.975, bottom=.143, top=.779 if n==4 else .758,
                        hspace=.29, wspace=.29)
    fig.text(.50,.969,title,ha="center",fontsize=15,weight="semibold")
    fig.text(.50,.936, absorber + rf"   $\cdot$   $C_f={COG_FITS[covering]}$ for Fe II",
             ha="center", fontsize=9.5, color="#35464e")
    ab = [Line2D([],[],color=color,lw=1.65,label=label) for color,label in
          zip(COLORS.values(), ("−1.0","−0.30","0","+0.30","+1.0"), strict=True)]
    fig.legend(handles=[Line2D([],[],color="none",label="[Fe/H]"), *ab], ncol=6,
               loc="upper center", bbox_to_anchor=(.524,.911), frameon=False,
               fontsize=9.3, columnspacing=1.55, handlelength=1.6, handletextpad=.55)
    marker_styles = styles()
    marks = [("reference", "Fe II-stop reference")]
    if n==3:
        marks.append(("control", "Second Fe II-stop control"))
    fig.legend(handles=[Line2D([],[],linestyle="none", label=label, **marker_styles[key])
                        for key,label in marks], ncol=len(marks), loc="upper center",
               bbox_to_anchor=(.524,.878 if n==4 else .862), frameon=False,
               fontsize=9.0, columnspacing=1.68, handlelength=1.3)
    for j, (points, lines, control, marker_key, heading, details, xlim) in enumerate(arranged):
        position = axes[0,j].get_position()
        xmid = (position.x0 + position.x1)/2
        fig.text(xmid, .822 if n==4 else .802, heading, ha="center", fontsize=10.35,weight="semibold")
        fig.text(xmid, .800 if n==4 else .779, details, ha="center", fontsize=8.25, color="#35464e")
        for i, (ax, info) in enumerate(zip(axes[:,j], metrics, strict=True)):
            thresholds(ax, info)
            for feh, group in points.groupby("FeH_dex"):
                track=group.sort_values("log_N_H")
                color=COLORS[feh]
                ax.plot(track.log_N_H, track[info.column], marker="o", markersize=3.65 if lines else 5.2,
                        markerfacecolor="white" if lines else color, markeredgewidth=.9,
                        linewidth=1.17, color=color, linestyle="-" if lines else "none",
                        zorder=4 if feh==0. else 2)
            ax.plot(control.log_N_H, control[info.column], linestyle="none",
                    zorder=9, **marker_styles[marker_key])
            ax.set_xlim(*xlim)
            ax.set_ylim(*info.ylim)
            ax.xaxis.set_major_locator(MultipleLocator(.5))
            ax.xaxis.set_minor_locator(MultipleLocator(.25))
            ax.yaxis.set_major_locator(MultipleLocator(info.tick))
            ax.tick_params(direction="out", length=3, width=.7, pad=3)
            ax.tick_params(which="minor", direction="out", length=1.6, width=.55)
            ax.set_title(f"({'abcdefgh'[2*i+j]})", loc="left", fontsize=9.2, weight="semibold", pad=3.1)
            if j==0:
                ax.set_ylabel(info.label)
            assert not ax.texts
    fig.supxlabel(r"$\log_{10}(N_{\rm H}/\mathrm{cm}^{-2})$", y=.082, x=.544, fontsize=10.35)
    notes = {
        "V339Del": ("The darker Balmer band uses the adopted H15/H16 fit. The pale extension admits any of the six fits at\n"
                    "$C_f=0.30$. Na I shading marks values below the observational upper limit."),
        "V5668Sgr": ("Shading shows the trial tolerances. The Na I band spans ±0.30 dex around the adopted column and\n"
                      "depends on the treatment of the local background."),
        "V2944Oph": ("Shading shows the trial tolerances. The Na I band spans 12.87–13.16 from the background and covering\n"
                      "tests of the doublet on the He I 5876 Å emission."),
    }
    fig.text(.115,.034,notes[nova],fontsize=8.15,color="#35464e",va="center", linespacing=1.26)
    return fig


def main():
    OUTPUT.mkdir(exist_ok=True)
    cases = [
        ("V339Del", "V339 Del", r"Day $+47$ from optical maximum, $-1103$ km s$^{-1}$", .30),
        ("V5668Sgr", "V5668 Sgr", r"$-786.2$ km s$^{-1}$ absorber", .60),
        ("V2944Oph", "V2944 Oph", r"$-878$ km s$^{-1}$ absorber", .25),
    ]
    with PdfPages(OUTPUT / "Nova_FeH_diagnostics_review.pdf") as review:
        for name, title, absorber, covering in cases:
            fig=figure(name,title,absorber,covering)
            fig.savefig(OUTPUT / f"{name}_FeH_NH_diagnostics.pdf")
            review.savefig(fig)
            plt.close(fig)


if __name__=="__main__":
    main()
