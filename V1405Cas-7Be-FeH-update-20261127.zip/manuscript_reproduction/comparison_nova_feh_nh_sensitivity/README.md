# Fe/H and hydrogen-column diagnostics for the three comparison absorbers

The vector PDFs cover [V339 Del](output/V339Del_FeH_NH_diagnostics.pdf),
[V5668 Sgr](output/V5668Sgr_FeH_NH_diagnostics.pdf), and
[V2944 Oph](output/V2944Oph_FeH_NH_diagnostics.pdf). Run `python3 plot.py` with
NumPy, pandas and Matplotlib to regenerate the three figures and a review PDF.

The colour scale is shared with V1405 Cas Fig. 23. Each circle is a completed
hydrogen-stopped model. Connected points of the same colour show models with
the same input [Fe/H] and incident spectrum. Lines guide the eye between
the sampled columns. The red star marks the adopted Fe II-stopped model; the
open diamond marks the Fe II-stopped control of the alternate family on the
V5668 Sgr and V2944 Oph figures.

- V339 Del includes 19 hydrogen-stopped trials plus the reference control
  from the manuscript's reproduction data. The right column uses the four
  Fe-matched hydrogen-stop trials and the solar-composition hydrogen-stop
  point. Its Fe II columns are within 0.025 dex of the reference. The Balmer
  residual is model minus the adopted H15/H16 fit. The pale extension
  corresponds to passing the 0.10 dex test for any of the six fits at
  C_f = 0.30. The Na I band extends up to the observational upper limit
  of 1.4e12 cm^-2.
- V5668 Sgr and V2944 Oph each include 28 hydrogen-stopped trials and two
  Fe II-stop controls, evaluated from the returned Cloudy C25.00 files.
  Their left and right columns distinguish the reference and alternate
  illumination and density prescriptions. Their Na I bands use the
  respective trials, 12.8641 ± 0.30 and 12.87–13.16 in log ground-state
  column (cm^-2). These are background-dependent comparison bands.
- The shaded Fe II and Ca II bands are the 0.20 dex rms and ±0.30 dex
  column-mismatch trial criteria. The figures use separate panels for
  these checks, so each model can be compared directly with the plotted
  condition in each row.

See [Table 11](../comparison_nova_slab_diagnostics/README.md), [Table 12](../four_nova_mass_fractions/README.md), and the [Cloudy inputs and selected numerical outputs](../cloudy_feh_nh/README.md).
