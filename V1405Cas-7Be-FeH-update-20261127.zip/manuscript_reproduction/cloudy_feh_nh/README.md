# Cloudy Fe/H and total hydrogen-column grids

[Cloudy inputs and selected diagnostic outputs](Cloudy_inputs_and_diagnostic_outputs.tar.xz) cover the V1405 Cas pilot, grid, +0.30 dex extension and Ca adjustment, and the V339 Del, V5668 Sgr and V2944 Oph grids. The archive includes the runnable packages, model decks, case definitions, summary CSVs and returned ion and Fe level columns. The top-level directory identifies the source package. The full solver logs and zone histories are excluded.

Verify the archive with `sha256sum -c SHA256SUMS` and extract it with `tar -xJf Cloudy_inputs_and_diagnostic_outputs.tar.xz`. Each input package has instructions for Cloudy C25.00. For calculations that depend on the V1405 Cas atomic overlays, use the same adopted atomic data as the [UV025 B1 model](../uv025_b1_slab_inputs/README.md). Set the executable and data paths for your installation as described by the individual runners. The public package uses portable path defaults.

- [Figure 23 and its four CSVs](../v1405_cas_feh_nh_sensitivity/README.md)
- [Comparison figures and source CSVs](../comparison_nova_feh_nh_sensitivity/README.md)
- [Table 11 Fe/H diagnostics](../comparison_nova_slab_diagnostics/feh_nh_diagnostic_summary.csv)
- [Table 12 discovery-epoch mass-fraction sensitivity](../four_nova_mass_fractions/mass_fraction_trial_ranges.csv)
