from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import least_squares, minimize_scalar

ROOT = Path(__file__).resolve().parent
C = 299792.458
K = 1.497e-15 * np.sqrt(np.pi)
GRID = [0.8]
WAVES = np.array([3130.583557665, 3131.228107417, 3132.056630])
BE_TIE = 10**(-.479+.178) * WAVES[1]/WAVES[0]
ca = pd.read_csv(ROOT/'diagnostic_current.csv').set_index('ID').loc[['D03','D04']]
profiles = pd.read_csv(ROOT/'be_saved_background_profiles.csv')
template = pd.read_csv(ROOT/'opacity_templates.csv').query('Cf == 0.8')

def shape(v):
    return np.interp(v, template.v_relative_kms, template.phi_per_kms, left=0, right=0)

def flux(tau, covering):
    return 1 - covering + covering*np.exp(-tau)

def calcium(log_n, covering):
    u = np.linspace(-57, 28, 851)
    side = np.r_[np.linspace(-77, -57, 201), np.linspace(33, 53, 201)]
    wavelengths = ca.rest_air_A.to_numpy()
    strength = K * 10**(log_n + ca.loggf.to_numpy()) * wavelengths / 2
    side_flux = flux(shape(side)[:, None]*strength, covering)
    design = np.c_[np.ones(len(side)), side]
    baseline = np.c_[np.ones(len(u)), u] @ np.linalg.lstsq(design, side_flux, rcond=None)[0]
    model = flux(shape(u)[:, None]*strength, covering)/baseline
    return np.trapezoid(1-model,u,axis=0)*wavelengths/C*1000

rows = []
for covering in GRID:
    if covering > 1:
        covering = 1.0
    observed_ca = ca.EW_rest_mA.to_numpy()
    def ca_objective(log_n):
        return np.sum(np.log10(calcium(log_n, covering) / observed_ca)**2)
    fit_ca=minimize_scalar(ca_objective,bounds=(10,15),method='bounded',options={'xatol':1e-12})
    assert fit_ca.success
    pred_ca = calcium(fit_ca.x,covering)
    for background,g in profiles.groupby('background'):
        w,y=g.wave_air_A.to_numpy(),g.normalized_flux.to_numpy()
        v=C*((w[:,None]/WAVES)**2-1)/((w[:,None]/WAVES)**2+1)+793
        p=shape(v)
        def residual(log_strength):
            b,cr=10**log_strength
            return flux(b*(p[:,0]+BE_TIE*p[:,1])+cr*p[:,2],covering)-y
        fits=[least_squares(residual,x0,bounds=(-4,5),max_nfev=300) for x0 in ((1,2),(2,3),(2,2))]
        fit=min((x for x in fits if x.success),key=lambda x:np.sum(x.fun**2))
        log_be=np.log10(2*10**fit.x[0]/(K*10**(-.178)*WAVES[0]))
        ratio=10**(log_be-fit_ca.x)
        rows.append(dict(Cf=round(covering,2), background=background, logN_BeII=log_be,
                         logN_CaII=fit_ca.x, ionic_ratio=ratio, BeCa_fixed_Kg=ratio*1.244e-4,
                         rms_Be_flux=np.sqrt(np.mean(fit.fun**2)),
                         max_abs_Be_residual=np.max(np.abs(fit.fun)),
                         rms_Ca_log_EW=np.sqrt(fit_ca.fun/2),
                         CaK_obs_minus_model=observed_ca[0]-pred_ca[0],
                         CaH_obs_minus_model=observed_ca[1]-pred_ca[1],
                         Be_flux_samples_below_covering_floor=int(np.sum(y<1-covering)),
                         Be_fit_at_bound=bool(np.any(fit.active_mask)),
                         max_Be_component_tau=float(np.max(10**fit.x[0]*(p[:,0]+BE_TIE*p[:,1])))))

original = pd.DataFrame(rows).assign(template="full")
v = template.v_relative_kms.to_numpy()
phi = template.phi_per_kms.to_numpy()
phi *= np.clip((v+32)/7, 0, 1)
phi /= np.trapezoid(phi,v)
rows = []
for covering in GRID:
    if covering > 1:
        covering = 1.0
    observed_ca = ca.EW_rest_mA.to_numpy()
    def ca_objective(log_n):
        return np.sum(np.log10(calcium(log_n, covering) / observed_ca)**2)
    fit_ca=minimize_scalar(ca_objective,bounds=(10,15),method='bounded',options={'xatol':1e-12})
    assert fit_ca.success
    pred_ca = calcium(fit_ca.x,covering)
    for background,g in profiles.groupby('background'):
        w,y=g.wave_air_A.to_numpy(),g.normalized_flux.to_numpy()
        v=C*((w[:,None]/WAVES)**2-1)/((w[:,None]/WAVES)**2+1)+793
        p=shape(v)
        def residual(log_strength):
            b,cr=10**log_strength
            return flux(b*(p[:,0]+BE_TIE*p[:,1])+cr*p[:,2],covering)-y
        fits=[least_squares(residual,x0,bounds=(-4,5),max_nfev=300) for x0 in ((1,2),(2,3),(2,2))]
        fit=min((x for x in fits if x.success),key=lambda x:np.sum(x.fun**2))
        log_be=np.log10(2*10**fit.x[0]/(K*10**(-.178)*WAVES[0]))
        ratio=10**(log_be-fit_ca.x)
        rows.append(dict(Cf=round(covering,2), background=background, logN_BeII=log_be,
                         logN_CaII=fit_ca.x, ionic_ratio=ratio, BeCa_fixed_Kg=ratio*1.244e-4,
                         rms_Be_flux=np.sqrt(np.mean(fit.fun**2)),
                         max_abs_Be_residual=np.max(np.abs(fit.fun)),
                         rms_Ca_log_EW=np.sqrt(fit_ca.fun/2),
                         CaK_obs_minus_model=observed_ca[0]-pred_ca[0],
                         CaH_obs_minus_model=observed_ca[1]-pred_ca[1],
                         Be_flux_samples_below_covering_floor=int(np.sum(y<1-covering)),
                         Be_fit_at_bound=bool(np.any(fit.active_mask)),
                         max_Be_component_tau=float(np.max(10**fit.x[0]*(p[:,0]+BE_TIE*p[:,1])))))

pd.concat([original, pd.DataFrame(rows).assign(template="tapered")]).to_csv(ROOT / "template_check.csv", index=False)
