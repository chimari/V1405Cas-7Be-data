from pathlib import Path
import numpy as np
def read(p):
 raw=p.read_bytes();h={}
 for i in range(0,len(raw),80):
  s=raw[i:i+80].decode('ascii');k=s[:8].strip()
  if k=='END':break
  if s[8:10]=='= ':h[k]=s[10:].split('/')[0].strip().strip("'").strip()
 assert h['NAXIS']=='1' and h['BITPIX']=='-32'
 f=np.frombuffer(raw,dtype='>f4',count=int(h['NAXIS1']),offset=((i+80+2879)//2880)*2880).astype(float)*float(h.get('BSCALE',1))+float(h.get('BZERO',0));w=float(h['CRVAL1'])+(np.arange(len(f))+1-float(h['CRPIX1']))*float(h['CDELT1']);return w,f
