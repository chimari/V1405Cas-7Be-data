from pathlib import Path
from fits_reader import read
import numpy as np
import pandas as pd
from scipy.optimize import least_squares, minimize_scalar

exec(Path('scan.py').read_text().split('rows = []')[0].replace('ROOT = Path(__file__).resolve().parent','ROOT = Path.cwd()'))
primary=pd.read_csv('primary_points_Cf08.csv')
arms={arm:read(Path(name)) for arm,name in [('Ub','Ub.fits'),('Yb','Yb_120s.fits')]}
grid=np.arange(-60,40.1,.5)
weak=[]
for row in primary.itertuples():
    if row.ion not in ('Fe II','Ti II','Cr II'):
        continue
    w,f=arms[row.arm]
    q=(w/row.rest_air_A)**2
    v=C*(q-1)/(q+1)+793
    side=((v>=row.continuum_blue_lo_relative_kms)&(v<=row.continuum_blue_hi_relative_kms))|((v>=row.continuum_red_lo_relative_kms)&(v<=row.continuum_red_hi_relative_kms))
    core=(v>=-17)&(v<=13)
    if not side.any() or not core.any():
        continue
    i=f/np.polyval(np.polyfit(v[side],f[side],1),v)
    depth=1-i[core].min()
    if 0<depth<=.15:
        tau=-np.log((np.interp(grid,v,i)-.2)/.8)
        area=np.trapezoid(tau,grid)
        if area>0:
            weak.append((row.ion,row.ID,depth,tau/area))
print(pd.Series([r[0] for r in weak]).value_counts())
def average(records):
    phi=np.maximum(np.mean([r[3] for r in records],axis=0),0)
    return phi/np.trapezoid(phi,grid)

archive=template
templates={'archived':archive,'reconstructed':pd.DataFrame({'v_relative_kms':grid,'phi_per_kms':average(weak)})}
for ion in ('Fe II','Ti II','Cr II'):
    templates[ion]=pd.DataFrame({'v_relative_kms':grid,'phi_per_kms':average([r for r in weak if r[0]==ion])})

def measured_ew(row, strength):
    u=np.linspace(row.EW_lo_relative_kms,row.EW_hi_relative_kms,851)
    side=np.r_[np.linspace(row.continuum_blue_lo_relative_kms,row.continuum_blue_hi_relative_kms,201),
               np.linspace(row.continuum_red_lo_relative_kms,row.continuum_red_hi_relative_kms,201)]
    baseline=np.polyval(np.polyfit(side,flux(shape(side)*strength,.8),1),u)
    return np.trapezoid(1-flux(shape(u)*strength,.8)/baseline,u)*row.rest_air_A/C*1000

def fe_fit():
    iron=list(primary[primary.ion=='Fe II'].itertuples())
    def loss(scale):
        return sum(np.log10(measured_ew(r,10**(r.log_integrated_tau_kms+scale))/r.EW_rest_mA)**2 for r in iron)
    return minimize_scalar(loss,bounds=(-1,1),method='bounded').x

rows=[]
for name, template in templates.items():
    ca_fit=minimize_scalar(lambda n:sum(np.log10(calcium(n,.8)/ca.EW_rest_mA.to_numpy())**2),bounds=(10,15),method='bounded')
    fe=fe_fit()
    for bg,g in profiles.groupby('background'):
        w,y=g.wave_air_A.to_numpy(),g.normalized_flux.to_numpy()
        q=(w[:,None]/WAVES)**2
        v=C*(q-1)/(q+1)+793
        controls=[(window,shift,name,tilt) for window in ('full','trim')
                  for shift in (-2,0,2) for tilt in (-.02,0,.02)]
        if name=='archived':
            controls.append(('full',0,'Cr II',0))
        for window, shift, cr_name, tilt in controls:
            observed=y/(1+tilt*(w-w.mean())/np.ptp(w))
            mask=np.ones(len(w),dtype=bool) if window=='full' else (w>=w.min()+.10)&(w<=w.max()-.10)
            cr=templates[cr_name]
            cr_shape=np.interp(v[:,2]-shift,cr.v_relative_kms,cr.phi_per_kms,left=0,right=0)
            be_shape=shape(v[:,0])+BE_TIE*shape(v[:,1])
            def residual(l):
                return flux(10**l[0]*be_shape+10**l[1]*cr_shape,.8)-observed
            fit=least_squares(lambda l:residual(l)[mask],[2,3],bounds=(-4,5))
            assert fit.success and not np.any(fit.active_mask)
            be=np.log10(2*10**fit.x[0]/(K*10**(-.178)*WAVES[0]))
            rows.append(dict(template=name,Cr_template=cr_name,background=bg,window=window,Cr_shift=shift,background_tilt=tilt,logN_Be=be,
                             logN_Ca=ca_fit.x,log_Fe_scale=fe,BeCa_ionic=10**(be-ca_fit.x),
                             log_BeFe_relative=be-fe,rms_full=np.sqrt(np.mean(residual(fit.x)**2))))
result=pd.DataFrame(rows)
base=result.query("template=='archived' and Cr_template=='archived' and background=='B1' and window=='full' and Cr_shift==0 and background_tilt==0").iloc[0]
result['BeFe_over_reference']=10**(result.pop('log_BeFe_relative')-(base.logN_Be-base.log_Fe_scale))
result.to_csv('trials.csv',index=False)
print(result.query("window=='full' and Cr_shift==0 and background_tilt==0").round(4).to_string(index=False))
print(result[['logN_Be','BeCa_ionic','BeFe_over_reference']].agg(['min','max']))
