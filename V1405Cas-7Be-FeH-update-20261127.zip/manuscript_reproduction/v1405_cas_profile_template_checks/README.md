# V1405 Cas profile-template sensitivity

`V1405Cas_template_check/` contains the opacity-taper trials; run `python scan.py` in that directory. `V1405Cas_ion_templates/` contains the ion-specific template checks. See its README for the inputs and the command that regenerates the trial CSV. These tests support section 6.2 and Table 6.
